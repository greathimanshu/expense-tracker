<?php

namespace App\Livewire;

use Livewire\Component;
use App\Models\Profile;
use App\Models\Project;
use App\Models\Experience;
use App\Models\Skill;
use App\Models\SocialLink;
use App\Models\Service;
use App\Models\Testimonial;
use App\Models\SeoSetting;

class Portfolio extends Component
{
    public ?string $theme = null;

    public function mount(?string $theme = null): void
    {
        $this->theme = $theme;
    }

    public function render()
    {
        $profile = Profile::first();
        $projects = Project::orderByDesc('featured')->orderByDesc('year')->get();
        $experiences = Experience::orderByDesc('start_date')->get();
        $skills = Skill::orderByDesc('proficiency')->get();
        $socials = SocialLink::orderBy('order')->get();
        $services = Service::orderBy('order')->get();
        $testimonials = Testimonial::orderBy('order')->get();

        // SEO
        $seo = SeoSetting::first();
        $fallbackTitle = trim(($profile->name ?? 'Portfolio') . (isset($profile->title) ? ' — ' . $profile->title : ''));
        $title = $seo->meta_title ?? $fallbackTitle;
        $metaDescription = $seo->meta_description ?? ($profile->bio ?? 'Laravel + Livewire portfolio SPA');
        $metaKeywords = $seo->meta_keywords ?? null;
        $ogImage = $seo->og_image ?? null;

        $theme = $this->theme ?: ($profile?->site_theme ?: 'minimal-accent');
        $viewName = view()->exists('livewire.themes.' . $theme)
            ? 'livewire.themes.' . $theme
            : 'livewire.portfolio';

        $layoutName = view()->exists('layouts.themes.' . $theme)
            ? 'layouts.themes.' . $theme
            : 'layouts.app';

        return view($viewName, compact('profile', 'projects', 'experiences', 'skills', 'socials', 'services', 'testimonials'))
            ->with('__forceTheme', $theme)
            ->layout($layoutName, [
                'title' => $title,
                'metaDescription' => $metaDescription,
                'metaKeywords' => $metaKeywords,
                'ogTitle' => $title,
                'ogDescription' => $metaDescription,
                'ogImage' => $ogImage,
                'twitterTitle' => $title,
                'twitterDescription' => $metaDescription,
            ]);
    }
}
