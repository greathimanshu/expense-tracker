<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Service extends Model
{
    use HasFactory;

    protected $fillable = [
        'title', 'summary', 'icon', 'order'
    ];

    protected $casts = [
        'order' => 'integer',
    ];
}
