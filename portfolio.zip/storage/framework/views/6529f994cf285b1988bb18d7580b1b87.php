<div class="container mx-auto max-w-6xl px-4 py-10">
  <div class="flex items-center justify-between mb-6">
    <h1 class="text-2xl font-bold">Certificates</h1>
    <a href="<?php echo e(route('admin.dashboard')); ?>" class="text-sm text-indigo-600">Back to Dashboard</a>
  </div>

  <!--[if BLOCK]><![endif]--><?php if(session('status')): ?>
    <div class="mb-4 rounded-md bg-green-50 text-green-800 px-4 py-2 text-sm"><?php echo e(session('status')); ?></div>
  <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

  <div class="grid md:grid-cols-3 gap-6">
    <form wire:submit.prevent="save" class="space-y-4 bg-white rounded-xl border border-gray-200 p-6 mb-6">
      <div class="flex items-center justify-between">
        <h2 class="font-semibold"><!--[if BLOCK]><![endif]--><?php if($editingId): ?> Edit Certificate <?php else: ?> New Certificate <?php endif; ?><!--[if ENDBLOCK]><![endif]--></h2>
        <button type="button" wire:click="createNew" class="text-sm text-gray-500">Reset</button>
      </div>
      <div class="grid md:grid-cols-2 gap-4">
        <div class="md:col-span-2">
          <label class="block text-sm text-gray-600 mb-1">Name</label>
          <input type="text" wire:model="name" class="w-full rounded-md border border-gray-300 px-3 py-2" />
          <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-sm text-red-600 mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
        </div>
        <div>
          <label class="block text-sm text-gray-600 mb-1">Issuer</label>
          <input type="text" wire:model="issuer" class="w-full rounded-md border border-gray-300 px-3 py-2" />
          <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['issuer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-sm text-red-600 mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
        </div>
        <div>
          <label class="block text-sm text-gray-600 mb-1">Date</label>
          <input type="date" wire:model="date" class="w-full rounded-md border border-gray-300 px-3 py-2" />
          <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-sm text-red-600 mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
        </div>
        <div class="md:col-span-2">
          <label class="block text-sm text-gray-600 mb-1">URL</label>
          <input type="url" wire:model="url" class="w-full rounded-md border border-gray-300 px-3 py-2" />
          <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-sm text-red-600 mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
        </div>
        <div>
          <label class="block text-sm text-gray-600 mb-1">Order</label>
          <input type="number" wire:model="order" class="w-full rounded-md border border-gray-300 px-3 py-2" />
          <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['order'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-sm text-red-600 mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
        </div>
      </div>
      <div class="flex items-center justify-end">
        <button type="submit" class="inline-flex items-center rounded-md bg-indigo-600 text-white px-4 py-2 hover:bg-indigo-500">Save Certificate</button>
      </div>
    </form>

    <div class="md:col-span-2 space-y-3">
      <div class="grid md:grid-cols-2 gap-4">
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $certificates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="p-4 rounded-xl border border-gray-200 bg-white">
            <div class="flex items-start justify-between gap-3">
              <div>
                <div class="font-semibold"><?php echo e($c->name); ?></div>
                <div class="text-sm text-gray-500"><?php echo e($c->issuer); ?></div>
              </div>
              <div class="flex items-center gap-2">
                <button wire:click="edit(<?php echo e($c->id); ?>)" class="text-sm text-indigo-600">Edit</button>
                <button wire:click="delete(<?php echo e($c->id); ?>)" class="text-sm text-red-600" onclick="return confirm('Delete this certificate?')">Delete</button>
              </div>
            </div>
            <div class="mt-1 text-xs text-gray-500 flex items-center gap-2">
              <!--[if BLOCK]><![endif]--><?php if($c->date): ?> <span><?php echo e($c->date->format('M Y')); ?></span> <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
              <!--[if BLOCK]><![endif]--><?php if($c->url): ?> <a class="text-indigo-600" href="<?php echo e($c->url); ?>" target="_blank">Link</a> <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
      </div>
      <div>
        <?php echo e($certificates->links()); ?>

      </div>
    </div>
  </div>
</div>
<?php /**PATH C:\xampp\htdocs\portfolio\resources\views/livewire/admin/certificates.blade.php ENDPATH**/ ?>