<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Project extends Model
{
    use HasFactory;

    protected $fillable = [
        'title',
        'slug',
        'description',
        'tech_stack',
        'github_url',
        'live_url',
        'image_url',
        'year',
        'featured',
        'include_in_resume',
        'order',
    ];

    protected $casts = [
        'featured' => 'boolean',
        'include_in_resume' => 'boolean',
        'year' => 'integer',
        'order' => 'integer',
    ];
}
