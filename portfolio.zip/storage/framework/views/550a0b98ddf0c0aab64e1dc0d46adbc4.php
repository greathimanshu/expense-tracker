<?php $__env->startSection('content'); ?>
<div class="container mx-auto max-w-3xl px-4 py-6">
    <div class="flex items-center justify-between mb-6">
        <div>
            <h1 class="text-3xl font-bold tracking-tight"><?php echo e($resume['basics']['name'] ?? 'Resume'); ?></h1>
            <?php if(!empty($resume['basics']['label'])): ?>
                <p class="text-sm text-gray-600"><?php echo e($resume['basics']['label']); ?></p>
            <?php endif; ?>
        </div>
        <div class="flex items-center gap-2">
            <a href="<?php echo e(route('resume.json')); ?>" class="px-3 py-1.5 text-sm rounded-md border border-gray-200 hover:bg-gray-50">JSON</a>
            <a href="<?php echo e(route('resume.markdown')); ?>" class="px-3 py-1.5 text-sm rounded-md bg-indigo-600 text-white hover:bg-indigo-500">Download .md</a>
            <a href="<?php echo e(route('resume.pdf')); ?>" class="px-3 py-1.5 text-sm rounded-md bg-violet-600 text-white hover:bg-violet-500">Download PDF</a>
        </div>
    </div>

    <?php
        $fmt = function($d) {
            try { return $d ? \Carbon\Carbon::parse($d)->format('m/Y') : null; } catch (\Exception $e) { return $d; }
        };
    ?>
    <div class="rounded-xl bg-white border border-gray-200 p-5 mb-4">
        <h2 class="text-[12px] font-semibold uppercase tracking-wider text-gray-700">About</h2>
        <div class="h-px bg-gray-800/80 mt-1"></div>
        <?php if(!empty($resume['basics']['summary'] ?? null)): ?>
            <p class="text-gray-700"><?php echo e($resume['basics']['summary']); ?></p>
        <?php else: ?>
            <p class="text-gray-500">No summary provided.</p>
        <?php endif; ?>
        <div class="mt-4 text-sm text-gray-600 space-y-1">
            <?php if(!empty($resume['basics']['email'] ?? null)): ?>
                <div>Email: <a href="mailto:<?php echo $resume['basics']['email']; ?>" class="text-indigo-600"><?php echo e($resume['basics']['email']); ?></a></div>
            <?php endif; ?>
            <?php if(!empty($resume['basics']['url'] ?? null)): ?>
                <div>Website: <a href="<?php echo e($resume['basics']['url']); ?>" class="text-indigo-600" target="_blank" rel="noreferrer"><?php echo e($resume['basics']['url']); ?></a></div>
            <?php endif; ?>
            <?php if(!empty(($resume['basics']['location']['city'] ?? null))): ?>
                <div>Location: <?php echo e($resume['basics']['location']['city']); ?></div>
            <?php endif; ?>
            <?php
                $gh = null;
                foreach (($resume['basics']['profiles'] ?? []) as $p) {
                    $net = strtolower($p['network'] ?? '');
                    $url = strtolower($p['url'] ?? '');
                    if ($net === 'github' || str_contains($url, 'github.com')) { $gh = $p; break; }
                }
            ?>
            <?php if($gh): ?>
                <div>GitHub: <a href="<?php echo e($gh['url'] ?? '#'); ?>" class="text-indigo-600" target="_blank" rel="noreferrer"><?php echo e($gh['username'] ?? ($gh['url'] ?? 'GitHub')); ?></a></div>
            <?php endif; ?>
        </div>
        <?php if(!empty($resume['basics']['profiles'] ?? [])): ?>
            <div class="mt-3 flex flex-wrap gap-2 text-sm">
                <?php $__currentLoopData = $resume['basics']['profiles']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php ($u = strtolower($profile['url'] ?? '')); ?>
                    <?php ($name = trim(strtolower($profile['username'] ?? ''))); ?>
                    <?php if($u && !str_contains($u, 'example.com') && $name !== 'yourname' && !(strtolower($profile['network'] ?? '') === 'github' || str_contains($u, 'github.com'))): ?>
                        <a href="<?php echo e($profile['url']); ?>" class="px-2 py-1 rounded-md border border-indigo-200 text-indigo-700 hover:bg-indigo-50" target="_blank" rel="noreferrer"><?php echo e($profile['username']); ?></a>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </div>

    <?php if(!empty($resume['work'] ?? [])): ?>
        <div class="rounded-xl bg-white border border-gray-200 p-5 mb-4">
            <h2 class="text-[12px] font-semibold uppercase tracking-wider text-gray-700">Experience</h2>
            <div class="h-px bg-gray-800/80 mt-1 mb-2"></div>
            <div class="space-y-3">
                <?php $__currentLoopData = $resume['work']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div>
                        <div class="flex items-center justify-between">
                            <div class="font-medium"><?php echo e($work['position']); ?> · <?php echo e($work['company']); ?></div>
                            <div class="text-sm text-gray-500"><?php echo e($fmt($work['startDate'])); ?> — <?php echo e($fmt($work['endDate']) ?? 'Present'); ?></div>
                        </div>
                        <?php if(!empty($work['summary'])): ?>
                            <?php ($lines = array_values(array_filter(array_map('trim', preg_split('/\r?\n/', (string)$work['summary']))))); ?>
                            <?php if(count($lines) > 1): ?>
                                <ul class="list-disc ml-3 mt-1 text-sm text-gray-700">
                                    <?php $__currentLoopData = $lines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e(ltrim($line, "-• ")); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            <?php else: ?>
                                <p class="text-sm text-gray-700 mt-1"><?php echo e($work['summary']); ?></p>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php endif; ?>

    <?php if(!empty($resume['education'] ?? [])): ?>
        <div class="rounded-xl bg-white border border-gray-200 p-5 mb-4">
            <h2 class="text-[12px] font-semibold uppercase tracking-wider text-gray-700">Education</h2>
            <div class="h-px bg-gray-800/80 mt-1 mb-2"></div>
            <div class="space-y-3">
                <?php $__currentLoopData = $resume['education']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $edu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div>
                        <div class="flex items-center justify-between">
                            <div class="font-medium"><?php echo e($edu['studyType']); ?> <?php if(!empty($edu['area'])): ?> · <?php echo e($edu['area']); ?> <?php endif; ?></div>
                            <div class="text-sm text-gray-500">
                                <?php if(!empty($edu['startDate'])): ?> <?php echo e($fmt($edu['startDate'])); ?> <?php endif; ?> — <?php if(!empty($edu['endDate'])): ?> <?php echo e($fmt($edu['endDate'])); ?> <?php else: ?> Present <?php endif; ?>
                            </div>
                        </div>
                        <div class="text-sm text-gray-600"><?php echo e($edu['institution']); ?></div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php endif; ?>

    <?php if(!empty($resume['certificates'] ?? [])): ?>
        <div class="rounded-xl bg-white border border-gray-200 p-5 mb-4">
            <h2 class="text-[12px] font-semibold uppercase tracking-wider text-gray-700">Certificates</h2>
            <div class="h-px bg-gray-800/80 mt-1 mb-2"></div>
            <div class="space-y-3">
                <?php $__currentLoopData = $resume['certificates']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="flex items-center justify-between">
                        <div>
                            <div class="font-medium"><?php echo e($cert['name']); ?></div>
                            <div class="text-sm text-gray-600"><?php echo e($cert['issuer']); ?></div>
                        </div>
                        <div class="text-sm text-gray-500 flex items-center gap-2">
                            <?php if(!empty($cert['date'])): ?> <span><?php echo e($cert['date']); ?></span> <?php endif; ?>
                            <?php if(!empty($cert['url'])): ?> <a href="<?php echo e($cert['url']); ?>" class="text-indigo-600" target="_blank">Link</a> <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php endif; ?>

    <?php if(!empty($resume['projects'] ?? [])): ?>
        <div class="rounded-xl bg-white border border-gray-200 p-5 mb-4">
            <h2 class="text-[12px] font-semibold uppercase tracking-wider text-gray-700">Projects</h2>
            <div class="h-px bg-gray-800/80 mt-1 mb-2"></div>
            <div class="space-y-3">
                <?php $__currentLoopData = $resume['projects']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div>
                        <div class="font-medium"><?php echo e($p['title']); ?> <?php if(!empty($p['year'])): ?> <span class="text-gray-500">(<?php echo e($p['year']); ?>)</span> <?php endif; ?></div>
                        <?php if(!empty($p['description'])): ?>
                            <?php ($projLines = array_values(array_filter(array_map('trim', preg_split('/\r?\n/', (string)$p['description']))))); ?>
                            <?php if(count($projLines) > 1): ?>
                                <ul class="list-disc ml-3 mt-1 text-sm text-gray-700">
                                    <?php $__currentLoopData = $projLines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e(ltrim($line, "-• ")); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            <?php else: ?>
                                <div class="text-sm text-gray-700"><?php echo e($p['description']); ?></div>
                            <?php endif; ?>
                        <?php endif; ?>
                        <div class="text-xs text-gray-500 mt-1 flex items-center gap-2">
                            <?php if(!empty($p['github'])): ?> <a href="<?php echo e($p['github']); ?>" target="_blank" class="text-indigo-600">GitHub</a> <?php endif; ?>
                            <?php if(!empty($p['live'])): ?> <a href="<?php echo e($p['live']); ?>" target="_blank" class="text-indigo-600">Live</a> <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php endif; ?>

    <?php if(!empty($resume['skills'] ?? [])): ?>
        <div class="rounded-xl bg-white border border-gray-200 p-5">
            <h2 class="text-[12px] font-semibold uppercase tracking-wider text-gray-700">Skills</h2>
            <div class="h-px bg-gray-800/80 mt-1 mb-2"></div>
            <div class="flex flex-wrap gap-2">
                <?php $__currentLoopData = $resume['skills']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span class="px-3 py-1.5 text-sm rounded-md border border-gray-200 bg-gray-50"><?php echo e($skill['name']); ?></span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\portfolio\resources\views/resume.blade.php ENDPATH**/ ?>