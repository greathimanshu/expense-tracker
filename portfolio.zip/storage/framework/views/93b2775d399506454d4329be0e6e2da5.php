<div>
    <div class="mb-6">
        <h1 class="text-2xl font-bold">SEO Settings</h1>
        <p class="text-sm text-gray-600">Manage meta title, description, keywords and OG image.</p>
    </div>

    <!--[if BLOCK]><![endif]--><?php if(session('status')): ?>
        <div class="mb-4 rounded-md bg-green-50 p-3 text-green-700 text-sm"><?php echo e(session('status')); ?></div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <form wire:submit.prevent="save" class="space-y-5 max-w-3xl">
        <div>
            <label class="block text-sm font-medium text-gray-700">Meta Title</label>
            <input type="text" wire:model.defer="meta_title" class="mt-1 w-full rounded-md border-gray-300 focus:border-indigo-500 focus:ring-indigo-500" placeholder="Himanshu — Laravel Developer">
            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['meta_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-sm text-red-600 mt-1"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700">Meta Description</label>
            <textarea wire:model.defer="meta_description" rows="3" class="mt-1 w-full rounded-md border-gray-300 focus:border-indigo-500 focus:ring-indigo-500" placeholder="I build robust, secure Laravel apps: SaaS, payments, queues, APIs."></textarea>
            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['meta_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-sm text-red-600 mt-1"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700">Keywords (comma separated)</label>
            <input type="text" wire:model.defer="meta_keywords" class="mt-1 w-full rounded-md border-gray-300 focus:border-indigo-500 focus:ring-indigo-500" placeholder="Laravel, Livewire, PHP, MySQL, SaaS, Payment Gateway">
            <p class="text-xs text-gray-500 mt-1">Example: Laravel, Livewire, PHP, MySQL</p>
            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['meta_keywords'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-sm text-red-600 mt-1"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700">Open Graph Image URL</label>
            <input type="url" wire:model.defer="og_image" class="mt-1 w-full rounded-md border-gray-300 focus:border-indigo-500 focus:ring-indigo-500" placeholder="https://example.com/og.jpg">
            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['og_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-sm text-red-600 mt-1"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
        </div>

        <div class="pt-2">
            <button type="submit" class="inline-flex items-center rounded-md bg-indigo-600 px-4 py-2 text-white hover:bg-indigo-500">Save SEO</button>
        </div>
    </form>
</div>
<?php /**PATH C:\xampp\htdocs\portfolio\resources\views/livewire/admin/seo.blade.php ENDPATH**/ ?>