<!doctype html>
<html lang="en" class="h-full">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{{ $title ?? 'Portfolio' }} · Minimal Accent</title>
  <meta name="description" content="{{ $metaDescription ?? 'Laravel + Livewire portfolio SPA' }}">
  @isset($metaKeywords)
    <meta name="keywords" content="{{ $metaKeywords }}">
  @endisset
  <link rel="canonical" href="{{ url()->current() }}">

  <!-- Open Graph -->
  <meta property="og:type" content="website">
  <meta property="og:title" content="{{ $ogTitle ?? ($title ?? 'Portfolio') }}">
  <meta property="og:description" content="{{ $ogDescription ?? ($metaDescription ?? 'Laravel + Livewire portfolio SPA') }}">
  <meta property="og:url" content="{{ url()->current() }}">
  @isset($ogImage)
    <meta property="og:image" content="{{ $ogImage }}">
  @endisset

  <!-- Twitter -->
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="{{ $twitterTitle ?? ($title ?? 'Portfolio') }}">
  <meta name="twitter:description" content="{{ $twitterDescription ?? ($metaDescription ?? 'Laravel + Livewire portfolio SPA') }}">
  @isset($ogImage)
    <meta name="twitter:image" content="{{ $ogImage }}">
  @endisset
  @vite(['resources/css/app.css','resources/js/app.js'])
  @livewireStyles
</head>
<body class="h-full bg-white text-slate-800 antialiased">
  <div class="min-h-screen flex flex-col relative overflow-hidden">
    <div aria-hidden="true" class="pointer-events-none absolute inset-0 -z-10">
      <div class="absolute -left-16 top-0 h-72 w-72 rounded-full bg-gradient-to-br from-indigo-400/30 to-purple-400/30 blur-3xl"></div>
      <div class="absolute right-[-6rem] top-40 h-64 w-64 rounded-full bg-gradient-to-br from-fuchsia-300/30 to-sky-300/30 blur-3xl"></div>
    </div>
    @include('components.site.themes.minimal-accent.header')
    <main class="flex-1">{{ $slot }}</main>
    @include('components.site.themes.minimal-accent.footer')
  </div>
  @livewireScripts
</body>
</html>
