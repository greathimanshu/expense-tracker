<style>
  /* Animated gradient logo, subtle and classic */
  @keyframes logoShine { 0%{background-position:0% 50%} 50%{background-position:100% 50%} 100%{background-position:0% 50%} }
  .logo-anim {
    font-family: 'Cinzel', serif;
    letter-spacing: 0.5px;
    background: linear-gradient(90deg, #111827, #7c3aed, #a78bfa, #111827);
    background-size: 300% 100%;
    -webkit-background-clip: text;
    background-clip: text;
    color: transparent;
    animation: logoShine 10s linear infinite;
  }
  @media (prefers-reduced-motion: reduce) {
    .logo-anim { animation: none; }
  }
</style>
<?php (
  $__markSize = isset($markSize) ? (string) $markSize : '2em'
); ?>
<?php (
  $__pos = isset($markPos) ? (string) $markPos : 'left'
); ?>
<?php (
  $__posClass = $__pos === 'center' ? 'inset-0 bg-center' : '-inset-y-1 -left-3 bg-left'
); ?>
<a href="<?php echo e(route('portfolio')); ?>" class="<?php echo e($class ?? 'font-semibold text-lg'); ?>" aria-label="Himanshu - Home">
  <span class="relative inline-block">
    <span aria-hidden="true" class="pointer-events-none absolute -z-10 opacity-20 dark:opacity-10 bg-no-repeat bg-contain <?php echo e($__posClass); ?>"
          style="background-image:url('https://laravel.com/img/logomark.min.svg'); width:<?php echo e($__markSize); ?>; height:<?php echo e($__markSize); ?>;"></span>
    <span class="logo-anim relative">Himanshu</span>
  </span>
</a>
<?php /**PATH C:\xampp\htdocs\portfolio\resources\views/components/site/logo.blade.php ENDPATH**/ ?>