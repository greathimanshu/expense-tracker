<div>
  <div class="flex items-center justify-between mb-6">
    <h1 class="text-2xl font-bold">Skills</h1>
    <a href="<?php echo e(route('admin.dashboard')); ?>" class="text-sm text-indigo-600">Back to Dashboard</a>
  </div>

  <!--[if BLOCK]><![endif]--><?php if(session('status')): ?>
    <div class="mb-4 rounded-md bg-green-50 text-green-800 px-4 py-2 text-sm"><?php echo e(session('status')); ?></div>
  <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

  <form wire:submit.prevent="save" class="space-y-4 bg-white rounded-xl border border-gray-200 p-6 mb-6">
    <div class="grid md:grid-cols-4 gap-4">
      <div class="md:col-span-2">
        <label class="block text-sm text-gray-600 mb-1">Name</label>
        <input type="text" wire:model="name" class="w-full rounded-md border border-gray-300 px-3 py-2" />
        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-sm text-red-600 mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
      </div>
      <div>
        <label class="block text-sm text-gray-600 mb-1">Category</label>
        <input type="text" wire:model="category" class="w-full rounded-md border border-gray-300 px-3 py-2" />
        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-sm text-red-600 mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
      </div>
      <div>
        <label class="block text-sm text-gray-600 mb-1">Proficiency (%)</label>
        <input type="number" wire:model="proficiency" min="0" max="100" class="w-full rounded-md border border-gray-300 px-3 py-2" />
        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['proficiency'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-sm text-red-600 mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
      </div>
      <div>
        <label class="block text-sm text-gray-600 mb-1">Order</label>
        <input type="number" wire:model="order" min="0" class="w-full rounded-md border border-gray-300 px-3 py-2" />
        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['order'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-sm text-red-600 mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
      </div>
    </div>
    <div class="flex items-center gap-3">
      <button type="submit" class="px-4 py-2 rounded-md bg-indigo-600 text-white">Save</button>
      <button type="button" wire:click="createNew" class="px-4 py-2 rounded-md border">Clear</button>
    </div>
  </form>

  <div class="bg-white rounded-xl border border-gray-200">
    <table class="min-w-full text-sm">
      <thead class="bg-gray-50 text-gray-600">
        <tr>
          <th class="px-4 py-3 text-left">Name</th>
          <th class="px-4 py-3 text-left">Category</th>
          <th class="px-4 py-3">Proficiency</th>
          <th class="px-4 py-3">Order</th>
          <th class="px-4 py-3">Actions</th>
        </tr>
      </thead>
      <tbody class="divide-y">
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $it): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td class="px-4 py-3"><?php echo e($it->name); ?></td>
            <td class="px-4 py-3"><?php echo e($it->category); ?></td>
            <td class="px-4 py-3 text-center"><?php echo e($it->proficiency); ?>%</td>
            <td class="px-4 py-3 text-center"><?php echo e($it->order); ?></td>
            <td class="px-4 py-3 text-right space-x-2">
              <button wire:click="edit(<?php echo e($it->id); ?>)" class="text-indigo-600">Edit</button>
              <button wire:click="delete(<?php echo e($it->id); ?>)" class="text-red-600">Delete</button>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
      </tbody>
    </table>
    <div class="p-3"><?php echo e($items->links()); ?></div>
  </div>
</div>
<?php /**PATH C:\xampp\htdocs\portfolio\resources\views/livewire/admin/skills.blade.php ENDPATH**/ ?>