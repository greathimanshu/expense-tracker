<?php

namespace App\Livewire\Admin;

use App\Models\SocialLink;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Validate;
use Livewire\Component;

class SocialLinks extends Component
{
    public ?int $editingId = null;

    #[Validate('required|string|min:2')]
    public string $label = '';
    #[Validate('required|string')]
    public string $url = '';
    #[Validate('nullable|string|max:50')]
    public ?string $icon = null;
    #[Validate('nullable|integer|min:0')]
    public ?int $order = 0;

    public function updated($field): void
    {
        $this->validateOnly($field);
    }

    public function edit(int $id): void
    {
        $s = SocialLink::findOrFail($id);
        $this->editingId = $s->id;
        $this->label = (string) $s->label;
        $this->url = (string) $s->url;
        $this->icon = $s->icon;
        $this->order = $s->order;
    }

    public function createNew(): void
    {
        $this->reset(['editingId','label','url','icon','order']);
        $this->order = 0;
    }

    public function save(): void
    {
        $this->validate();
        $data = $this->only(['label','url','icon','order']);
        SocialLink::updateOrCreate(['id' => $this->editingId], $data);
        session()->flash('status', 'Social link saved.');
        $this->createNew();
    }

    public function delete(int $id): void
    {
        SocialLink::whereKey($id)->delete();
        session()->flash('status', 'Social link deleted.');
    }

    #[Layout('layouts.admin')]
    public function render()
    {
        return view('livewire.admin.social-links', [
            'items' => SocialLink::orderBy('order')->orderBy('label')->paginate(20),
        ]);
    }
}
