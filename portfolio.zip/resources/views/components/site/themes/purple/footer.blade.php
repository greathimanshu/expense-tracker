<footer class="mt-8 border-t border-purple-100/70 bg-white/70 backdrop-blur">
  <div class="h-1 w-full" style="background:linear-gradient(90deg,#7c3aed,#a78bfa,#c084fc,#7c3aed); background-size:300% 100%; animation: gradientShift 10s linear infinite"></div>
  <div class="container mx-auto max-w-6xl px-4 py-8 text-sm text-slate-700 flex items-center justify-between">
    <p>&copy; {{ date('Y') }} {{ config('app.name') }} · Purple</p>
    <a href="#top" class="hover:text-purple-700">Back to top ↑</a>
  </div>
</footer>
