<footer class="border-t border-gray-100 bg-white/80 backdrop-blur">
  <div class="container mx-auto max-w-6xl px-4 py-8 text-sm text-slate-600 flex items-center justify-between">
    <p>&copy; <?php echo e(date('Y')); ?> <?php echo e(config('app.name')); ?> · Minimal + Accent</p>
    <a href="#top" class="hover:text-indigo-600">Back to top ↑</a>
  </div>
</footer>
<?php /**PATH C:\xampp\htdocs\portfolio\resources\views/components/site/themes/minimal-accent/footer.blade.php ENDPATH**/ ?>