<footer class="border-t border-gray-200 bg-white">
  <div class="container mx-auto max-w-6xl px-4 py-8 text-sm text-slate-600 flex items-center justify-between">
    <p>&copy; {{ date('Y') }} {{ config('app.name') }}. All rights reserved.</p>
    <a href="#top" class="hover:text-indigo-600">Back to top ↑</a>
  </div>
</footer>
