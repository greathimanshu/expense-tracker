<?php

namespace App\Livewire\Admin;

use App\Models\Testimonial;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Validate;
use Livewire\Component;

class Testimonials extends Component
{
    public ?int $editingId = null;

    #[Validate('required|string|min:2')]
    public string $author = '';
    #[Validate('nullable|string|max:100')]
    public ?string $role = null;
    #[Validate('nullable|string|max:100')]
    public ?string $company = null;
    #[Validate('required|string|max:1000')]
    public string $quote = '';
    #[Validate('nullable|url')]
    public ?string $avatar_url = null;
    #[Validate('nullable|integer|min:0')]
    public ?int $order = 0;

    public function edit(int $id): void
    {
        $t = Testimonial::findOrFail($id);
        $this->editingId = $t->id;
        $this->author = (string) $t->author;
        $this->role = $t->role;
        $this->company = $t->company;
        $this->quote = (string) $t->quote;
        $this->avatar_url = $t->avatar_url;
        $this->order = $t->order;
    }

    public function createNew(): void
    {
        $this->reset(['editingId','author','role','company','quote','avatar_url','order']);
        $this->order = 0;
    }

    public function save(): void
    {
        $this->validate();
        $data = $this->only(['author','role','company','quote','avatar_url','order']);
        Testimonial::updateOrCreate(['id' => $this->editingId], $data);
        session()->flash('status', 'Testimonial saved.');
        $this->createNew();
    }

    public function delete(int $id): void
    {
        Testimonial::whereKey($id)->delete();
        session()->flash('status', 'Testimonial deleted.');
    }

    #[Layout('layouts.admin')]
    public function render()
    {
        return view('livewire.admin.testimonials', [
            'items' => Testimonial::orderBy('order')->orderBy('author')->paginate(12),
        ]);
    }
}
