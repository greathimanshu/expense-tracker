<div class="container mx-auto max-w-3xl px-4 py-6">
    <div class="flex items-center justify-between mb-6">
        <div>
            <h1 class="text-3xl font-bold tracking-tight">{{ $resume['basics']['name'] ?? 'Resume' }}</h1>
            @if(!empty($resume['basics']['label']))
                <p class="text-sm text-gray-600">{{ $resume['basics']['label'] }}</p>
            @endif
        </div>
        <div class="flex items-center gap-2">
            <a href="{{ route('resume.json') }}" class="px-3 py-1.5 text-sm rounded-md border border-gray-200 hover:bg-gray-50">JSON</a>
            <a href="{{ route('resume.markdown') }}" class="px-3 py-1.5 text-sm rounded-md bg-indigo-600 text-white hover:bg-indigo-500">Download .md</a>
            <a href="{{ route('resume.pdf') }}" class="px-3 py-1.5 text-sm rounded-md bg-violet-600 text-white hover:bg-violet-500">Download PDF</a>
        </div>
    </div>

    @php
        $fmt = function($d) {
            try { return $d ? \Carbon\Carbon::parse($d)->format('m/Y') : null; } catch (\Exception $e) { return $d; }
        };
    @endphp
    <div class="rounded-xl bg-white border border-gray-200 p-5 mb-4">
        <h2 class="text-[12px] font-semibold uppercase tracking-wider text-gray-700">About</h2>
        <div class="h-px bg-gray-800/80 mt-1"></div>
        @if(!empty($resume['basics']['summary'] ?? null))
            <p class="text-gray-700">{{ $resume['basics']['summary'] }}</p>
        @else
            <p class="text-gray-500">No summary provided.</p>
        @endif
        <div class="mt-4 text-sm text-gray-600 space-y-1">
            @if(!empty($resume['basics']['email'] ?? null))
                <div>Email: <a href="mailto:{!! $resume['basics']['email'] !!}" class="text-indigo-600">{{ $resume['basics']['email'] }}</a></div>
            @endif
            @if(!empty($resume['basics']['url'] ?? null))
                <div>Website: <a href="{{ $resume['basics']['url'] }}" class="text-indigo-600" target="_blank" rel="noreferrer">{{ $resume['basics']['url'] }}</a></div>
            @endif
            @if(!empty(($resume['basics']['location']['city'] ?? null)))
                <div>Location: {{ $resume['basics']['location']['city'] }}</div>
            @endif
            @php
                $gh = null;
                foreach (($resume['basics']['profiles'] ?? []) as $p) {
                    $net = strtolower($p['network'] ?? '');
                    $url = strtolower($p['url'] ?? '');
                    if ($net === 'github' || str_contains($url, 'github.com')) { $gh = $p; break; }
                }
            @endphp
            @if($gh)
                <div>GitHub: <a href="{{ $gh['url'] ?? '#' }}" class="text-indigo-600" target="_blank" rel="noreferrer">{{ $gh['username'] ?? ($gh['url'] ?? 'GitHub') }}</a></div>
            @endif
        </div>
        @if(!empty($resume['basics']['profiles'] ?? []))
            <div class="mt-3 flex flex-wrap gap-2 text-sm">
                @foreach($resume['basics']['profiles'] as $profile)
                    @php($u = strtolower($profile['url'] ?? ''))
                    @php($name = trim(strtolower($profile['username'] ?? '')))
                    @if($u && !str_contains($u, 'example.com') && $name !== 'yourname' && !(strtolower($profile['network'] ?? '') === 'github' || str_contains($u, 'github.com')))
                        <a href="{{ $profile['url'] }}" class="px-2 py-1 rounded-md border border-indigo-200 text-indigo-700 hover:bg-indigo-50" target="_blank" rel="noreferrer">{{ $profile['username'] }}</a>
                    @endif
                @endforeach
            </div>
        @endif
    </div>

    @if(!empty($resume['work'] ?? []))
        <div class="rounded-xl bg-white border border-gray-200 p-5 mb-4">
            <h2 class="text-[12px] font-semibold uppercase tracking-wider text-gray-700">Experience</h2>
            <div class="h-px bg-gray-800/80 mt-1 mb-2"></div>
            <div class="space-y-3">
                @foreach($resume['work'] as $work)
                    <div>
                        <div class="flex items-center justify-between">
                            <div class="font-medium">{{ $work['position'] }} · {{ $work['company'] }}</div>
                            <div class="text-sm text-gray-500">{{ $fmt($work['startDate']) }} — {{ $fmt($work['endDate']) ?? 'Present' }}</div>
                        </div>
                        @if(!empty($work['summary']))
                            @php($lines = array_values(array_filter(array_map('trim', preg_split('/\r?\n/', (string)$work['summary'])))))
                            @if(count($lines) > 1)
                                <ul class="list-disc ml-3 mt-1 text-sm text-gray-700">
                                    @foreach($lines as $line)
                                        <li>{{ ltrim($line, "-• ") }}</li>
                                    @endforeach
                                </ul>
                            @else
                                <p class="text-sm text-gray-700 mt-1">{{ $work['summary'] }}</p>
                            @endif
                        @endif
                    </div>
                @endforeach
            </div>
        </div>
    @endif

    @if(!empty($resume['education'] ?? []))
        <div class="rounded-xl bg-white border border-gray-200 p-5 mb-4">
            <h2 class="text-[12px] font-semibold uppercase tracking-wider text-gray-700">Education</h2>
            <div class="h-px bg-gray-800/80 mt-1 mb-2"></div>
            <div class="space-y-3">
                @foreach($resume['education'] as $edu)
                    <div>
                        <div class="flex items-center justify-between">
                            <div class="font-medium">{{ $edu['studyType'] }} @if(!empty($edu['area'])) · {{ $edu['area'] }} @endif</div>
                            <div class="text-sm text-gray-500">
                                @if(!empty($edu['startDate'])) {{ $fmt($edu['startDate']) }} @endif — @if(!empty($edu['endDate'])) {{ $fmt($edu['endDate']) }} @else Present @endif
                            </div>
                        </div>
                        <div class="text-sm text-gray-600">{{ $edu['institution'] }}</div>
                    </div>
                @endforeach
            </div>
        </div>
    @endif

    @if(!empty($resume['certificates'] ?? []))
        <div class="rounded-xl bg-white border border-gray-200 p-5 mb-4">
            <h2 class="text-[12px] font-semibold uppercase tracking-wider text-gray-700">Certificates</h2>
            <div class="h-px bg-gray-800/80 mt-1 mb-2"></div>
            <div class="space-y-3">
                @foreach($resume['certificates'] as $cert)
                    <div class="flex items-center justify-between">
                        <div>
                            <div class="font-medium">{{ $cert['name'] }}</div>
                            <div class="text-sm text-gray-600">{{ $cert['issuer'] }}</div>
                        </div>
                        <div class="text-sm text-gray-500 flex items-center gap-2">
                            @if(!empty($cert['date'])) <span>{{ $cert['date'] }}</span> @endif
                            @if(!empty($cert['url'])) <a href="{{ $cert['url'] }}" class="text-indigo-600" target="_blank">Link</a> @endif
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    @endif

    @if(!empty($resume['projects'] ?? []))
        <div class="rounded-xl bg-white border border-gray-200 p-5 mb-4">
            <h2 class="text-[12px] font-semibold uppercase tracking-wider text-gray-700">Projects</h2>
            <div class="h-px bg-gray-800/80 mt-1 mb-2"></div>
            <div class="space-y-3">
                @foreach($resume['projects'] as $p)
                    <div>
                        <div class="font-medium">{{ $p['title'] }} @if(!empty($p['year'])) <span class="text-gray-500">({{ $p['year'] }})</span> @endif</div>
                        @if(!empty($p['description']))
                            @php($projLines = array_values(array_filter(array_map('trim', preg_split('/\r?\n/', (string)$p['description'])))))
                            @if(count($projLines) > 1)
                                <ul class="list-disc ml-3 mt-1 text-sm text-gray-700">
                                    @foreach($projLines as $line)
                                        <li>{{ ltrim($line, "-• ") }}</li>
                                    @endforeach
                                </ul>
                            @else
                                <div class="text-sm text-gray-700">{{ $p['description'] }}</div>
                            @endif
                        @endif
                        <div class="text-xs text-gray-500 mt-1 flex items-center gap-2">
                            @if(!empty($p['github'])) <a href="{{ $p['github'] }}" target="_blank" class="text-indigo-600">GitHub</a> @endif
                            @if(!empty($p['live'])) <a href="{{ $p['live'] }}" target="_blank" class="text-indigo-600">Live</a> @endif
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    @endif

    @if(!empty($resume['skills'] ?? []))
        <div class="rounded-xl bg-white border border-gray-200 p-5">
            <h2 class="text-[12px] font-semibold uppercase tracking-wider text-gray-700">Skills</h2>
            <div class="h-px bg-gray-800/80 mt-1 mb-2"></div>
            <div class="flex flex-wrap gap-2">
                @foreach($resume['skills'] as $skill)
                    <span class="px-3 py-1.5 text-sm rounded-md border border-gray-200 bg-gray-50">{{ $skill['name'] }}</span>
                @endforeach
            </div>
        </div>
    @endif
</div>
