<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Education;

class EducationSeeder extends Seeder
{
    public function run(): void
    {
        // Idempotent upserts based on institution + study_type
        Education::updateOrCreate([
            'institution' => 'Punjabi University Patiala',
            'study_type' => 'Bachelor of Commerce Application (B.C.A)'
        ], [
            'area' => 'Computer Applications',
            'start_date' => '2017-05-01',
            'end_date' => '2019-07-01',
            'order' => 1,
        ]);

        Education::updateOrCreate([
            'institution' => 'Punjab School Education Board (P.S.E.B)',
            'study_type' => 'High School'
        ], [
            'area' => null,
            'start_date' => '2017-06-01',
            'end_date' => '2018-04-01',
            'order' => 2,
        ]);

        Education::updateOrCreate([
            'institution' => 'Punjab School Education Board (P.S.E.B)',
            'study_type' => 'Intermediate'
        ], [
            'area' => null,
            'start_date' => '2015-03-01',
            'end_date' => '2016-06-01',
            'order' => 3,
        ]);
    }
}
