<header class="sticky top-0 z-40 backdrop-blur bg-white/70 border-b border-gray-100">
    <?php
        $isHome = request()->routeIs('portfolio');
        $home = route('portfolio');
        // Try to use Profile name if APP_NAME is default
        $appName = config('app.name');
        if ($appName === 'Laravel') {
            try {
                $profileName = \App\Models\Profile::query()->value('name');
                if ($profileName) { $appName = $profileName; }
            } catch (\Throwable $e) {}
        }
    ?>
    <div class="container mx-auto max-w-6xl px-4 py-3 flex items-center justify-between">
        <?php echo $__env->make('components.site.logo', ['class' => 'text-xl'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <nav class="hidden md:flex items-center gap-6 text-sm">
            <a href="<?php echo e($isHome ? '#projects' : $home . '#projects'); ?>" <?php if(!$isHome): ?> wire:navigate <?php endif; ?> class="hover:text-[#6366f1]">Projects</a>
            <a href="<?php echo e($isHome ? '#experience' : $home . '#experience'); ?>" <?php if(!$isHome): ?> wire:navigate <?php endif; ?> class="hover:text-[#6366f1]">Experience</a>
            <a href="<?php echo e($isHome ? '#skills' : $home . '#skills'); ?>" <?php if(!$isHome): ?> wire:navigate <?php endif; ?> class="hover:text-[#6366f1]">Skills</a>
            <a href="<?php echo e($isHome ? '#contact' : $home . '#contact'); ?>" <?php if(!$isHome): ?> wire:navigate <?php endif; ?> class="hover:text-[#6366f1]">Contact</a>
            <a href="<?php echo e(route('resume.view')); ?>" wire:navigate class="hover:text-[#6366f1]">Resume</a>
        </nav>

        <div class="flex items-center gap-2">
            <!-- <button type="button" data-toggle-theme class="hidden md:inline-flex items-center justify-center rounded-md border border-gray-200/80 px-3 py-1.5 text-sm hover:bg-gray-50 text-gray-700">
                <span class="dark:hidden">🌙 Dark</span>
                <span class="hidden dark:inline">☀️ Light</span>
            </button> -->
            <button type="button" data-mobile-menu-toggle class="md:hidden inline-flex items-center justify-center rounded-md border border-gray-200/80 p-2 text-gray-700 hover:bg-gray-50" aria-label="Toggle navigation">
                ☰
            </button>
        </div>
    </div>

    <!-- Mobile menu -->
    <div id="mobileMenu" class="md:hidden hidden border-t border-gray-100 bg-white/90">
        <div class="container mx-auto max-w-6xl px-4 py-3 space-y-2 text-sm">
            <a href="<?php echo e($isHome ? '#projects' : $home . '#projects'); ?>" <?php if(!$isHome): ?> wire:navigate <?php endif; ?> class="block hover:text-[#6366f1]">Projects</a>
            <a href="<?php echo e($isHome ? '#experience' : $home . '#experience'); ?>" <?php if(!$isHome): ?> wire:navigate <?php endif; ?> class="block hover:text-[#6366f1]">Experience</a>
            <a href="<?php echo e($isHome ? '#skills' : $home . '#skills'); ?>" <?php if(!$isHome): ?> wire:navigate <?php endif; ?> class="block hover:text-[#6366f1]">Skills</a>
            <a href="<?php echo e($isHome ? '#contact' : $home . '#contact'); ?>" <?php if(!$isHome): ?> wire:navigate <?php endif; ?> class="block hover:text-[#6366f1]">Contact</a>
            <a href="<?php echo e(route('resume.view')); ?>" wire:navigate class="block hover:text-[#6366f1]">Resume</a>
            <!-- <button type="button" data-toggle-theme class="mt-2 inline-flex items-center justify-center rounded-md border border-gray-200/80 px-3 py-1.5 text-sm hover:bg-gray-50 text-gray-700">
                <span class="dark:hidden">🌙 Dark</span>
                <span class="hidden dark:inline">☀️ Light</span>
            </button> -->
        </div>
    </div>
</header>
<?php /**PATH C:\xampp\htdocs\portfolio\resources\views/components/site/header.blade.php ENDPATH**/ ?>