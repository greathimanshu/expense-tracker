<header class="sticky top-0 z-40 backdrop-blur bg-white/70 border-b border-gray-100">
    <div class="container mx-auto max-w-6xl px-4 py-3 flex items-center justify-between">
        <a href="<?php echo e(route('portfolio')); ?>" class="font-semibold text-xl hover:text-[#6366f1] transition-colors"><?php echo e(config('app.name', 'My Portfolio')); ?></a>

        <nav class="hidden md:flex items-center gap-6 text-sm">
            <a href="#projects" class="hover:text-[#6366f1]">Projects</a>
            <a href="#experience" class="hover:text-[#6366f1]">Experience</a>
            <a href="#skills" class="hover:text-[#6366f1]">Skills</a>
            <a href="#contact" class="hover:text-[#6366f1]">Contact</a>
            <a href="<?php echo e(route('resume.view')); ?>" class="hover:text-[#6366f1]">Resume</a>
        </nav>

        <div class="flex items-center gap-2">
            <!-- <button type="button" data-toggle-theme class="hidden md:inline-flex items-center justify-center rounded-md border border-gray-200/80 px-3 py-1.5 text-sm hover:bg-gray-50 text-gray-700">
                <span class="dark:hidden">🌙 Dark</span>
                <span class="hidden dark:inline">☀️ Light</span>
            </button> -->
            <button type="button" data-mobile-menu-toggle class="md:hidden inline-flex items-center justify-center rounded-md border border-gray-200/80 p-2 text-gray-700 hover:bg-gray-50" aria-label="Toggle navigation">
                ☰
            </button>
        </div>
    </div>

    <!-- Mobile menu -->
    <div id="mobileMenu" class="md:hidden hidden border-t border-gray-100 bg-white/90">
        <div class="container mx-auto max-w-6xl px-4 py-3 space-y-2 text-sm">
            <a href="#projects" class="block hover:text-[#6366f1]">Projects</a>
            <a href="#experience" class="block hover:text-[#6366f1]">Experience</a>
            <a href="#skills" class="block hover:text-[#6366f1]">Skills</a>
            <a href="#contact" class="block hover:text-[#6366f1]">Contact</a>
            <a href="<?php echo e(route('resume.view')); ?>" class="block hover:text-[#6366f1]">Resume</a>
            <!-- <button type="button" data-toggle-theme class="mt-2 inline-flex items-center justify-center rounded-md border border-gray-200/80 px-3 py-1.5 text-sm hover:bg-gray-50 text-gray-700">
                <span class="dark:hidden">🌙 Dark</span>
                <span class="hidden dark:inline">☀️ Light</span>
            </button> -->
        </div>
    </div>
</header>
<?php /**PATH C:\xampp\htdocs\portfolio\resources\views/components/site/header.blade.php ENDPATH**/ ?>