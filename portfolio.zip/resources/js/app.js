import './bootstrap';

function getPreferredTheme() {
    const saved = localStorage.getItem('theme');
    if (saved === 'light' || saved === 'dark') return saved;
    return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
}

// Typewriter effect for elements with [data-typewriter]
function initTypewriter() {
    const els = document.querySelectorAll('[data-typewriter]');
    if (!els.length) return;
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    els.forEach(el => {
        const phrases = (el.getAttribute('data-phrases') || el.textContent || '').split('|').filter(Boolean);
        const loop = (el.getAttribute('data-loop') || 'true') === 'true';
        const speed = parseInt(el.getAttribute('data-speed') || '48', 10); // ms per char
        const delay = parseInt(el.getAttribute('data-delay') || '1000', 10); // pause between phrases
        if (!phrases.length) return;

        // If reduced motion, just set first phrase and return
        if (reduce) { el.textContent = phrases[0]; return; }

        let i = 0; let ch = 0; let deleting = false; let rafId = null; let last = 0;
        const step = (ts) => {
            if (!last) last = ts;
            const dt = ts - last;
            if (dt < speed) { rafId = requestAnimationFrame(step); return; }
            last = ts;
            const phrase = phrases[i];
            if (!deleting) {
                ch++;
                el.textContent = phrase.slice(0, ch);
                if (ch >= phrase.length) { deleting = true; last -= (delay - speed); }
            } else {
                ch--;
                el.textContent = phrase.slice(0, Math.max(ch, 0));
                if (ch <= 0) {
                    deleting = false;
                    i = (i + 1) % phrases.length;
                    if (!loop && i === 0) { cancelAnimationFrame(rafId); return; }
                }
            }
            rafId = requestAnimationFrame(step);
        };
        cancelAnimationFrame(rafId);
        rafId = requestAnimationFrame(step);
    });
}

// Top scroll progress bar
function initScrollProgress() {
    const bar = document.getElementById('scrollProgress');
    if (!bar) return;
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    let ticking = false;
    const update = () => {
        const doc = document.documentElement;
        const h = doc.scrollHeight - window.innerHeight;
        const p = h > 0 ? (window.scrollY / h) : 0;
        bar.style.width = `${(p * 100).toFixed(2)}%`;
        ticking = false;
    };
    const onScroll = () => {
        if (ticking) return; ticking = true;
        (reduce ? update : requestAnimationFrame.bind(window))(update);
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('resize', onScroll);
    update();
}

// Magnetic hover for elements with [data-magnetic]
function initMagneticHover() {
    const items = document.querySelectorAll('[data-magnetic]');
    if (!items.length) return;
    const strength = 0.25; // lower = stronger pull
    items.forEach((el) => {
        const target = el.querySelector('.magnetic-target') || el;
        let rafId = null;
        const animateTo = (x, y) => {
            if (rafId) cancelAnimationFrame(rafId);
            const step = () => {
                const cur = target._mag || { x: 0, y: 0 };
                const nx = cur.x + (x - cur.x) * (1 - strength);
                const ny = cur.y + (y - cur.y) * (1 - strength);
                target._mag = { x: nx, y: ny };
                target.style.transform = `translate3d(${nx.toFixed(1)}px, ${ny.toFixed(1)}px, 0)`;
                if (Math.abs(nx - x) > 0.5 || Math.abs(ny - y) > 0.5) {
                    rafId = requestAnimationFrame(step);
                }
            };
            rafId = requestAnimationFrame(step);
        };
        const onMove = (e) => {
            const r = el.getBoundingClientRect();
            const x = (e.clientX - (r.left + r.width / 2)) * 0.25;
            const y = (e.clientY - (r.top + r.height / 2)) * 0.25;
            animateTo(x, y);
        };
        const onLeave = () => animateTo(0, 0);
        el.addEventListener('mousemove', onMove);
        el.addEventListener('mouseleave', onLeave);
        el.addEventListener('blur', onLeave, true);
    });
}

// Staggered reveal: container [data-stagger] reveals children sequentially
function initStaggerReveal() {
    const containers = document.querySelectorAll('[data-stagger]');
    if (!containers.length) return;
    const io = new IntersectionObserver((entries) => {
        entries.forEach((e) => {
            if (!e.isIntersecting) return;
            const el = e.target;
            const delay = parseInt(el.getAttribute('data-stagger'), 10) || 60;
            const children = Array.from(el.children);
            children.forEach((child, i) => {
                child.style.transitionDelay = `${i * delay}ms`;
                child.classList.add('in-view');
            });
            io.unobserve(el);
        });
    }, { threshold: 0.12 });
    containers.forEach((c) => io.observe(c));
}

// Parallax background and drifting blobs (horizontal + rotation)
function initParallaxBackground() {
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reduce) return;

    const grad = document.querySelector('.bg-animated-gradient');
    const mask = document.querySelector('.bg-radial-mask');
    const blobs = Array.from(document.querySelectorAll('.blob'));
    if (!grad && !mask && !blobs.length) return;

    // Randomized drift configuration per blob
    const blobsCfg = blobs.map((b, i) => ({
        el: b,
        pf: 0.05 + i * 0.015,              // vertical parallax factor (lower = calmer)
        ax: 6 + Math.random() * 6,         // horizontal amplitude (px)
        wx: 0.2 + Math.random() * 0.3,     // horizontal angular speed (rad/s)
        ar: 1 + Math.random() * 1.2,       // rotation amplitude (deg)
        wr: 0.15 + Math.random() * 0.25,   // rotation speed (rad/s)
        phx: Math.random() * Math.PI * 2,  // horizontal phase
        phr: Math.random() * Math.PI * 2,  // rotation phase
    }));

    let ticking = false;
    let start = performance.now();

    const onScroll = () => {
        if (ticking) return; ticking = true;
        requestAnimationFrame(() => {
            const y = window.scrollY || window.pageYOffset;
            if (grad) grad.style.transform = `translateY(${(y * 0.03).toFixed(2)}px)`;
            if (mask) mask.style.transform = `translateY(${(y * 0.015).toFixed(2)}px)`;
            ticking = false;
        });
    };

    const animate = (t) => {
        const time = (t - start) / 1000; // seconds
        const y = window.scrollY || window.pageYOffset;
        blobsCfg.forEach(cfg => {
            const driftX = Math.sin(time * cfg.wx + cfg.phx) * cfg.ax; // px
            const rot = Math.sin(time * cfg.wr + cfg.phr) * cfg.ar;    // deg
            const ty = y * cfg.pf;                                     // px
            cfg.el.style.transform = `translate3d(${driftX.toFixed(1)}px, ${ty.toFixed(1)}px, 0) rotate(${rot.toFixed(2)}deg)`;
            cfg.el.style.willChange = 'transform';
        });
        requestAnimationFrame(animate);
    };

    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
    requestAnimationFrame(animate);
}

// Smooth scroll for anchor links with header offset
function initSmoothAnchors() {
    const prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const links = Array.from(document.querySelectorAll('a[href^="#"]'))
        .filter(a => a.getAttribute('href') && a.getAttribute('href') !== '#');
    if (!links.length) return;

    const getOffset = () => {
        const header = document.querySelector('header');
        if (!header) return 0;
        const style = window.getComputedStyle(header);
        const isFixed = style.position === 'fixed' || header.classList.contains('fixed') || header.classList.contains('sticky');
        return isFixed ? header.offsetHeight : 0;
    };

    const scrollToTarget = (el) => {
        const offset = getOffset();
        const rect = el.getBoundingClientRect();
        const top = rect.top + window.scrollY - offset - 8; // extra padding
        if (prefersReduced) {
            window.scrollTo(0, top);
        } else {
            window.scrollTo({ top, behavior: 'smooth' });
        }
        // focus for accessibility
        el.setAttribute('tabindex', '-1');
        el.focus({ preventScroll: true });
    };

    links.forEach(link => {
        link.addEventListener('click', (e) => {
            const hash = link.getAttribute('href');
            const target = document.querySelector(hash);
            if (!target) return;
            e.preventDefault();
            scrollToTarget(target);
            history.pushState(null, '', hash);
        });
    });
}

// Blur-up effect: remove blur when image fully loads
function initBlurUp() {
    const imgs = document.querySelectorAll('img.blur-up');
    imgs.forEach((img) => {
        if (img.complete) {
            img.classList.add('loaded');
        } else {
            img.addEventListener('load', () => img.classList.add('loaded'), { once: true });
        }
    });
}

// Subtle 3D tilt for elements marked with [data-tilt]
function initTilt() {
    const cards = document.querySelectorAll('[data-tilt]');
    if (!cards.length) return;
    const maxTilt = 6; // degrees
    cards.forEach((card) => {
        const img = card.querySelector('.tilt-img') || card.firstElementChild;
        if (!img) return;
        const onMove = (e) => {
            const rect = card.getBoundingClientRect();
            const px = (e.clientX - rect.left) / rect.width;
            const py = (e.clientY - rect.top) / rect.height;
            const rx = (py - 0.5) * -2 * maxTilt;
            const ry = (px - 0.5) * 2 * maxTilt;
            img.style.transform = `perspective(800px) rotateX(${rx.toFixed(2)}deg) rotateY(${ry.toFixed(2)}deg) scale(1.02)`;
        };
        const reset = () => {
            img.style.transform = '';
        };
        card.addEventListener('mousemove', onMove);
        card.addEventListener('mouseleave', reset);
    });
}

// Mobile hamburger menu for public header
function initMobileNav() {
    const btn = document.querySelector('[data-mobile-menu-toggle]');
    const menu = document.getElementById('mobileMenu');
    if (!btn || !menu) return;
    const open = () => {
        menu.classList.remove('hidden');
        document.body.style.overflow = 'hidden';
    };
    const close = () => {
        menu.classList.add('hidden');
        document.body.style.overflow = '';
    };
    const toggle = () => (menu.classList.contains('hidden') ? open() : close());
    btn.addEventListener('click', toggle);
    // close on any link click inside menu
    menu.querySelectorAll('a').forEach((a) => a.addEventListener('click', close));
    // auto-close after Livewire SPA navigation completes
    document.addEventListener('livewire:navigated', close);
}

function applyTheme(theme) {
    const root = document.documentElement;
    root.dataset.theme = theme;
    // Ensure Tailwind dark: variants work by toggling the 'dark' class
    root.classList.toggle('dark', theme === 'dark');
    localStorage.setItem('theme', theme);
}

function toggleTheme() {
    const next = (document.documentElement.dataset.theme === 'dark') ? 'light' : 'dark';
    applyTheme(next);
}

function initThemeToggle() {
    const forced = document.documentElement.dataset.adminTheme;
    if (forced === 'light') {
        applyTheme('light');
        const btns = document.querySelectorAll('[data-toggle-theme]');
        btns.forEach((btn) => {
            btn.setAttribute('disabled', 'disabled');
            btn.classList.add('opacity-50', 'cursor-not-allowed');
        });
        return;
    }
    applyTheme(getPreferredTheme());
    const btns = document.querySelectorAll('[data-toggle-theme]');
    btns.forEach((btn) => btn.addEventListener('click', toggleTheme));
    // Signal that the main bundle initialized theme toggle handlers
    try { window.__themeBundleInit = true; } catch (e) {}
}

function initReveal() {
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reduce) return; // CSS will show content without animations
    const els = document.querySelectorAll('.reveal');
    if (!els.length) return;
    const io = new IntersectionObserver((entries) => {
        entries.forEach((e) => {
            if (e.isIntersecting) {
                e.target.classList.add('in-view');
                io.unobserve(e.target);
            }
        });
    }, { threshold: 0.12 });
    els.forEach((el) => io.observe(el));
}

function initAll() {
    initThemeToggle();
    initReveal();
    initAdminSidebar();
    initTilt();
    initMobileNav();
    initBlurUp();
    initSmoothAnchors();
    initParallaxBackground();
    initScrollProgress();
    initMagneticHover();
    initStaggerReveal();
    initTypewriter();
}

document.addEventListener('DOMContentLoaded', initAll);
document.addEventListener('livewire:navigated', initAll);

function initAdminSidebar() {
    const drawer = document.getElementById('mobileSidebar');
    if (!drawer) return;

    const openBtns = document.querySelectorAll('[data-open-sidebar]');
    const closeBtns = document.querySelectorAll('[data-close-sidebar]');

    const open = () => {
        drawer.classList.remove('hidden');
        // prevent background scroll
        document.body.style.overflow = 'hidden';
    };
    const close = () => {
        drawer.classList.add('hidden');
        document.body.style.overflow = '';
    };

    openBtns.forEach((b) => b.addEventListener('click', open));
    closeBtns.forEach((b) => b.addEventListener('click', close));
}
