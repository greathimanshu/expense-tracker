<?php

namespace App\Livewire;

use App\Models\SeoSetting;
use App\Services\ResumeBuilderService;
use Livewire\Attributes\Layout;
use Livewire\Component;

class Resume extends Component
{
    public array $resume = [];

    public function mount(ResumeBuilderService $service): void
    {
        $this->resume = $service->build();
    }

    #[Layout('layouts.app')]
    public function render()
    {
        $seo = SeoSetting::first();
        $name = $this->resume['basics']['name'] ?? config('app.name');
        $summary = $this->resume['basics']['summary'] ?? null;

        $title = trim(($name ? ($name . ' — ') : '') . 'Resume');
        $desc = $seo->meta_description ?? ($summary ?: 'Professional resume and experience overview.');
        $keywords = $seo->meta_keywords ?? null;

        return view('livewire.resume', [
            'resume' => $this->resume,
            'title' => $title,
            'metaDescription' => $desc,
            'metaKeywords' => $keywords,
            'ogTitle' => $title,
            'ogDescription' => $desc,
            'ogImage' => $seo->og_image ?? null,
            'twitterTitle' => $title,
            'twitterDescription' => $desc,
        ]);
    }
}
