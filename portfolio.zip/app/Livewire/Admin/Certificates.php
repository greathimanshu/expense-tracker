<?php

namespace App\Livewire\Admin;

use App\Models\Certificate;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Validate;
use Livewire\Component;

class Certificates extends Component
{
    public ?int $editingId = null;

    #[Validate('required|string|min:2')]
    public string $name = '';
    #[Validate('nullable|string|max:255')]
    public ?string $issuer = null;
    #[Validate('nullable|date')]
    public ?string $date = null;
    #[Validate('nullable|url')]
    public ?string $url = null;
    #[Validate('nullable|integer')]
    public ?int $order = 0;

    public function edit(int $id): void
    {
        $c = Certificate::findOrFail($id);
        $this->editingId = $c->id;
        $this->name = (string) $c->name;
        $this->issuer = $c->issuer;
        $this->date = optional($c->date)?->format('Y-m-d');
        $this->url = $c->url;
        $this->order = $c->order;
    }

    public function createNew(): void
    {
        $this->reset(['editingId','name','issuer','date','url','order']);
    }

    public function save(): void
    {
        $this->validate();
        $data = $this->only(['name','issuer','date','url','order']);
        Certificate::updateOrCreate(['id' => $this->editingId], $data);
        session()->flash('status', 'Certificate saved.');
        $this->createNew();
    }

    public function delete(int $id): void
    {
        Certificate::whereKey($id)->delete();
        session()->flash('status', 'Certificate deleted.');
    }

    #[Layout('layouts.admin')]
    public function render()
    {
        return view('livewire.admin.certificates', [
            'certificates' => Certificate::orderBy('order')->orderByDesc('date')->paginate(10),
        ]);
    }
}
