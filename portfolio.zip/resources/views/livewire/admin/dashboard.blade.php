<div class="px-1 py-2">
  <div class="flex items-center justify-between mb-6">
    <div>
      <h1 class="text-2xl font-bold tracking-tight">Welcome back</h1>
      <p class="text-sm text-gray-500">Quick shortcuts to manage your portfolio</p>
    </div>
    <div class="flex items-center gap-3">
      <a href="{{ route('admin.projects') }}" wire:navigate class="inline-flex items-center rounded-md bg-indigo-600 text-white px-4 py-2 text-sm hover:bg-indigo-500">+ New Project</a>
      <form method="POST" action="{{ route('admin.logout') }}">
        @csrf
        <button class="inline-flex items-center rounded-md border border-gray-200 px-3 py-2 text-sm hover:bg-gray-50">Logout</button>
      </form>
    </div>
  </div>

  <div class="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
    <a href="{{ route('admin.projects') }}" wire:navigate class="group rounded-xl bg-white p-5 border border-gray-200 hover:border-indigo-200 hover:shadow-sm transition">
      <div class="text-xs uppercase tracking-wide text-gray-500">Projects</div>
      <div class="mt-1 font-semibold text-gray-800">Manage Projects</div>
      <div class="mt-3 h-1 w-16 rounded bg-gradient-to-r from-indigo-600 to-violet-600 group-hover:w-24 transition-all"></div>
    </a>
    <a href="{{ route('admin.experience') }}" wire:navigate class="group rounded-xl bg-white p-5 border border-gray-200 hover:border-indigo-200 hover:shadow-sm transition">
      <div class="text-xs uppercase tracking-wide text-gray-500">Experience</div>
      <div class="mt-1 font-semibold text-gray-800">Work History</div>
      <div class="mt-3 h-1 w-16 rounded bg-gradient-to-r from-indigo-600 to-violet-600 group-hover:w-24 transition-all"></div>
    </a>
    <a href="{{ route('admin.skills') }}" wire:navigate class="group rounded-xl bg-white p-5 border border-gray-200 hover:border-indigo-200 hover:shadow-sm transition">
      <div class="text-xs uppercase tracking-wide text-gray-500">Skills</div>
      <div class="mt-1 font-semibold text-gray-800">Capabilities</div>
      <div class="mt-3 h-1 w-16 rounded bg-gradient-to-r from-indigo-600 to-violet-600 group-hover:w-24 transition-all"></div>
    </a>
    <a href="{{ route('admin.profile') }}" wire:navigate class="group rounded-xl bg-white p-5 border border-gray-200 hover:border-indigo-200 hover:shadow-sm transition">
      <div class="text-xs uppercase tracking-wide text-gray-500">Profile</div>
      <div class="mt-1 font-semibold text-gray-800">Edit Profile</div>
      <div class="mt-3 h-1 w-16 rounded bg-gradient-to-r from-indigo-600 to-violet-600 group-hover:w-24 transition-all"></div>
    </a>
  </div>

  <div class="grid lg:grid-cols-2 gap-4">
    <div class="rounded-xl bg-white border border-gray-200 p-5">
      <div class="flex items-center justify-between mb-3">
        <h2 class="font-semibold">Tips</h2>
        <span class="text-xs text-gray-500">Getting started</span>
      </div>
      <ul class="text-sm list-disc list-inside text-gray-600 space-y-1">
        <li>Keep projects updated with images and links.</li>
        <li>Highlight featured projects to pin them to the top.</li>
        <li>Use skills and services to showcase your strengths.</li>
      </ul>
    </div>
    <div class="rounded-xl bg-white border border-gray-200 p-5">
      <div class="flex items-center justify-between mb-3">
        <h2 class="font-semibold">Shortcuts</h2>
        <span class="text-xs text-gray-500">Quick access</span>
      </div>
      <div class="flex flex-wrap gap-2">
        <a href="{{ route('admin.socials') }}" wire:navigate class="px-3 py-1.5 text-sm rounded-md border border-indigo-200 text-indigo-700 hover:bg-indigo-50">Social Links</a>
        <a href="{{ route('admin.services') }}" wire:navigate class="px-3 py-1.5 text-sm rounded-md border border-indigo-200 text-indigo-700 hover:bg-indigo-50">Services</a>
        <a href="{{ route('admin.testimonials') }}" wire:navigate class="px-3 py-1.5 text-sm rounded-md border border-indigo-200 text-indigo-700 hover:bg-indigo-50">Testimonials</a>
      </div>
    </div>
  </div>
</div>
