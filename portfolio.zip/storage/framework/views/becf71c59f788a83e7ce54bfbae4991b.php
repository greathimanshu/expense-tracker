<footer class="border-t border-gray-100 py-8">
    <div class="container mx-auto max-w-6xl px-4 text-sm text-gray-500">
        © <?php echo e(date('Y')); ?> <?php echo e(config('app.name')); ?>. All rights reserved.
    </div>
</footer>
<?php /**PATH C:\xampp\htdocs\portfolio\resources\views/components/site/footer.blade.php ENDPATH**/ ?>