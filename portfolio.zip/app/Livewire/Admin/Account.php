<?php

namespace App\Livewire\Admin;

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rules\Password as PasswordRule;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Validate;
use Livewire\Component;

class Account extends Component
{
    public string $email = '';

    // Password fields (optional change)
    public ?string $current_password = null;
    public ?string $password = null;
    public ?string $password_confirmation = null;

    public function mount(): void
    {
        $user = Auth::user();
        $this->email = (string)($user?->email ?? '');
    }

    public function updateAccount(): void
    {
        $user = Auth::user();
        if (!$user) {
            abort(403);
        }

        // Validate email change
        $this->validate([
            'email' => ['required','email','max:255','unique:users,email,' . $user->id],
        ]);

        // If password fields provided, validate and change
        $changingPassword = filled($this->password) || filled($this->password_confirmation) || filled($this->current_password);
        if ($changingPassword) {
            $this->validate([
                'current_password' => ['required','current_password'],
                'password' => ['required', 'confirmed', PasswordRule::defaults()],
            ]);
            $user->password = Hash::make((string)$this->password);
        }

        // Update email if changed
        if ($user->email !== $this->email) {
            $user->email = $this->email;
        }

        $user->save();

        // Reset password fields
        $this->current_password = $this->password = $this->password_confirmation = null;

        session()->flash('status', 'Account updated successfully.');
    }

    #[Layout('layouts.admin')]
    public function render()
    {
        return view('livewire.admin.account');
    }
}
