<?php

namespace App\Services;

use App\Models\Experience;
use App\Models\Education;
use App\Models\Certificate;
use App\Models\Profile as ProfileModel;
use App\Models\Project;
use App\Models\Skill as SkillModel;
use App\Models\SocialLink;
use Illuminate\Support\Collection;

class ResumeBuilderService
{
    /**
     * Build a normalized resume array consumable by JSON/Blade/Markdown.
     * @return array<string,mixed>
     */
    public function build(): array
    {
        $profile = ProfileModel::query()->first();
        $socials = SocialLink::query()->orderBy('order')->get();
        $experiences = Experience::query()->orderByDesc('start_date')->get();
        $educations = Education::query()->orderBy('order')->orderByDesc('start_date')->get();
        $certs = Certificate::query()->orderBy('order')->orderByDesc('date')->get();
        $skills = SkillModel::query()->orderBy('order')->get();
        $projects = Project::query()->where('include_in_resume', true)->orderByDesc('year')->get();

        return [
            'basics' => [
                'name' => $profile?->name ?? config('app.name'),
                'label' => $profile?->title,
                'email' => $profile?->email,
                'url' => $profile?->resume_url,
                'summary' => $profile?->bio,
                'location' => [
                    'city' => $profile?->location,
                ],
                'profiles' => $this->mapSocials($socials),
            ],
            'work' => $experiences->map(function (Experience $exp) {
                return [
                    'company' => $exp->company,
                    'position' => $exp->role,
                    'startDate' => optional($exp->start_date)->format('Y-m-d'),
                    'endDate' => optional($exp->end_date)->format('Y-m-d'),
                    'summary' => $exp->description,
                    'location' => $exp->location,
                ];
            })->all(),
            'education' => $educations->map(function (Education $e) {
                return [
                    'institution' => $e->institution,
                    'area' => $e->area,
                    'studyType' => $e->study_type,
                    'startDate' => optional($e->start_date)->format('Y-m-d'),
                    'endDate' => optional($e->end_date)->format('Y-m-d'),
                ];
            })->all(),
            'certificates' => $certs->map(function (Certificate $c) {
                return [
                    'name' => $c->name,
                    'issuer' => $c->issuer,
                    'date' => optional($c->date)->format('Y-m-d'),
                    'url' => $c->url,
                ];
            })->all(),
            'skills' => $skills->map(function (SkillModel $sk) {
                return [
                    'name' => $sk->name,
                    'category' => $sk->category,
                    'proficiency' => (int) $sk->proficiency,
                ];
            })->all(),
            'projects' => $projects->map(function (Project $p) {
                return [
                    'title' => $p->title,
                    'description' => $p->description,
                    'tech' => $p->tech_stack,
                    'github' => $p->github_url,
                    'live' => $p->live_url,
                    'year' => $p->year,
                ];
            })->all(),
        ];
    }

    /**
     * Convert a normalized resume array to Markdown.
     * @param array<string,mixed> $resume
     */
    public function toMarkdown(array $resume): string
    {
        $lines = [];
        $b = $resume['basics'] ?? [];
        $lines[] = '# ' . ($b['name'] ?? 'Resume');
        if (!empty($b['label'])) $lines[] = '### ' . $b['label'];
        $contact = [];
        if (!empty($b['email'])) $contact[] = $b['email'];
        if (!empty($b['url'])) $contact[] = $b['url'];
        if ($contact) $lines[] = implode(' • ', $contact);
        if (!empty($b['summary'])) {
            $lines[] = '';
            $lines[] = $b['summary'];
        }

        if (!empty($resume['work'])) {
            $lines[] = '';
            $lines[] = '## Experience';
            foreach ($resume['work'] as $w) {
                $period = trim(($w['startDate'] ?? '') . ' — ' . ($w['endDate'] ?? 'Present'));
                $lines[] = "**{$w['position']} · {$w['company']}**  ";
                if (!empty($period)) $lines[] = "_{$period}_";
                if (!empty($w['summary'])) $lines[] = $w['summary'];
                $lines[] = '';
            }
        }

        if (!empty($resume['projects'])) {
            $lines[] = '## Projects';
            foreach ($resume['projects'] as $p) {
                $title = $p['title'] ?? 'Project';
                $year = $p['year'] ? " ({$p['year']})" : '';
                $lines[] = "- **{$title}{$year}** — " . ($p['description'] ?? '');
                $links = array_filter([
                    $p['github'] ? "[GitHub]({$p['github']})" : null,
                    $p['live'] ? "[Live]({$p['live']})" : null,
                ]);
                if ($links) $lines[] = '  ' . implode(' • ', $links);
            }
            $lines[] = '';
        }

        if (!empty($resume['skills'])) {
            $lines[] = '## Skills';
            $skillNames = array_map(fn($s) => $s['name'] ?? '', $resume['skills']);
            $skillNames = array_filter($skillNames);
            if ($skillNames) $lines[] = implode(', ', $skillNames);
        }

        return implode("\n", $lines) . "\n";
    }

    /**
     * @param Collection<int, SocialLink> $socials
     * @return array<int, array{username:string,url:string,label?:string}>
     */
    private function mapSocials(Collection $socials): array
    {
        return $socials->map(function (SocialLink $s) {
            return [
                'label' => $s->label,
                'username' => $this->extractHandleFromUrl($s->url) ?? ($s->label ?? 'profile'),
                'url' => (string) $s->url,
            ];
        })->all();
    }

    private function extractHandleFromUrl(?string $url): ?string
    {
        if (! $url) return null;
        $parts = parse_url($url);
        if (! isset($parts['path'])) return null;
        $handle = trim($parts['path'], '/');
        if ($handle === '') return null;
        return explode('/', $handle)[0];
    }
}
