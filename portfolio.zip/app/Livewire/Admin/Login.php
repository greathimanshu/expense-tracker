<?php

namespace App\Livewire\Admin;

use Illuminate\Support\Facades\Auth;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Validate;
use Livewire\Component;

class Login extends Component
{
    #[Validate('required|email')]
    public string $email = '';

    #[Validate('required|min:6')]
    public string $password = '';

    public bool $remember = false;

    public function updated($field): void
    {
        $this->validateOnly($field);
    }

    public function mount(): void
    {
        if (Auth::check()) {
            $this->redirectIntended(route('admin.dashboard'), navigate: true);
        }
    }

    public function login()
    {
        $this->validate();
        if (Auth::attempt(['email' => $this->email, 'password' => $this->password], $this->remember)) {
            request()->session()->regenerate();
            // Save the new session id so middleware can invalidate other sessions
            $user = Auth::user();
            $user->current_session_id = request()->session()->getId();
            $user->save();
            return $this->redirectIntended(route('admin.dashboard'), navigate: true);
        }
        $this->addError('email', 'Invalid credentials.');
    }

    #[Layout('layouts.app')]
    public function render()
    {
        return view('livewire.admin.login');
    }
}
