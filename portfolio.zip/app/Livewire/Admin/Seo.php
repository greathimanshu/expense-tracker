<?php

namespace App\Livewire\Admin;

use App\Models\SeoSetting;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Validate;
use Livewire\Component;

class Seo extends Component
{
    public ?int $id = null;

    #[Validate('nullable|string|max:255')]
    public ?string $meta_title = null;

    #[Validate('nullable|string|max:300')]
    public ?string $meta_description = null;

    #[Validate('nullable|string|max:500')]
    public ?string $meta_keywords = null; // comma separated

    #[Validate('nullable|url')]
    public ?string $og_image = null;

    public function mount(): void
    {
        $s = SeoSetting::first();
        if ($s) {
            $this->id = $s->id;
            $this->meta_title = $s->meta_title;
            $this->meta_description = $s->meta_description;
            $this->meta_keywords = $s->meta_keywords;
            $this->og_image = $s->og_image;
        }
    }

    public function save(): void
    {
        $this->validate();
        $data = $this->only(['meta_title','meta_description','meta_keywords','og_image']);
        $row = SeoSetting::updateOrCreate(['id' => $this->id], $data);
        $this->id = $row->id;
        session()->flash('status', 'SEO settings saved.');
    }

    #[Layout('layouts.admin')]
    public function render()
    {
        return view('livewire.admin.seo');
    }
}
