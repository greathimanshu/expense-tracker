<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\SeoSetting;

class SeoSeeder extends Seeder
{
    public function run(): void
    {
        SeoSetting::updateOrCreate(
            ['id' => 1],
            [
                'meta_title' => 'Himanshu — Laravel Developer',
                'meta_description' => 'I build robust, secure Laravel apps: SaaS, payments, queues, and APIs. 2.5+ years experience in Laravel + Livewire.',
                'meta_keywords' => 'Laravel, Livewire, PHP, MySQL, SaaS, Payment Gateway, REST API, Queue, Horizon, Eloquent, Blade',
                'og_image' => null,
            ]
        );
    }
}
