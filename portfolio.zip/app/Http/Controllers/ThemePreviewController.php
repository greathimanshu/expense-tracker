<?php

namespace App\Http\Controllers;

use App\Models\Profile;
use App\Models\Project;
use App\Models\Experience;
use App\Models\Skill;
use App\Models\SocialLink;
use App\Models\Service;
use App\Models\Testimonial;
use Illuminate\Http\Request;

class ThemePreviewController extends Controller
{
    public function show(Request $request, string $theme)
    {
        $allowed = ['minimal', 'minimal-accent', 'glass'];
        if (!in_array($theme, $allowed, true)) {
            abort(404);
        }
        $profile = Profile::first();
        $projects = Project::orderByDesc('featured')->orderByDesc('year')->get();
        $experiences = Experience::orderByDesc('start_date')->get();
        $skills = Skill::orderByDesc('proficiency')->get();
        $socials = SocialLink::orderBy('order')->get();
        $services = Service::orderBy('order')->get();
        $testimonials = Testimonial::orderBy('order')->get();
        // Render the themed wrapper view if it exists; fall back to main portfolio with forced theme
        $viewName = view()->exists('livewire.themes.' . $theme) ? 'livewire.themes.' . $theme : 'livewire.portfolio';
        return view($viewName, compact('profile','projects','experiences','skills','socials','services','testimonials'))
            ->with('__forceTheme', $theme);
    }
}
