<div class="container mx-auto max-w-3xl px-4 py-10">
  <div class="flex items-center justify-between mb-6">
    <h1 class="text-2xl font-bold">Edit Profile</h1>
    <a href="<?php echo e(route('admin.dashboard')); ?>" class="text-sm text-indigo-600">Back to Dashboard</a>
  </div>

  <!--[if BLOCK]><![endif]--><?php if(session('status')): ?>
    <div class="mb-4 rounded-md bg-green-50 text-green-800 px-4 py-2 text-sm"><?php echo e(session('status')); ?></div>
  <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

  <form wire:submit.prevent="save" class="space-y-5 bg-white rounded-xl border border-gray-200 p-6">
    <div class="grid md:grid-cols-3 gap-4 items-end">
      <div class="md:col-span-2">
        <label class="block text-sm text-gray-600 mb-1">Avatar Upload</label>
        <input type="file" wire:model="avatar" accept="image/*" class="w-full rounded-md border border-gray-300 px-3 py-2" />
        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['avatar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-sm text-red-600 mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
      </div>
      <div class="flex items-center gap-3">
        <div class="h-14 w-14 rounded-full overflow-hidden bg-gray-100 flex items-center justify-center">
          <!--[if BLOCK]><![endif]--><?php if($avatar): ?>
            <img src="<?php echo e($avatar->temporaryUrl()); ?>" class="h-full w-full object-cover" />
          <?php elseif($avatar_url): ?>
            <img src="<?php echo e($avatar_url); ?>" class="h-full w-full object-cover" />
          <?php else: ?>
            <span>👤</span>
          <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>
      </div>
    </div>
    <div class="grid md:grid-cols-2 gap-4">
      <div>
        <label class="block text-sm text-gray-600 mb-1">Name</label>
        <input type="text" wire:model="name" class="w-full rounded-md border border-gray-300 px-3 py-2 focus:ring-2 focus:ring-indigo-500" />
        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-sm text-red-600 mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
      </div>
      <div>
        <label class="block text-sm text-gray-600 mb-1">Title</label>
        <input type="text" wire:model="title" class="w-full rounded-md border border-gray-300 px-3 py-2 focus:ring-2 focus:ring-indigo-500" />
        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-sm text-red-600 mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
      </div>
    </div>

    <div>
      <label class="block text-sm text-gray-600 mb-1">Typewriter Phrases</label>
      <textarea wire:model="typewriter_phrases" rows="2" class="w-full rounded-md border border-gray-300 px-3 py-2 focus:ring-2 focus:ring-indigo-500" placeholder="Laravel + Livewire Expert|Builds Robust Admin Tools|Optimizes DX & Performance"></textarea>
      <p class="text-xs text-gray-500 mt-1">Enter phrases separated by | (pipe). Example: Laravel + Livewire Expert|Builds Robust Admin Tools|Optimizes DX & Performance</p>
      <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['typewriter_phrases'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-sm text-red-600 mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
    </div>

    <!-- Site Theme -->
    <div>
      <label class="block text-sm text-gray-600 mb-1">Portfolio Theme</label>
      <select wire:model="site_theme" class="w-full rounded-md border border-gray-300 px-3 py-2 focus:ring-2 focus:ring-indigo-500">
        <option value="minimal">Minimal</option>
        <option value="minimal-accent">Minimal + Accent</option>
        <option value="glass">Glass</option>
      </select>
      <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['site_theme'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-sm text-red-600 mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
      <p class="text-xs text-gray-500 mt-1">Choose the visual style applied to the public portfolio hero section.</p>
    </div>

    <div>
      <label class="block text-sm text-gray-600 mb-1">Bio</label>
      <textarea wire:model="bio" rows="4" class="w-full rounded-md border border-gray-300 px-3 py-2 focus:ring-2 focus:ring-indigo-500"></textarea>
      <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['bio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-sm text-red-600 mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
    </div>

    <div class="grid md:grid-cols-2 gap-4">
      <div>
        <label class="block text-sm text-gray-600 mb-1">Location</label>
        <input type="text" wire:model="location" class="w-full rounded-md border border-gray-300 px-3 py-2 focus:ring-2 focus:ring-indigo-500" />
        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-sm text-red-600 mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
      </div>
      <div>
        <label class="block text-sm text-gray-600 mb-1">Email</label>
        <input type="email" wire:model="email" class="w-full rounded-md border border-gray-300 px-3 py-2 focus:ring-2 focus:ring-indigo-500" />
        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-sm text-red-600 mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
      </div>
    </div>

    <div class="grid md:grid-cols-2 gap-4">
      <div>
        <label class="block text-sm text-gray-600 mb-1">Phone</label>
        <input type="text" wire:model="phone" class="w-full rounded-md border border-gray-300 px-3 py-2 focus:ring-2 focus:ring-indigo-500" />
        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-sm text-red-600 mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
      </div>
      <div>
        <label class="block text-sm text-gray-600 mb-1">Avatar URL</label>
        <input type="url" wire:model="avatar_url" class="w-full rounded-md border border-gray-300 px-3 py-2 focus:ring-2 focus:ring-indigo-500" />
        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['avatar_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-sm text-red-600 mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
      </div>
    </div>

    <div>
      <label class="block text-sm text-gray-600 mb-1">Resume URL</label>
      <input type="url" wire:model="resume_url" class="w-full rounded-md border border-gray-300 px-3 py-2 focus:ring-2 focus:ring-indigo-500" />
      <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['resume_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-sm text-red-600 mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
    </div>

    <div class="flex items-center justify-end gap-3">
      <button type="submit" class="inline-flex items-center rounded-md bg-indigo-600 text-white px-4 py-2 hover:bg-indigo-500">Save</button>
    </div>
  </form>
</div>
<?php /**PATH C:\xampp\htdocs\portfolio\resources\views/livewire/admin/profile-editor.blade.php ENDPATH**/ ?>