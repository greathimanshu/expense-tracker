<aside class="hidden md:flex md:w-64 md:flex-col md:fixed md:inset-y-0 bg-gradient-to-b from-indigo-600 to-violet-600 text-white">
  <div class="flex h-16 items-center px-4 border-b border-white/10">
    <a href="{{ route('admin.dashboard') }}" wire:navigate class="text-lg font-semibold tracking-tight">Admin</a>
  </div>
  <nav class="flex-1 overflow-y-auto p-3 text-sm">
    <ul class="space-y-1">
      @foreach([
        ['label'=>'Dashboard','route'=>'admin.dashboard','icon'=>'🏠'],
        ['label'=>'Profile','route'=>'admin.profile','icon'=>'👤'],
        ['label'=>'Projects','route'=>'admin.projects','icon'=>'📦'],
        ['label'=>'Experience','route'=>'admin.experience','icon'=>'🧰'],
        ['label'=>'Skills','route'=>'admin.skills','icon'=>'📊'],
        ['label'=>'Social Links','route'=>'admin.socials','icon'=>'🔗'],
        ['label'=>'Services','route'=>'admin.services','icon'=>'🧩'],
        ['label'=>'Testimonials','route'=>'admin.testimonials','icon'=>'💬'],
        ['label'=>'Education','route'=>'admin.education','icon'=>'🎓'],
        ['label'=>'Certificates','route'=>'admin.certificates','icon'=>'📜'],
        ['label'=>'Theme','route'=>'admin.theme','icon'=>'🎨'],
        ['label'=>'SEO','route'=>'admin.seo','icon'=>'🔎'],
        ['label'=>'Account','route'=>'admin.account','icon'=>'⚙️'],
      ] as $it)
        @php($active = request()->routeIs($it['route']))
        <li>
          <a href="{{ route($it['route']) }}" wire:navigate class="flex items-center gap-2 px-3 py-2 rounded-md transition-colors {{ $active ? 'bg-white text-indigo-700' : 'text-white/80 hover:text-white hover:bg-white/10' }}">
            <span class="w-5 text-center">{{ $it['icon'] }}</span>
            <span>{{ $it['label'] }}</span>
          </a>
        </li>
      @endforeach
    </ul>
  </nav>
  <div class="p-3 border-t border-white/10">
    <form method="POST" action="{{ route('admin.logout') }}">
      @csrf
      <button type="submit" class="w-full px-3 py-2 rounded-md bg-white/10 hover:bg-white/20 text-white text-sm">Sign out</button>
    </form>
  </div>
</aside>
