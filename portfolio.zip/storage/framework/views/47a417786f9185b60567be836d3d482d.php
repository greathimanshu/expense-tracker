<div>
  <div class="flex items-center justify-between mb-6">
    <h1 class="text-2xl font-bold tracking-tight">Experience</h1>
    <a href="<?php echo e(route('admin.dashboard')); ?>" wire:navigate class="text-sm rounded-md border border-indigo-200 text-indigo-700 px-3 py-1.5 hover:bg-indigo-50">Dashboard</a>
  </div>

  <!--[if BLOCK]><![endif]--><?php if(session('status')): ?>
    <div class="mb-4 rounded-md bg-green-50 text-green-800 px-4 py-2 text-sm"><?php echo e(session('status')); ?></div>
  <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

  <form wire:submit.prevent="save" class="space-y-4 bg-white rounded-xl border border-gray-200 p-6 mb-6 shadow-sm">
    <div class="grid md:grid-cols-2 gap-4">
      <div>
        <label class="block text-sm text-gray-700 mb-1">Company</label>
        <input type="text" wire:model="company" class="w-full rounded-md border border-gray-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-300" />
        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['company'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-sm text-red-600 mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
      </div>
      <div>
        <label class="block text-sm text-gray-700 mb-1">Role</label>
        <input type="text" wire:model="role" class="w-full rounded-md border border-gray-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-300" />
        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-sm text-red-600 mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
      </div>
      <div>
        <label class="block text-sm text-gray-700 mb-1">Start Date</label>
        <input type="date" wire:model="start_date" class="w-full rounded-md border border-gray-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-300" />
        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-sm text-red-600 mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
      </div>
      <div>
        <label class="block text-sm text-gray-700 mb-1">End Date</label>
        <input type="date" wire:model="end_date" class="w-full rounded-md border border-gray-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-300" />
        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-sm text-red-600 mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
      </div>
      <div class="md:col-span-2">
        <label class="block text-sm text-gray-700 mb-1">Location</label>
        <input type="text" wire:model="location" class="w-full rounded-md border border-gray-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-300" />
        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-sm text-red-600 mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
      </div>
      <div class="md:col-span-2">
        <label class="block text-sm text-gray-700 mb-1">Description</label>
        <textarea wire:model="description" rows="3" class="w-full rounded-md border border-gray-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-300"></textarea>
        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-sm text-red-600 mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
      </div>
    </div>
    <div class="flex items-center gap-3">
      <button type="submit" class="px-4 py-2 rounded-md bg-indigo-600 text-white hover:bg-indigo-500">Save</button>
      <button type="button" wire:click="createNew" class="px-4 py-2 rounded-md border border-gray-200 hover:bg-gray-50">Clear</button>
    </div>
  </form>

  <div class="bg-white rounded-xl border border-gray-200 overflow-hidden shadow-sm">
    <table class="min-w-full text-sm">
      <thead class="bg-gray-50 text-gray-600">
        <tr>
          <th class="px-4 py-3 text-left font-semibold">Company</th>
          <th class="px-4 py-3 text-left font-semibold">Role</th>
          <th class="px-4 py-3 font-semibold">Period</th>
          <th class="px-4 py-3 font-semibold">Actions</th>
        </tr>
      </thead>
      <tbody class="divide-y">
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $it): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr class="hover:bg-gray-50">
            <td class="px-4 py-3"><?php echo e($it->company); ?></td>
            <td class="px-4 py-3"><?php echo e($it->role); ?></td>
            <td class="px-4 py-3 text-center"><?php echo e(optional($it->start_date)->format('Y-m')); ?> — <?php echo e(optional($it->end_date)->format('Y-m') ?: 'Present'); ?></td>
            <td class="px-4 py-3 text-right">
              <div class="inline-flex items-center gap-2">
                <button wire:click="edit(<?php echo e($it->id); ?>)" class="px-3 py-1.5 rounded-md border border-indigo-200 text-indigo-700 hover:bg-indigo-50">Edit</button>
                <button wire:click="delete(<?php echo e($it->id); ?>)" class="px-3 py-1.5 rounded-md border border-red-200 text-red-700 hover:bg-red-50">Delete</button>
              </div>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
      </tbody>
    </table>
    <div class="p-3"><?php echo e($items->links()); ?></div>
  </div>
</div>
<?php /**PATH C:\xampp\htdocs\portfolio\resources\views/livewire/admin/experiences.blade.php ENDPATH**/ ?>