<div class="container mx-auto max-w-6xl px-4 py-10">
  <div class="flex items-center justify-between mb-6">
    <h1 class="text-2xl font-bold">Education</h1>
    <a href="{{ route('admin.dashboard') }}" class="text-sm text-indigo-600">Back to Dashboard</a>
  </div>

  @if (session('status'))
    <div class="mb-4 rounded-md bg-green-50 text-green-800 px-4 py-2 text-sm">{{ session('status') }}</div>
  @endif

  <div class="grid md:grid-cols-3 gap-6">
    <form wire:submit.prevent="save" class="space-y-4 bg-white rounded-xl border border-gray-200 p-6 mb-6">
      <div class="flex items-center justify-between">
        <h2 class="font-semibold">@if($editingId) Edit Education @else New Education @endif</h2>
        <button type="button" wire:click="createNew" class="text-sm text-gray-500">Reset</button>
      </div>
      <div class="grid md:grid-cols-2 gap-4">
        <div class="md:col-span-2">
          <label class="block text-sm text-gray-600 mb-1">Institution</label>
          <input type="text" wire:model="institution" class="w-full rounded-md border border-gray-300 px-3 py-2" />
          @error('institution') <p class="text-sm text-red-600 mt-1">{{ $message }}</p> @enderror
        </div>
        <div>
          <label class="block text-sm text-gray-600 mb-1">Area</label>
          <input type="text" wire:model="area" class="w-full rounded-md border border-gray-300 px-3 py-2" />
          @error('area') <p class="text-sm text-red-600 mt-1">{{ $message }}</p> @enderror
        </div>
        <div>
          <label class="block text-sm text-gray-600 mb-1">Study Type</label>
          <input type="text" wire:model="study_type" class="w-full rounded-md border border-gray-300 px-3 py-2" />
          @error('study_type') <p class="text-sm text-red-600 mt-1">{{ $message }}</p> @enderror
        </div>
        <div>
          <label class="block text-sm text-gray-600 mb-1">Start Date</label>
          <input type="date" wire:model="start_date" class="w-full rounded-md border border-gray-300 px-3 py-2" />
          @error('start_date') <p class="text-sm text-red-600 mt-1">{{ $message }}</p> @enderror
        </div>
        <div>
          <label class="block text-sm text-gray-600 mb-1">End Date</label>
          <input type="date" wire:model="end_date" class="w-full rounded-md border border-gray-300 px-3 py-2" />
          @error('end_date') <p class="text-sm text-red-600 mt-1">{{ $message }}</p> @enderror
        </div>
        <div>
          <label class="block text-sm text-gray-600 mb-1">Order</label>
          <input type="number" wire:model="order" class="w-full rounded-md border border-gray-300 px-3 py-2" />
          @error('order') <p class="text-sm text-red-600 mt-1">{{ $message }}</p> @enderror
        </div>
      </div>
      <div class="flex items-center justify-end">
        <button type="submit" class="inline-flex items-center rounded-md bg-indigo-600 text-white px-4 py-2 hover:bg-indigo-500">Save Education</button>
      </div>
    </form>

    <div class="md:col-span-2 space-y-3">
      <div class="grid md:grid-cols-2 gap-4">
        @foreach($educations as $e)
          <div class="p-4 rounded-xl border border-gray-200 bg-white">
            <div class="flex items-start justify-between gap-3">
              <div>
                <div class="font-semibold">{{ $e->institution }}</div>
                <div class="text-sm text-gray-500">{{ $e->study_type }} @if($e->area) • {{ $e->area }} @endif</div>
              </div>
              <div class="flex items-center gap-2">
                <button wire:click="edit({{ $e->id }})" class="text-sm text-indigo-600">Edit</button>
                <button wire:click="delete({{ $e->id }})" class="text-sm text-red-600" onclick="return confirm('Delete this education?')">Delete</button>
              </div>
            </div>
            <div class="mt-1 text-xs text-gray-500">
              @if($e->start_date) {{ $e->start_date->format('M Y') }} @endif — @if($e->end_date) {{ $e->end_date->format('M Y') }} @else Present @endif
            </div>
          </div>
        @endforeach
      </div>
      <div>
        {{ $educations->links() }}
      </div>
    </div>
  </div>
</div>
