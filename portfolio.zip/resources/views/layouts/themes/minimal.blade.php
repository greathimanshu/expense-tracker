<!doctype html>
<html lang="en" class="h-full">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{{ $title ?? 'Portfolio' }} · Minimal</title>
  <meta name="description" content="{{ $metaDescription ?? 'Laravel + Livewire portfolio SPA' }}">
  @isset($metaKeywords)
    <meta name="keywords" content="{{ $metaKeywords }}">
  @endisset
  <link rel="canonical" href="{{ url()->current() }}">

  <!-- Open Graph -->
  <meta property="og:type" content="website">
  <meta property="og:title" content="{{ $ogTitle ?? ($title ?? 'Portfolio') }}">
  <meta property="og:description" content="{{ $ogDescription ?? ($metaDescription ?? 'Laravel + Livewire portfolio SPA') }}">
  <meta property="og:url" content="{{ url()->current() }}">
  @isset($ogImage)
    <meta property="og:image" content="{{ $ogImage }}">
  @endisset

  <!-- Twitter -->
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="{{ $twitterTitle ?? ($title ?? 'Portfolio') }}">
  <meta name="twitter:description" content="{{ $twitterDescription ?? ($metaDescription ?? 'Laravel + Livewire portfolio SPA') }}">
  @isset($ogImage)
    <meta name="twitter:image" content="{{ $ogImage }}">
  @endisset
  @vite(['resources/css/app.css','resources/js/app.js'])
  @livewireStyles
</head>
<body class="h-full bg-white text-slate-800 antialiased">
  <div class="min-h-screen flex flex-col">
    @include('components.site.themes.minimal.header')
    <main class="flex-1">{{ $slot }}</main>
    @include('components.site.themes.minimal.footer')
  </div>
  @livewireScripts
</body>
</html>
