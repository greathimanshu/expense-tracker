<?php

namespace App\Livewire\Admin;

use App\Models\Service;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Validate;
use Livewire\Component;

class Services extends Component
{
    public ?int $editingId = null;

    #[Validate('required|string|min:2')]
    public string $title = '';
    #[Validate('nullable|string|max:4')]
    public ?string $icon = null; // emoji or short icon code
    #[Validate('nullable|string|max:1000')]
    public ?string $summary = null;
    #[Validate('nullable|integer|min:0')]
    public ?int $order = 0;

    public function edit(int $id): void
    {
        $s = Service::findOrFail($id);
        $this->editingId = $s->id;
        $this->title = (string) $s->title;
        $this->icon = $s->icon;
        $this->summary = $s->summary;
        $this->order = $s->order;
    }

    public function createNew(): void
    {
        $this->reset(['editingId','title','icon','summary','order']);
        $this->order = 0;
    }

    public function save(): void
    {
        $this->validate();
        $data = $this->only(['title','icon','summary','order']);
        Service::updateOrCreate(['id' => $this->editingId], $data);
        session()->flash('status', 'Service saved.');
        $this->createNew();
    }

    public function delete(int $id): void
    {
        Service::whereKey($id)->delete();
        session()->flash('status', 'Service deleted.');
    }

    #[Layout('layouts.admin')]
    public function render()
    {
        return view('livewire.admin.services', [
            'items' => Service::orderBy('order')->orderBy('title')->paginate(12),
        ]);
    }
}
