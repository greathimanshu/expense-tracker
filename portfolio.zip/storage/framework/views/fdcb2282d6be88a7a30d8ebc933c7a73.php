<div class="container mx-auto max-w-6xl px-4 py-10">
  <div class="flex items-center justify-between mb-6">
    <h1 class="text-2xl font-bold">Projects</h1>
    <a href="<?php echo e(route('admin.dashboard')); ?>" class="text-sm text-indigo-600">Back to Dashboard</a>
  </div>

  <!--[if BLOCK]><![endif]--><?php if(session('status')): ?>
    <div class="mb-4 rounded-md bg-green-50 text-green-800 px-4 py-2 text-sm"><?php echo e(session('status')); ?></div>
  <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

  <div class="grid md:grid-cols-3 gap-6">
    <form wire:submit.prevent="save" class="space-y-4 bg-white rounded-xl border border-gray-200 p-6 mb-6">
      <div class="flex items-center justify-between">
        <h2 class="font-semibold"><!--[if BLOCK]><![endif]--><?php if($editingId): ?> Edit Project <?php else: ?> New Project <?php endif; ?><!--[if ENDBLOCK]><![endif]--></h2>
        <button type="button" wire:click="createNew" class="text-sm text-gray-500">Reset</button>
      </div>
      <div class="grid md:grid-cols-2 gap-4">
        <div>
          <label class="block text-sm text-gray-600 mb-1">Title</label>
          <input type="text" wire:model="title" class="w-full rounded-md border border-gray-300 px-3 py-2" />
          <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-sm text-red-600 mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
        </div>
        <div>
          <label class="block text-sm text-gray-600 mb-1">Tech Stack</label>
          <input type="text" wire:model="tech_stack" class="w-full rounded-md border border-gray-300 px-3 py-2" />
          <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['tech_stack'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-sm text-red-600 mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
        </div>
        <div class="md:col-span-2">
          <label class="block text-sm text-gray-600 mb-1">Description</label>
          <textarea wire:model="description" rows="3" class="w-full rounded-md border border-gray-300 px-3 py-2"></textarea>
          <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-sm text-red-600 mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
        </div>
        <div>
          <label class="block text-sm text-gray-600 mb-1">GitHub URL</label>
          <input type="text" wire:model="github_url" class="w-full rounded-md border border-gray-300 px-3 py-2" />
          <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['github_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-sm text-red-600 mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
        </div>
        <div>
          <label class="block text-sm text-gray-600 mb-1">Live URL</label>
          <input type="text" wire:model="live_url" class="w-full rounded-md border border-gray-300 px-3 py-2" />
          <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['live_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-sm text-red-600 mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
        </div>
        <div class="md:col-span-2 grid md:grid-cols-3 gap-4 items-end">
          <div class="md:col-span-2">
            <label class="block text-sm text-gray-600 mb-1">Project Image Upload</label>
            <input type="file" wire:model="image" accept="image/*" class="w-full rounded-md border border-gray-300 px-3 py-2" />
            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-sm text-red-600 mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
          </div>
          <div class="flex items-center gap-3">
            <div class="h-20 w-32 rounded-md overflow-hidden bg-gray-100 flex items-center justify-center">
              <!--[if BLOCK]><![endif]--><?php if($image): ?>
                <img src="<?php echo e($image->temporaryUrl()); ?>" class="h-full w-full object-cover" />
              <?php elseif($image_url): ?>
                <img src="<?php echo e($image_url); ?>" class="h-full w-full object-cover" />
              <?php else: ?>
                <span class="text-gray-400">No image</span>
              <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </div>
          </div>
        </div>
        <div>
          <label class="block text-sm text-gray-600 mb-1">Year</label>
          <input type="number" wire:model="year" class="w-full rounded-md border border-gray-300 px-3 py-2" />
          <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-sm text-red-600 mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
        </div>
        <div>
          <label class="block text-sm text-gray-600 mb-1">Image URL</label>
          <input type="url" wire:model="image_url" class="w-full rounded-md border border-gray-300 px-3 py-2 focus:ring-2 focus:ring-indigo-500" />
        </div>
        
      </div>
      <div class="flex items-center gap-6">
        <label class="inline-flex items-center gap-2 text-sm text-gray-700">
          <input type="checkbox" wire:model="featured" class="rounded border-gray-300"> Featured
        </label>
        <label class="inline-flex items-center gap-2 text-sm text-gray-700">
          <input type="checkbox" wire:model="include_in_resume" class="rounded border-gray-300"> Include in resume
        </label>
      </div>
      <div class="flex items-center justify-end">
        <button type="submit" class="inline-flex items-center rounded-md bg-indigo-600 text-white px-4 py-2 hover:bg-indigo-500">Save Project</button>
      </div>
    </form>

    <div class="md:col-span-2 space-y-3">
      <div class="grid md:grid-cols-2 gap-4">
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="p-4 rounded-xl border border-gray-200 bg-white">
            <div class="flex items-start justify-between gap-3">
              <div>
                <div class="font-semibold"><?php echo e($p->title); ?></div>
                <div class="text-sm text-gray-500"><?php echo e($p->tech_stack); ?></div>
              </div>
              <div class="flex items-center gap-2">
                <button wire:click="edit(<?php echo e($p->id); ?>)" class="text-sm text-indigo-600">Edit</button>
                <button wire:click="delete(<?php echo e($p->id); ?>)" class="text-sm text-red-600" onclick="return confirm('Delete this project?')">Delete</button>
              </div>
            </div>
            <!--[if BLOCK]><![endif]--><?php if($p->description): ?>
              <p class="mt-2 text-gray-700 text-sm"><?php echo e($p->description); ?></p>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            <div class="mt-2 text-xs text-gray-500 flex items-center gap-2">
              <!--[if BLOCK]><![endif]--><?php if($p->github_url): ?> <a class="text-indigo-600" href="<?php echo e($p->github_url); ?>" target="_blank">GitHub</a> <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
              <!--[if BLOCK]><![endif]--><?php if($p->live_url): ?> <a class="text-indigo-600" href="<?php echo e($p->live_url); ?>" target="_blank">Live</a> <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
              <!--[if BLOCK]><![endif]--><?php if($p->year): ?> <span>• <?php echo e($p->year); ?></span> <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
              <span class="ml-auto flex items-center gap-2">
                <!--[if BLOCK]><![endif]--><?php if($p->include_in_resume): ?>
                  <span class="inline-flex items-center px-2 py-0.5 rounded bg-indigo-100 text-indigo-700">In Resume</span>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                <!--[if BLOCK]><![endif]--><?php if($p->featured): ?>
                  <span class="inline-flex items-center px-2 py-0.5 rounded bg-emerald-100 text-emerald-700">Featured</span>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
              </span>
            </div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
      </div>
      <div>
        <?php echo e($projects->links()); ?>

      </div>
    </div>
  </div>
</div>
<?php /**PATH C:\xampp\htdocs\portfolio\resources\views/livewire/admin/projects.blade.php ENDPATH**/ ?>