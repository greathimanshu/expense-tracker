<header class="sticky top-0 z-40">
  <!-- Subtle accent bar -->
  <div class="h-0.5 w-full" style="background:linear-gradient(90deg,#7c3aed,#a78bfa,#7c3aed); background-size:200% 100%; animation: gradientShift 20s linear infinite"></div>
  <div class="backdrop-blur bg-white/80 border-b border-purple-100/60 shadow-sm">
    <div class="container mx-auto max-w-6xl px-4 py-3 flex items-center justify-between">
      <?php echo $__env->make('components.site.logo', ['class' => 'font-semibold text-lg'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
      <nav class="hidden md:flex items-center gap-6 text-sm text-slate-700">
        <a href="#projects" class="group relative pb-1 hover:text-purple-700 transition">
          <span>Projects</span>
          <span class="absolute left-0 -bottom-0.5 h-0.5 w-0 bg-purple-600 transition-all duration-200 group-hover:w-full"></span>
        </a>
        <a href="#experience" class="group relative pb-1 hover:text-purple-700 transition">
          <span>Experience</span>
          <span class="absolute left-0 -bottom-0.5 h-0.5 w-0 bg-purple-600 transition-all duration-200 group-hover:w-full"></span>
        </a>
        <a href="#skills" class="group relative pb-1 hover:text-purple-700 transition">
          <span>Skills</span>
          <span class="absolute left-0 -bottom-0.5 h-0.5 w-0 bg-purple-600 transition-all duration-200 group-hover:w-full"></span>
        </a>
        <a href="#contact" class="group relative pb-1 hover:text-purple-700 transition">
          <span>Contact</span>
          <span class="absolute left-0 -bottom-0.5 h-0.5 w-0 bg-purple-600 transition-all duration-200 group-hover:w-full"></span>
        </a>
        <a href="<?php echo e(route('resume.view')); ?>" class="group relative pb-1 hover:text-purple-700 transition">
          <span>Resume</span>
          <span class="absolute left-0 -bottom-0.5 h-0.5 w-0 bg-purple-600 transition-all duration-200 group-hover:w-full"></span>
        </a>
      </nav>
      <div class="flex items-center gap-2">
        <!-- <button type="button" data-toggle-theme class="hidden md:inline-flex items-center justify-center rounded-md border border-purple-200/70 bg-white/70 px-3 py-1.5 text-sm text-slate-700 hover:bg-purple-50">
          <span class="dark:hidden">Dark</span>
          <span class="hidden dark:inline">Light</span>
        </button> -->
        <button type="button" data-mobile-menu-toggle class="md:hidden inline-flex items-center justify-center rounded-md border border-purple-200/70 bg-white/70 p-2 text-slate-700 hover:bg-purple-50" aria-label="Toggle navigation">☰</button>
      </div>
    </div>
  </div>
</header>
<?php /**PATH C:\xampp\htdocs\portfolio\resources\views/components/site/themes/purple/header.blade.php ENDPATH**/ ?>