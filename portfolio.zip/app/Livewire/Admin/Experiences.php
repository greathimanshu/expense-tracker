<?php

namespace App\Livewire\Admin;

use App\Models\Experience;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Validate;
use Livewire\Component;

class Experiences extends Component
{
    public ?int $editingId = null;

    #[Validate('required|string|min:2')]
    public string $company = '';
    #[Validate('required|string|min:2')]
    public string $role = '';
    #[Validate('nullable|date')]
    public ?string $start_date = null;
    #[Validate('nullable|date')]
    public ?string $end_date = null;
    #[Validate('nullable|string|max:255')]
    public ?string $location = null;
    #[Validate('nullable|string|max:1000')]
    public ?string $description = null;

    public function updated($field): void
    {
        $this->validateOnly($field);
    }

    public function edit(int $id): void
    {
        $e = Experience::findOrFail($id);
        $this->editingId = $e->id;
        $this->company = (string) $e->company;
        $this->role = (string) $e->role;
        $this->start_date = optional($e->start_date)->format('Y-m-d');
        $this->end_date = optional($e->end_date)->format('Y-m-d');
        $this->location = $e->location;
        $this->description = $e->description;
    }

    public function createNew(): void
    {
        $this->reset(['editingId','company','role','start_date','end_date','location','description']);
    }

    public function save(): void
    {
        $this->validate();
        $data = [
            'company' => $this->company,
            'role' => $this->role,
            'start_date' => $this->start_date ? (new \Carbon\Carbon($this->start_date)) : null,
            'end_date' => $this->end_date ? (new \Carbon\Carbon($this->end_date)) : null,
            'location' => $this->location,
            'description' => $this->description,
        ];
        Experience::updateOrCreate(['id' => $this->editingId], $data);
        session()->flash('status', 'Experience saved.');
        $this->createNew();
    }

    public function delete(int $id): void
    {
        Experience::whereKey($id)->delete();
        session()->flash('status', 'Experience deleted.');
    }

    #[Layout('layouts.admin')]
    public function render()
    {
        return view('livewire.admin.experiences', [
            'items' => Experience::orderByDesc('start_date')->paginate(10),
        ]);
    }
}
