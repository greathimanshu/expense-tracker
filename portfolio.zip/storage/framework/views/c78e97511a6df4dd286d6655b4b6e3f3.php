<div class="min-h-[60vh] flex items-center justify-center px-4">
  <div class="w-full max-w-md rounded-xl border border-gray-200 bg-white p-6 shadow-sm">
    <h1 class="text-xl font-semibold mb-4">Admin Login</h1>

    <form wire:submit.prevent="login" class="space-y-4">
      <div>
        <label class="block text-sm text-gray-600 mb-1">Email</label>
        <input type="email" wire:model.debounce.500ms="email" class="w-full rounded-md border border-gray-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500" />
        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-sm text-red-600 mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
      </div>
      <div>
        <label class="block text-sm text-gray-600 mb-1">Password</label>
        <input type="password" wire:model.debounce.500ms="password" class="w-full rounded-md border border-gray-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500" />
        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-sm text-red-600 mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
      </div>
      <label class="inline-flex items-center gap-2 text-sm text-gray-600">
        <input type="checkbox" wire:model="remember" class="rounded border-gray-300" /> Remember me
      </label>
      <button type="submit" class="w-full inline-flex items-center justify-center rounded-md bg-indigo-600 text-white px-4 py-2 font-medium hover:bg-indigo-500">Sign in</button>
    </form>
  </div>
</div>
<?php /**PATH C:\xampp\htdocs\portfolio\resources\views/livewire/admin/login.blade.php ENDPATH**/ ?>