<footer class="border-t border-gray-100 py-8">
    <div class="container mx-auto max-w-6xl px-4 text-sm text-gray-500">
        © {{ date('Y') }} {{ config('app.name') }}. All rights reserved.
    </div>
</footer>
