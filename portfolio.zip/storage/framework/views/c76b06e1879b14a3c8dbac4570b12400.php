<footer class="mx-4 mb-4 rounded-xl border border-white/40 bg-white/50 backdrop-blur shadow-sm">
  <div class="container mx-auto max-w-6xl px-4 py-6 text-sm text-slate-700 flex items-center justify-between">
    <p>&copy; <?php echo e(date('Y')); ?> <?php echo e(config('app.name')); ?> · Glass</p>
    <a href="#top" class="hover:text-indigo-600">Back to top ↑</a>
  </div>
</footer>
<?php /**PATH C:\xampp\htdocs\portfolio\resources\views/components/site/themes/glass/footer.blade.php ENDPATH**/ ?>