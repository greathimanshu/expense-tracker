<?php

namespace App\Livewire\Admin;

use App\Models\Profile;
use Illuminate\Support\Facades\Storage;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Validate;
use Livewire\Component;
use Livewire\WithFileUploads;

class ProfileEditor extends Component
{
    use WithFileUploads;
    public ?int $id = null;

    #[Validate('required|string|min:2')]
    public string $name = '';
    #[Validate('required|string|min:2')]
    public string $title = '';
    #[Validate('nullable|string|max:1000')]
    public ?string $typewriter_phrases = null;
    #[Validate('required|in:minimal,minimal-accent,glass,purple')]
    public string $site_theme = 'minimal-accent';
    #[Validate('nullable|string|max:1000')]
    public ?string $bio = null;
    #[Validate('nullable|string|max:255')]
    public ?string $location = null;
    #[Validate('required|email')]
    public string $email = '';
    #[Validate('nullable|string|max:30')]
    public ?string $phone = null;
    #[Validate('nullable|url')]
    public ?string $avatar_url = null;
    #[Validate('nullable|url')]
    public ?string $resume_url = null;

    // Uploads
    #[Validate('nullable|image|max:2048')]
    public $avatar;

    public function mount(): void
    {
        $p = Profile::first();
        if ($p) {
            $this->id = $p->id;
            $this->name = (string) $p->name;
            $this->title = (string) $p->title;
            $this->typewriter_phrases = $p->typewriter_phrases;
            $this->site_theme = $p->site_theme ?: 'minimal-accent';
            $this->bio = $p->bio;
            $this->location = $p->location;
            $this->email = (string) $p->email;
            $this->phone = $p->phone;
            $this->avatar_url = $p->avatar_url;
            $this->resume_url = $p->resume_url;
        }
    }

    public function save()
    {
        $this->validate();
        $data = $this->only(['name','title','typewriter_phrases','site_theme','bio','location','email','phone','avatar_url','resume_url']);
        if ($this->avatar) {
            $path = $this->avatar->store('avatars', 'public');
            $data['avatar_url'] = Storage::url($path);
        }
        $profile = Profile::updateOrCreate(['id' => $this->id], $data);
        $this->id = $profile->id;
        session()->flash('status', 'Profile saved.');
    }

    #[Layout('layouts.admin')]
    public function render()
    {
        return view('livewire.admin.profile-editor');
    }
}
