<div>
  <div class="flex items-center justify-between mb-6">
    <h1 class="text-2xl font-bold">Social Links</h1>
    <a href="{{ route('admin.dashboard') }}" class="text-sm text-indigo-600">Back to Dashboard</a>
  </div>

  @if (session('status'))
    <div class="mb-4 rounded-md bg-green-50 text-green-800 px-4 py-2 text-sm">{{ session('status') }}</div>
  @endif

  <form wire:submit.prevent="save" class="space-y-4 bg-white rounded-xl border border-gray-200 p-6 mb-6">
    <div class="grid md:grid-cols-4 gap-4">
      <div>
        <label class="block text-sm text-gray-600 mb-1">Label</label>
        <input type="text" wire:model="label" class="w-full rounded-md border border-gray-300 px-3 py-2" />
        @error('label') <p class="text-sm text-red-600 mt-1">{{ $message }}</p> @enderror
      </div>
      <div class="md:col-span-2">
        <label class="block text-sm text-gray-600 mb-1">URL</label>
        <input type="text" wire:model="url" class="w-full rounded-md border border-gray-300 px-3 py-2" />
        @error('url') <p class="text-sm text-red-600 mt-1">{{ $message }}</p> @enderror
      </div>
      <div>
        <label class="block text-sm text-gray-600 mb-1">Icon</label>
        <input type="text" wire:model="icon" class="w-full rounded-md border border-gray-300 px-3 py-2" placeholder="github, linkedin" />
        @error('icon') <p class="text-sm text-red-600 mt-1">{{ $message }}</p> @enderror
      </div>
      <div>
        <label class="block text-sm text-gray-600 mb-1">Order</label>
        <input type="number" wire:model="order" min="0" class="w-full rounded-md border border-gray-300 px-3 py-2" />
        @error('order') <p class="text-sm text-red-600 mt-1">{{ $message }}</p> @enderror
      </div>
    </div>
    <div class="flex items-center gap-3">
      <button type="submit" class="px-4 py-2 rounded-md bg-indigo-600 text-white">Save</button>
      <button type="button" wire:click="createNew" class="px-4 py-2 rounded-md border">Clear</button>
    </div>
  </form>

  <div class="bg-white rounded-xl border border-gray-200">
    <table class="min-w-full text-sm">
      <thead class="bg-gray-50 text-gray-600">
        <tr>
          <th class="px-4 py-3 text-left">Label</th>
          <th class="px-4 py-3 text-left">URL</th>
          <th class="px-4 py-3 text-left">Icon</th>
          <th class="px-4 py-3">Order</th>
          <th class="px-4 py-3">Actions</th>
        </tr>
      </thead>
      <tbody class="divide-y">
        @foreach($items as $it)
          <tr>
            <td class="px-4 py-3">{{ $it->label }}</td>
            <td class="px-4 py-3"><a href="{{ $it->url }}" class="text-indigo-600" target="_blank">{{ $it->url }}</a></td>
            <td class="px-4 py-3">{{ $it->icon }}</td>
            <td class="px-4 py-3 text-center">{{ $it->order }}</td>
            <td class="px-4 py-3 text-right space-x-2">
              <button wire:click="edit({{ $it->id }})" class="text-indigo-600">Edit</button>
              <button wire:click="delete({{ $it->id }})" class="text-red-600">Delete</button>
            </td>
          </tr>
        @endforeach
      </tbody>
    </table>
    <div class="p-3">{{ $items->links() }}</div>
  </div>
</div>
