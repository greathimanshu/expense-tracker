<?php

namespace App\Http\Controllers;

use App\Services\ResumeBuilderService;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Barryvdh\DomPDF\Facade\Pdf;
use App\Models\SeoSetting;

class ResumeController extends Controller
{
    public function __construct(private readonly ResumeBuilderService $service)
    {
    }

    public function view(Request $request)
    {
        $resume = $this->service->build();
        $seo = SeoSetting::first();
        $name = $resume['basics']['name'] ?? config('app.name');
        $label = $resume['basics']['label'] ?? null;
        $summary = $resume['basics']['summary'] ?? null;

        $title = trim(($name ? ($name . ' — ') : '') . 'Resume');
        $desc = $seo->meta_description ?? ($summary ?: 'Professional resume and experience overview.');
        $keywords = $seo->meta_keywords ?? null;

        return view('resume', [
            'resume' => $resume,
            // SEO meta
            'title' => $title,
            'metaDescription' => $desc,
            'metaKeywords' => $keywords,
            'ogTitle' => $title,
            'ogDescription' => $desc,
            'ogImage' => $seo->og_image ?? null,
            'twitterTitle' => $title,
            'twitterDescription' => $desc,
        ]);
    }

    public function json(Request $request)
    {
        $resume = $this->service->build();
        return response()->json($resume);
    }

    public function markdown(Request $request)
    {
        $resume = $this->service->build();
        $markdown = $this->service->toMarkdown($resume);
        $filename = 'resume.md';

        return response($markdown, Response::HTTP_OK, [
            'Content-Type' => 'text/markdown; charset=UTF-8',
            'Content-Disposition' => 'attachment; filename="' . $filename . '"',
        ]);
    }

    public function pdf(Request $request)
    {
        $resume = $this->service->build();
        $html = view('resume-pdf', ['resume' => $resume])->render();
        $pdf = Pdf::loadHTML($html)->setPaper('a4');
        return $pdf->download('resume.pdf');
    }

    // Optional: Implement PDF export later with a renderer (e.g. barryvdh/laravel-dompdf)
}
