<div>
  <div class="flex items-center justify-between mb-6">
    <h1 class="text-2xl font-bold tracking-tight">Experience</h1>
    <a href="{{ route('admin.dashboard') }}" wire:navigate class="text-sm rounded-md border border-indigo-200 text-indigo-700 px-3 py-1.5 hover:bg-indigo-50">Dashboard</a>
  </div>

  @if (session('status'))
    <div class="mb-4 rounded-md bg-green-50 text-green-800 px-4 py-2 text-sm">{{ session('status') }}</div>
  @endif

  <form wire:submit.prevent="save" class="space-y-4 bg-white rounded-xl border border-gray-200 p-6 mb-6 shadow-sm">
    <div class="grid md:grid-cols-2 gap-4">
      <div>
        <label class="block text-sm text-gray-700 mb-1">Company</label>
        <input type="text" wire:model="company" class="w-full rounded-md border border-gray-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-300" />
        @error('company') <p class="text-sm text-red-600 mt-1">{{ $message }}</p> @enderror
      </div>
      <div>
        <label class="block text-sm text-gray-700 mb-1">Role</label>
        <input type="text" wire:model="role" class="w-full rounded-md border border-gray-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-300" />
        @error('role') <p class="text-sm text-red-600 mt-1">{{ $message }}</p> @enderror
      </div>
      <div>
        <label class="block text-sm text-gray-700 mb-1">Start Date</label>
        <input type="date" wire:model="start_date" class="w-full rounded-md border border-gray-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-300" />
        @error('start_date') <p class="text-sm text-red-600 mt-1">{{ $message }}</p> @enderror
      </div>
      <div>
        <label class="block text-sm text-gray-700 mb-1">End Date</label>
        <input type="date" wire:model="end_date" class="w-full rounded-md border border-gray-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-300" />
        @error('end_date') <p class="text-sm text-red-600 mt-1">{{ $message }}</p> @enderror
      </div>
      <div class="md:col-span-2">
        <label class="block text-sm text-gray-700 mb-1">Location</label>
        <input type="text" wire:model="location" class="w-full rounded-md border border-gray-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-300" />
        @error('location') <p class="text-sm text-red-600 mt-1">{{ $message }}</p> @enderror
      </div>
      <div class="md:col-span-2">
        <label class="block text-sm text-gray-700 mb-1">Description</label>
        <textarea wire:model="description" rows="3" class="w-full rounded-md border border-gray-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-300"></textarea>
        @error('description') <p class="text-sm text-red-600 mt-1">{{ $message }}</p> @enderror
      </div>
    </div>
    <div class="flex items-center gap-3">
      <button type="submit" class="px-4 py-2 rounded-md bg-indigo-600 text-white hover:bg-indigo-500">Save</button>
      <button type="button" wire:click="createNew" class="px-4 py-2 rounded-md border border-gray-200 hover:bg-gray-50">Clear</button>
    </div>
  </form>

  <div class="bg-white rounded-xl border border-gray-200 overflow-hidden shadow-sm">
    <table class="min-w-full text-sm">
      <thead class="bg-gray-50 text-gray-600">
        <tr>
          <th class="px-4 py-3 text-left font-semibold">Company</th>
          <th class="px-4 py-3 text-left font-semibold">Role</th>
          <th class="px-4 py-3 font-semibold">Period</th>
          <th class="px-4 py-3 font-semibold">Actions</th>
        </tr>
      </thead>
      <tbody class="divide-y">
        @foreach($items as $it)
          <tr class="hover:bg-gray-50">
            <td class="px-4 py-3">{{ $it->company }}</td>
            <td class="px-4 py-3">{{ $it->role }}</td>
            <td class="px-4 py-3 text-center">{{ optional($it->start_date)->format('Y-m') }} — {{ optional($it->end_date)->format('Y-m') ?: 'Present' }}</td>
            <td class="px-4 py-3 text-right">
              <div class="inline-flex items-center gap-2">
                <button wire:click="edit({{ $it->id }})" class="px-3 py-1.5 rounded-md border border-indigo-200 text-indigo-700 hover:bg-indigo-50">Edit</button>
                <button wire:click="delete({{ $it->id }})" class="px-3 py-1.5 rounded-md border border-red-200 text-red-700 hover:bg-red-50">Delete</button>
              </div>
            </td>
          </tr>
        @endforeach
      </tbody>
    </table>
    <div class="p-3">{{ $items->links() }}</div>
  </div>
</div>
