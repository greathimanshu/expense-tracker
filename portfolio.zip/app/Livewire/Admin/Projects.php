<?php

namespace App\Livewire\Admin;

use App\Models\Project;
use Illuminate\Support\Facades\Storage;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Validate;
use Livewire\Component;
use Livewire\WithFileUploads;

class Projects extends Component
{
    use WithFileUploads;
    public ?int $editingId = null;

    #[Validate('required|string|min:2')]
    public string $title = '';
    #[Validate('nullable|string|max:1000')]
    public ?string $description = null;
    #[Validate('nullable|string|max:255')]
    public ?string $tech_stack = null;
    #[Validate('nullable|url')]
    public ?string $github_url = null;
    #[Validate('nullable|url')]
    public ?string $live_url = null;
    #[Validate('nullable|url')]
    public ?string $image_url = null;
    #[Validate('nullable|image|max:4096')]
    public $image;
    #[Validate('nullable|integer')]
    public ?int $year = null;
    #[Validate('boolean')]
    public bool $featured = false;
    #[Validate('boolean')]
    public bool $include_in_resume = false;

    public function edit(int $id): void
    {
        $p = Project::findOrFail($id);
        $this->editingId = $p->id;
        $this->title = (string) $p->title;
        $this->description = $p->description;
        $this->tech_stack = $p->tech_stack;
        $this->github_url = $p->github_url;
        $this->live_url = $p->live_url;
        $this->image_url = $p->image_url;
        $this->year = $p->year;
        $this->featured = (bool) $p->featured;
        $this->include_in_resume = (bool) $p->include_in_resume;
    }

    public function createNew(): void
    {
        $this->reset(['editingId','title','description','tech_stack','github_url','live_url','image_url','year','featured','include_in_resume']);
    }

    public function save(): void
    {
        $this->validate();
        $data = $this->only(['title','description','tech_stack','github_url','live_url','image_url','year','featured','include_in_resume']);
        if ($this->image) {
            $path = $this->image->store('projects', 'public');
            $data['image_url'] = Storage::url($path);
        }
        Project::updateOrCreate(['id' => $this->editingId], $data);
        session()->flash('status', 'Project saved.');
        $this->createNew();
    }

    public function delete(int $id): void
    {
        Project::whereKey($id)->delete();
        session()->flash('status', 'Project deleted.');
    }

    public function toggleInclude(int $id): void
    {
        $p = Project::findOrFail($id);
        $p->include_in_resume = ! (bool) $p->include_in_resume;
        $p->save();
        session()->flash('status', 'Include in resume updated.');
    }

    public function toggleFeatured(int $id): void
    {
        $p = Project::findOrFail($id);
        $p->featured = ! (bool) $p->featured;
        $p->save();
        session()->flash('status', 'Featured updated.');
    }

    #[Layout('layouts.admin')]
    public function render()
    {
        return view('livewire.admin.projects', [
            'projects' => Project::orderByDesc('featured')->orderByDesc('year')->paginate(10),
        ]);
    }
}
