<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>{{ $resume['basics']['name'] ?? 'Resume' }} — Resume</title>
    <style>
        /* Page + base */
        @page { margin: 9mm 8mm; }
        * { box-sizing: border-box; }
        body { font-family: DejaVu Sans, Arial, Helvetica, sans-serif; color: #0f172a; font-size: 10.8px; line-height: 1.35; }
        .muted { color: #6b7280; }
        .small { font-size: 10.75px; }
        .hr { height: 1px; background: #e5e7eb; margin: 6px 0 0; }

        /* Heading styles */
        h1 { font-size: 24px; letter-spacing: 0.2px; margin: 0; text-align: center; }
        .role { font-weight: 600; color: #111827; text-align: center; margin-top: 1px; }
        .contact { text-align: center; margin-top: 1px; font-size: 10.25px; color: #4b5563; }
        .section { margin-top: 10px; }
        .section h2 { font-size: 12px; margin: 0; font-weight: 700; color: #111827; text-transform: uppercase; letter-spacing: 0.5px; }
        .section .underline { height: 1px; background: #111827; margin-top: 3px; opacity: .9; }

        /* Layout helpers */
        .row { display: flex; justify-content: space-between; align-items: baseline; gap: 8px; }
        .item { margin: 4px 0 6px; }
        .content { margin-top: 6px; }

        /* Bullet lists */
        .bullets { list-style-type: disc; list-style-position: outside; margin: 2px 0 0 0; padding-left: 14px; }
        .bullets li { margin: 0 0 2px 0; }

        /* Pills */
        .pill { display:inline-block; padding: 1px 8px; border: 1px solid #e5e7eb; border-radius: 9999px; margin: 3px 6px 0 0; background: #f8fafc; color: #334155; }

        /* Links */
        a { color: #111827; text-decoration: none; }
        .links a:after { content: " \00B7 "; color: #9ca3af; }
        .links a:last-child:after { content: ""; }

        /* Allow headings to sit at page bottom if needed (prevents whole section from jumping) */
        /* Removed page-break-after: avoid on h2 */

        /* Footer page numbers */
        .footer { position: fixed; bottom: 12mm; left: 0; right: 0; text-align: center; font-size: 10px; color: #6b7280; }
        .pageno:before { content: counter(page) " of " counter(pages); }
    </style>
    <meta http-equiv="Content-Security-Policy" content="default-src 'self' 'unsafe-inline' data:;">
</head>
<body>
    @php
        $fmt = function($d) {
            try { return $d ? \Carbon\Carbon::parse($d)->format('m/Y') : null; } catch (\Exception $e) { return $d; }
        };
    @endphp
    <!-- Header -->
    <header>
        <h1>{{ $resume['basics']['name'] ?? 'Resume' }}</h1>
        @if(!empty($resume['basics']['label']))
            <div class="role">{{ $resume['basics']['label'] }}</div>
        @endif
        <div class="small muted contact">
            @php($contact = [])
            @if(!empty($resume['basics']['location']['city'])) @php($contact[] = $resume['basics']['location']['city']) @endif
            @if(!empty($resume['basics']['email'])) @php($contact[] = $resume['basics']['email']) @endif
            @if(!empty($resume['basics']['url'])) @php($contact[] = $resume['basics']['url']) @endif
            {{ implode(' • ', $contact) }}
        </div>
        @if(!empty($resume['basics']['profiles']))
            @foreach($resume['basics']['profiles'] as $p)
                @php($net = strtolower($p['network'] ?? ''))
                @php($url = $p['url'] ?? '')
                @if($net === 'github' || str_contains(strtolower($url), 'github.com'))
                    <div class="small" style="text-align:center; margin-top:2px;">
                        GitHub: <a href="{{ $p['url'] ?? '#' }}">{{ $p['username'] ?? ($p['url'] ?? 'GitHub') }}</a>
                    </div>
                    @break
                @endif
            @endforeach
        @endif
        <div class="hr"></div>
    </header>

    <!-- One column content -->
    <section class="content">
        @if(!empty($resume['basics']['summary']))
            <section class="section">
                <h2>Professional Summary</h2>
                <div class="underline"></div>
                <div style="margin-top:6px;">{{ $resume['basics']['summary'] }}</div>
            </section>
        @endif

        @if(!empty($resume['work']))
            <section class="section">
                <h2>Professional Experience</h2>
                <div class="underline"></div>
                @foreach($resume['work'] as $w)
                    <div class="item">
                        <div class="row">
                            <strong>{{ $w['position'] }} · {{ $w['company'] }}</strong>
                            <span class="small muted">{{ $fmt($w['startDate']) }} — {{ $fmt($w['endDate']) ?? 'Present' }}</span>
                        </div>
                        @php($lines = array_values(array_filter(array_map('trim', preg_split('/\r?\n/', (string)($w['summary'] ?? ''))))))
                        @if(!empty($lines) && count($lines) > 1)
                            <ul class="small bullets">
                                @foreach($lines as $line)
                                    <li>{{ ltrim($line, "-• ") }}</li>
                                @endforeach
                            </ul>
                        @elseif(!empty($w['summary']))
                            <div class="small" style="margin-top:4px;">{{ $w['summary'] }}</div>
                        @endif
                    </div>
                @endforeach
            </section>
        @endif

        @if(!empty($resume['education']))
            <section class="section">
                <h2>Education</h2>
                <div class="underline"></div>
                @foreach($resume['education'] as $edu)
                    <div class="item">
                        <div class="row">
                            <strong>{{ $edu['institution'] }}</strong>
                            @if(!empty($edu['startDate']) || !empty($edu['endDate']))
                                <span class="small muted">{{ $fmt($edu['startDate']) ?? '' }} — {{ $fmt($edu['endDate']) ?? '' }}</span>
                            @endif
                        </div>
                        <div class="small">{{ $edu['studyType'] }}@if(!empty($edu['area'])) — {{ $edu['area'] }}@endif</div>
                    </div>
                @endforeach
            </section>
        @endif

        @if(!empty($resume['projects']))
            <section class="section">
                <h2>Projects</h2>
                <div class="underline"></div>
                @foreach($resume['projects'] as $p)
                    <div class="item">
                        <div class="row">
                            <strong>{{ $p['title'] }}</strong>
                            @if(!empty($p['year']))<span class="small muted">{{ $p['year'] }}</span>@endif
                        </div>
                        @if(!empty($p['description']))
                            @php($pLines = array_values(array_filter(array_map('trim', preg_split('/\r?\n/', (string)$p['description'])))))
                            @if(count($pLines) > 1)
                                <ul class="small bullets">
                                    @foreach($pLines as $line)
                                        <li>{{ ltrim($line, "-•* ") }}</li>
                                    @endforeach
                                </ul>
                            @else
                                <div class="small" style="margin-top:4px;">{{ $p['description'] }}</div>
                            @endif
                        @endif
                        @php($links = array_filter([
                            !empty($p['github']) ? $p['github'] : null,
                            !empty($p['live']) ? $p['live'] : null,
                        ]))
                        @if(!empty($links))
                            <div class="small links" style="margin-top:4px;">
                                @if(!empty($p['github']))<a href="{{ $p['github'] }}">GitHub</a>@endif
                                @if(!empty($p['live']))<a href="{{ $p['live'] }}">Live</a>@endif
                            </div>
                        @endif
                    </div>
                @endforeach
            </section>
        @endif

        @if(!empty($resume['skills']))
            <section class="section">
                <h2>Key Skills</h2>
                <div class="underline"></div>
                <ul class="small" style="margin:4px 0 0 16px;">
                    @foreach($resume['skills'] as $s)
                        <li>{{ $s['name'] }}</li>
                    @endforeach
                </ul>
            </section>
        @endif

        @if(!empty($resume['interests'] ?? []))
            <section class="section">
                <h2>Interests</h2>
                <div class="underline"></div>
                <ul class="small" style="margin:6px 0 0 16px;">
                    @foreach($resume['interests'] as $i)
                        <li>{{ is_array($i) ? ($i['name'] ?? '') : $i }}</li>
                    @endforeach
                </ul>
            </section>
        @endif
    </section>

    <!-- footer removed to avoid reserved space at bottom -->
</body>
</html>
