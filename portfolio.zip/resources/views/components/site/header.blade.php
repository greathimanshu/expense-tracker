<header class="sticky top-0 z-40 backdrop-blur bg-white/70 border-b border-gray-100">
    @php
        $isHome = request()->routeIs('portfolio');
        $home = route('portfolio');
        // Try to use Profile name if APP_NAME is default
        $appName = config('app.name');
        if ($appName === 'Laravel') {
            try {
                $profileName = \App\Models\Profile::query()->value('name');
                if ($profileName) { $appName = $profileName; }
            } catch (\Throwable $e) {}
        }
    @endphp
    <div class="container mx-auto max-w-6xl px-4 py-3 flex items-center justify-between">
        @include('components.site.logo', ['class' => 'text-xl'])

        <nav class="hidden md:flex items-center gap-6 text-sm">
            <a href="{{ $isHome ? '#projects' : $home . '#projects' }}" @if(!$isHome) wire:navigate @endif class="hover:text-[#6366f1]">Projects</a>
            <a href="{{ $isHome ? '#experience' : $home . '#experience' }}" @if(!$isHome) wire:navigate @endif class="hover:text-[#6366f1]">Experience</a>
            <a href="{{ $isHome ? '#skills' : $home . '#skills' }}" @if(!$isHome) wire:navigate @endif class="hover:text-[#6366f1]">Skills</a>
            <a href="{{ $isHome ? '#contact' : $home . '#contact' }}" @if(!$isHome) wire:navigate @endif class="hover:text-[#6366f1]">Contact</a>
            <a href="{{ route('resume.view') }}" wire:navigate class="hover:text-[#6366f1]">Resume</a>
        </nav>

        <div class="flex items-center gap-2">
            <!-- <button type="button" data-toggle-theme class="hidden md:inline-flex items-center justify-center rounded-md border border-gray-200/80 px-3 py-1.5 text-sm hover:bg-gray-50 text-gray-700">
                <span class="dark:hidden">🌙 Dark</span>
                <span class="hidden dark:inline">☀️ Light</span>
            </button> -->
            <button type="button" data-mobile-menu-toggle class="md:hidden inline-flex items-center justify-center rounded-md border border-gray-200/80 p-2 text-gray-700 hover:bg-gray-50" aria-label="Toggle navigation">
                ☰
            </button>
        </div>
    </div>

    <!-- Mobile menu -->
    <div id="mobileMenu" class="md:hidden hidden border-t border-gray-100 bg-white/90">
        <div class="container mx-auto max-w-6xl px-4 py-3 space-y-2 text-sm">
            <a href="{{ $isHome ? '#projects' : $home . '#projects' }}" @if(!$isHome) wire:navigate @endif class="block hover:text-[#6366f1]">Projects</a>
            <a href="{{ $isHome ? '#experience' : $home . '#experience' }}" @if(!$isHome) wire:navigate @endif class="block hover:text-[#6366f1]">Experience</a>
            <a href="{{ $isHome ? '#skills' : $home . '#skills' }}" @if(!$isHome) wire:navigate @endif class="block hover:text-[#6366f1]">Skills</a>
            <a href="{{ $isHome ? '#contact' : $home . '#contact' }}" @if(!$isHome) wire:navigate @endif class="block hover:text-[#6366f1]">Contact</a>
            <a href="{{ route('resume.view') }}" wire:navigate class="block hover:text-[#6366f1]">Resume</a>
            <!-- <button type="button" data-toggle-theme class="mt-2 inline-flex items-center justify-center rounded-md border border-gray-200/80 px-3 py-1.5 text-sm hover:bg-gray-50 text-gray-700">
                <span class="dark:hidden">🌙 Dark</span>
                <span class="hidden dark:inline">☀️ Light</span>
            </button> -->
        </div>
    </div>
</header>
