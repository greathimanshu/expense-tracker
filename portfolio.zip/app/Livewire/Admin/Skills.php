<?php

namespace App\Livewire\Admin;

use App\Models\Skill;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Validate;
use Livewire\Component;

class Skills extends Component
{
    public ?int $editingId = null;

    #[Validate('required|string|min:2')]
    public string $name = '';
    #[Validate('nullable|string|max:100')]
    public ?string $category = null;
    #[Validate('required|integer|min:0|max:100')]
    public int $proficiency = 50;
    #[Validate('nullable|integer|min:0')]
    public ?int $order = 0;

    public function updated($field): void
    {
        $this->validateOnly($field);
    }

    public function edit(int $id): void
    {
        $s = Skill::findOrFail($id);
        $this->editingId = $s->id;
        $this->name = (string) $s->name;
        $this->category = $s->category;
        $this->proficiency = (int) $s->proficiency;
        $this->order = $s->order;
    }

    public function createNew(): void
    {
        $this->reset(['editingId','name','category','proficiency','order']);
        $this->proficiency = 50;
        $this->order = 0;
    }

    public function save(): void
    {
        $this->validate();
        $data = $this->only(['name','category','proficiency','order']);
        Skill::updateOrCreate(['id' => $this->editingId], $data);
        session()->flash('status', 'Skill saved.');
        $this->createNew();
    }

    public function delete(int $id): void
    {
        Skill::whereKey($id)->delete();
        session()->flash('status', 'Skill deleted.');
    }

    #[Layout('layouts.admin')]
    public function render()
    {
        return view('livewire.admin.skills', [
            'items' => Skill::orderBy('order')->orderBy('name')->paginate(12),
        ]);
    }
}
