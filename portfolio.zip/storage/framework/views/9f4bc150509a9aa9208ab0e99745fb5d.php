<!doctype html>
<html lang="en" class="h-full">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?php echo e($title ?? 'Portfolio'); ?> · Purple</title>
  <meta name="description" content="<?php echo e($metaDescription ?? 'Laravel + Livewire portfolio SPA'); ?>">
  <?php if(isset($metaKeywords)): ?>
    <meta name="keywords" content="<?php echo e($metaKeywords); ?>">
  <?php endif; ?>
  <link rel="canonical" href="<?php echo e(url()->current()); ?>">

  <!-- Open Graph -->
  <meta property="og:type" content="website">
  <meta property="og:title" content="<?php echo e($ogTitle ?? ($title ?? 'Portfolio')); ?>">
  <meta property="og:description" content="<?php echo e($ogDescription ?? ($metaDescription ?? 'Laravel + Livewire portfolio SPA')); ?>">
  <meta property="og:url" content="<?php echo e(url()->current()); ?>">
  <?php if(isset($ogImage)): ?>
    <meta property="og:image" content="<?php echo e($ogImage); ?>">
  <?php endif; ?>

  <!-- Twitter -->
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="<?php echo e($twitterTitle ?? ($title ?? 'Portfolio')); ?>">
  <meta name="twitter:description" content="<?php echo e($twitterDescription ?? ($metaDescription ?? 'Laravel + Livewire portfolio SPA')); ?>">
  <?php if(isset($ogImage)): ?>
    <meta name="twitter:image" content="<?php echo e($ogImage); ?>">
  <?php endif; ?>
  <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css','resources/js/app.js']); ?>
  <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

  <style>
    /* Animated gradient for header/footer bars and background orbs */
    @keyframes gradientShift { 0%{background-position:0% 50%} 50%{background-position:100% 50%} 100%{background-position:0% 50%} }
    @keyframes floatSlow { 0%{ transform: translateY(0) translateX(0);} 50%{ transform: translateY(-12px) translateX(6px);} 100%{ transform: translateY(0) translateX(0);} }
    html { scroll-behavior: smooth; }
    /* Ensure anchors don't slide under sticky header */
    .section-anchor { scroll-margin-top: 96px; }
  </style>
</head>
<body class="h-full bg-gradient-to-br from-purple-50 via-fuchsia-50 to-indigo-50 text-slate-800 antialiased">
  <!-- Animated background orbs -->
  <div aria-hidden="true" class="pointer-events-none fixed inset-0 -z-10 overflow-hidden">
    <div class="absolute -top-10 -left-16 h-64 w-64 rounded-full blur-3xl opacity-25"
         style="background:linear-gradient(45deg,#a78bfa,#f0abfc,#818cf8); background-size:200% 200%; animation: gradientShift 12s ease infinite, floatSlow 10s ease-in-out infinite;"></div>
    <div class="absolute bottom-[-5rem] right-[-6rem] h-72 w-72 rounded-full blur-3xl opacity-20"
         style="background:linear-gradient(45deg,#c084fc,#a78bfa,#7c3aed); background-size:200% 200%; animation: gradientShift 14s ease-in-out infinite, floatSlow 12s ease-in-out infinite;"></div>
  </div>

  <div class="min-h-screen flex flex-col">
    <?php echo $__env->make('components.site.themes.purple.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <main class="flex-1 pt-2 sm:pt-4"><?php echo e($slot); ?></main>
    <?php echo $__env->make('components.site.themes.purple.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
  </div>
  <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\portfolio\resources\views/layouts/themes/purple.blade.php ENDPATH**/ ?>