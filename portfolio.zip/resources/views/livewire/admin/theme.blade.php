<div class="container mx-auto max-w-6xl px-4 py-8">
  <div class="flex items-center justify-between mb-6">
    <h1 class="text-2xl font-bold">Theme</h1>
    <a href="{{ route('admin.dashboard') }}" class="text-sm text-indigo-600">Back to Dashboard</a>
  </div>

  @if (session('status'))
    <div class="mb-4 rounded-md bg-green-50 text-green-800 px-4 py-2 text-sm">{{ session('status') }}</div>
  @endif

  <p class="text-sm text-gray-600 mb-4">Choose a theme for the public portfolio page. Your selection updates instantly.</p>

  <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
    <!-- Minimal -->
    <div class="group relative rounded-xl border p-4 bg-white shadow-sm @if($site_theme==='minimal') ring-2 ring-indigo-500 border-indigo-200 @else border-gray-200 @endif">
      <div class="absolute right-3 top-3 text-xl">🧩</div>
      <h2 class="font-semibold">Minimal</h2>
      <p class="text-xs text-gray-500 mb-3">Clean and simple without accent background.</p>
      <div class="rounded-lg border border-gray-200 overflow-hidden">
        <iframe src="{{ route('admin.theme.preview', ['theme' => 'minimal']) }}" class="w-full h-60 sm:h-64 lg:h-72 bg-white" loading="lazy"></iframe>
      </div>
      <div class="mt-4 flex items-center justify-between">
        <span class="text-xs text-gray-500">Preview</span>
        <button type="button" wire:click="setTheme('minimal')" class="px-3 py-1.5 rounded-md text-sm @if($site_theme==='minimal') bg-indigo-600 text-white @else bg-gray-100 hover:bg-gray-200 @endif">@if($site_theme==='minimal') Selected @else Use Theme @endif</button>
      </div>
    </div>

    <!-- Minimal + Accent -->
    <div class="group relative rounded-xl border p-4 bg-white shadow-sm @if($site_theme==='minimal-accent') ring-2 ring-indigo-500 border-indigo-200 @else border-gray-200 @endif">
      <div class="absolute right-3 top-3 text-xl">🌈</div>
      <h2 class="font-semibold">Minimal + Accent</h2>
      <p class="text-xs text-gray-500 mb-3">Minimal layout with a subtle accent gradient spot.</p>
      <div class="rounded-lg border border-gray-200 overflow-hidden relative">
        <iframe src="{{ route('admin.theme.preview', ['theme' => 'minimal-accent']) }}" class="w-full h-60 sm:h-64 lg:h-72 bg-white" loading="lazy"></iframe>
      </div>
      <div class="mt-4 flex items-center justify-between">
        <span class="text-xs text-gray-500">Preview</span>
        <button type="button" wire:click="setTheme('minimal-accent')" class="px-3 py-1.5 rounded-md text-sm @if($site_theme==='minimal-accent') bg-indigo-600 text-white @else bg-gray-100 hover:bg-gray-200 @endif">@if($site_theme==='minimal-accent') Selected @else Use Theme @endif</button>
      </div>
    </div>

    <!-- Glass -->
    <div class="group relative rounded-xl border p-4 bg-white shadow-sm @if($site_theme==='glass') ring-2 ring-indigo-500 border-indigo-200 @else border-gray-200 @endif">
      <div class="absolute right-3 top-3 text-xl">🪟</div>
      <h2 class="font-semibold">Glass</h2>
      <p class="text-xs text-gray-500 mb-3">Frosted glass card with subtle gradient backdrop.</p>
      <div class="rounded-lg border border-gray-200 overflow-hidden relative">
        <iframe src="{{ route('admin.theme.preview', ['theme' => 'glass']) }}" class="w-full h-60 sm:h-64 lg:h-72 bg-white" loading="lazy"></iframe>
      </div>
      <div class="mt-4 flex items-center justify-between">
        <span class="text-xs text-gray-500">Preview</span>
        <button type="button" wire:click="setTheme('glass')" class="px-3 py-1.5 rounded-md text-sm @if($site_theme==='glass') bg-indigo-600 text-white @else bg-gray-100 hover:bg-gray-200 @endif">@if($site_theme==='glass') Selected @else Use Theme @endif</button>
      </div>
    </div>

    <!-- Purple (New) -->
    <div class="group relative rounded-xl border p-4 bg-white shadow-sm @if($site_theme==='purple') ring-2 ring-indigo-500 border-indigo-200 @else border-gray-200 @endif">
      <div class="absolute right-3 top-3 text-xl">💜</div>
      <h2 class="font-semibold">Purple</h2>
      <p class="text-xs text-gray-500 mb-3">Animated purple theme with gradient header and orbs.</p>
      <div class="rounded-lg border border-gray-200 overflow-hidden relative">
        <iframe src="{{ route('admin.theme.preview', ['theme' => 'purple']) }}" class="w-full h-60 sm:h-64 lg:h-72 bg-white" loading="lazy"></iframe>
      </div>
      <div class="mt-4 flex items-center justify-between">
        <span class="text-xs text-gray-500">Preview</span>
        <button type="button" wire:click="setTheme('purple')" class="px-3 py-1.5 rounded-md text-sm @if($site_theme==='purple') bg-indigo-600 text-white @else bg-gray-100 hover:bg-gray-200 @endif">@if($site_theme==='purple') Selected @else Use Theme @endif</button>
      </div>
    </div>
  </div>
</div>
