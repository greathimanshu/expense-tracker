<header class="sticky top-0 z-40">
  <div class="mx-4 mt-4 rounded-xl border border-white/40 bg-white/50 backdrop-blur shadow-sm">
    <div class="container mx-auto max-w-6xl px-4 py-3 flex items-center justify-between">
      @include('components.site.logo', ['class' => 'font-semibold text-xl'])
      <nav class="hidden md:flex items-center gap-6 text-sm text-slate-700">
        <a href="#projects" class="hover:text-indigo-600">Projects</a>
        <a href="#experience" class="hover:text-indigo-600">Experience</a>
        <a href="#skills" class="hover:text-indigo-600">Skills</a>
        <a href="#contact" class="hover:text-indigo-600">Contact</a>
        <a href="{{ route('resume.view') }}" class="hover:text-indigo-600">Resume</a>
      </nav>
      <div class="flex items-center gap-2">
        <!-- <button type="button" data-toggle-theme class="hidden md:inline-flex items-center justify-center rounded-md border border-white/60 bg-white/50 backdrop-blur px-3 py-1.5 text-sm text-slate-700 hover:bg-white/70">
          <span class="dark:hidden">🌙 Dark</span>
          <span class="hidden dark:inline">☀️ Light</span>
        </button> -->
        <button type="button" data-mobile-menu-toggle class="md:hidden inline-flex items-center justify-center rounded-md border border-white/60 bg-white/50 backdrop-blur p-2 text-slate-700 hover:bg-white/70" aria-label="Toggle navigation">☰</button>
      </div>
    </div>
  </div>
</header>
