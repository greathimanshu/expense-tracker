<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (Schema::hasTable('projects') && !Schema::hasColumn('projects', 'include_in_resume')) {
            Schema::table('projects', function (Blueprint $table) {
                $table->boolean('include_in_resume')->default(false)->after('featured');
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasTable('projects') && Schema::hasColumn('projects', 'include_in_resume')) {
            Schema::table('projects', function (Blueprint $table) {
                $table->dropColumn('include_in_resume');
            });
        }
    }
};
