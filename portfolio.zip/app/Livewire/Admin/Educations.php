<?php

namespace App\Livewire\Admin;

use App\Models\Education;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Validate;
use Livewire\Component;

class Educations extends Component
{
    public ?int $editingId = null;

    #[Validate('required|string|min:2')]
    public string $institution = '';
    #[Validate('nullable|string|max:255')]
    public ?string $area = null;
    #[Validate('nullable|string|max:255')]
    public ?string $study_type = null;
    #[Validate('nullable|date')]
    public ?string $start_date = null;
    #[Validate('nullable|date')]
    public ?string $end_date = null;
    #[Validate('nullable|integer')]
    public ?int $order = 0;

    public function edit(int $id): void
    {
        $e = Education::findOrFail($id);
        $this->editingId = $e->id;
        $this->institution = (string) $e->institution;
        $this->area = $e->area;
        $this->study_type = $e->study_type;
        $this->start_date = optional($e->start_date)?->format('Y-m-d');
        $this->end_date = optional($e->end_date)?->format('Y-m-d');
        $this->order = $e->order;
    }

    public function createNew(): void
    {
        $this->reset(['editingId','institution','area','study_type','start_date','end_date','order']);
    }

    public function save(): void
    {
        $this->validate();
        $data = $this->only(['institution','area','study_type','start_date','end_date','order']);
        Education::updateOrCreate(['id' => $this->editingId], $data);
        session()->flash('status', 'Education saved.');
        $this->createNew();
    }

    public function delete(int $id): void
    {
        Education::whereKey($id)->delete();
        session()->flash('status', 'Education deleted.');
    }

    #[Layout('layouts.admin')]
    public function render()
    {
        return view('livewire.admin.educations', [
            'educations' => Education::orderBy('order')->orderByDesc('start_date')->paginate(10),
        ]);
    }
}
