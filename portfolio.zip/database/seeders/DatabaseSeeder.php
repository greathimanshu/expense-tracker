<?php

namespace Database\Seeders;

use App\Models\User;
use App\Models\Profile;
use App\Models\Project;
use App\Models\Experience;
use App\Models\Skill;
use App\Models\SocialLink;
use App\Models\Service;
use App\Models\Testimonial;
use Database\Seeders\EducationSeeder;
use Database\Seeders\SeoSeeder;
// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        
        // Admin user (idempotent)
        \App\Models\User::updateOrCreate([
            'email' => 'himanshu@admin.com',
        ], [
            'name' => 'Portfolio Owner',
            'password' => bcrypt('12345678'),
            'email_verified_at' => now(),
        ]);

        // Profile (idempotent)
        $profile = Profile::updateOrCreate([
            'email' => 'its.himanshu@outlook.com',
        ], [
            'name' => 'Himanshu',
            'title' => 'Laravel Developer',
            'bio' => "I'm a PHP Laravel developer with 2.4 years of hands-on experience building and maintaining web applications. Skilled in PHP, Laravel, Livewire and MySQL, with basic knowledge of React.js, Vue.js and the Django framework. I'm passionate about writing clean, efficient code and always eager to take on new challenges that help me grow as a developer.",
            'location' => 'Bathinda, Punjab 151001',
            'email' => 'its.himanshu@outlook.com',
            'phone' => '6284234058',
            'avatar_url' => null,
            'resume_url' => null,
        ]);

        // Projects (match CV). Include only selected in resume; exclude PayAnytime
        Project::updateOrCreate([
            'slug' => 'multi-tenant-saas-payment-gateway',
        ], [
            'title' => 'Multi-Tenant SaaS Payment Gateway Platform (Laravel + Livewire + MySQL)',
            'description' => implode("\n", [
                'Designed and developed a scalable multi-tenant SaaS payment gateway system with domain/subdomain-based tenant isolation and separate databases per tenant.',
                'Implemented Super Admin panel to manage tenants, configure payment gateways, and assign gateways to tenants or users.',
                'Built tenant-level admin features to manage users, set custom transaction charges, and define charge slabs.',
                'Integrated dynamic payment routing so transactions map to the assigned gateway and fee structure.',
                'Engineered backend with Laravel and Livewire for reactive interfaces and seamless real-time updates.',
                'Optimized MySQL for high concurrency with connection pooling; ensured secure isolated storage per tenant.',
                'Tech Stack: Laravel, Livewire, MySQL, Multi-Tenancy, REST APIs, Payment Gateway Integration.',
            ]),
            'tech_stack' => 'Laravel, Livewire, MySQL, Multi-Tenancy, REST APIs, Payment Gateway',
            'github_url' => null,
            'live_url' => null,
            'image_url' => null,
            'year' => (int) date('Y'),
            'featured' => false,
            'include_in_resume' => true,
            'order' => 1,
        ]);

        Project::updateOrCreate([
            'slug' => 'backup-auto-detect-database',
        ], [
            'title' => 'Composer Package Developer — backup-auto-detect-database (Open-Source)',
            'description' => implode("\n", [
                'Developed a Laravel Composer package that auto-detects if the project uses MySQL or MongoDB, triggers a full database backup, and uploads it to Google Drive.',
                'Added config-driven features like local backup cleanup, scheduler-based automation, and simple .env setup.',
                'Supports Laravel 9–12 and PHP 8.1+, published on Packagist for easy install.',
                'GitHub: https://github.com/greathimanshu/backup-auto-detect-database',
            ]),
            'tech_stack' => 'Laravel, Composer, Google Drive API',
            'github_url' => 'https://github.com/greathimanshu/backup-auto-detect-database',
            'live_url' => null,
            'image_url' => null,
            'year' => (int) date('Y'),
            'featured' => false,
            'include_in_resume' => true,
            'order' => 2,
        ]);

        // Project::updateOrCreate([
        //     'slug' => 'payanytime',
        // ], [
        //     'title' => 'Payanytime',
        //     'description' => 'Financial web application integrating multiple payment gateways for seamless transactions (excluded from resume view).',
        //     'tech_stack' => 'Laravel, Payment Gateways, REST APIs',
        //     'github_url' => null,
        //     'live_url' => null,
        //     'image_url' => null,
        //     'year' => (int) date('Y'),
        //     'featured' => false,
        //     'include_in_resume' => false,
        //     'order' => 99,
        // ]);

        // Experience (match CV)
        Experience::updateOrCreate([
            'company' => 'Pentasoft professional',
            'role' => 'Laravel Developer',
        ], [
            'start_date' => '2022-05-01',
            'end_date' => null,
            'location' => null,
            'description' => implode("\n", [
                'Working with designers, Front End and project management staff to capture requirements for functional elements of website projects.',
                'Liaising with clients and ensuring all work complies with standards and guidelines.',
                'Working on project estimates and implementing code based on specifications.',
                'Setting up and creating new tables within MySQL.',
                'Improvement of system architecture by refactoring old legacy code to the latest technology.',
                'Live projects on cPanel and AWS (Amazon Web Server).',
            ]),
        ]);

        // Skills
        foreach ([
            ['name' => 'PHP, MySQL', 'category' => 'Backend', 'proficiency' => 90, 'order' => 1],
            ['name' => 'MVC Laravel Framework, Livewire', 'category' => 'Backend', 'proficiency' => 90, 'order' => 2],
            ['name' => 'AWS (EC2, S3, RDS) Deployment', 'category' => 'DevOps', 'proficiency' => 80, 'order' => 3],
            ['name' => 'cPanel Hosting & Server Management', 'category' => 'DevOps', 'proficiency' => 80, 'order' => 4],
            ['name' => 'Third Party API Integration', 'category' => 'Backend', 'proficiency' => 85, 'order' => 5],
            ['name' => 'MySQL Optimization & Query Performance', 'category' => 'Database', 'proficiency' => 85, 'order' => 6],
            ['name' => 'Git/GitHub Version Control', 'category' => 'Tools', 'proficiency' => 80, 'order' => 7],
            ['name' => 'Bootstrap HTML/CSS', 'category' => 'Frontend', 'proficiency' => 75, 'order' => 8],
            ['name' => 'Payment Gateway Integration', 'category' => 'Backend', 'proficiency' => 85, 'order' => 9],
        ] as $s) {
            Skill::updateOrCreate(['name' => $s['name']], $s);
        }

        // Socials (idempotent by label)
        SocialLink::updateOrCreate(['label' => 'GitHub'], ['url' => 'https://github.com/yourname', 'icon' => 'github', 'order' => 1]);
        SocialLink::updateOrCreate(['label' => 'LinkedIn'], ['url' => 'https://linkedin.com/in/yourname', 'icon' => 'linkedin', 'order' => 2]);
        SocialLink::updateOrCreate(['label' => 'Email'], ['url' => 'mailto:you@example.com', 'icon' => 'mail', 'order' => 3]);

        // Services (idempotent by title)
        foreach ([
            ['title' => 'Custom Web Applications', 'icon' => '🧩', 'summary' => 'Bespoke Laravel apps with clean architecture and testing.', 'order' => 1],
            ['title' => 'Livewire SPAs', 'icon' => '⚡', 'summary' => 'Interactive SPA experiences without heavy JS frameworks.', 'order' => 2],
            ['title' => 'DevOps on AWS EC2', 'icon' => '☁️', 'summary' => 'CI/CD, deployments, and scaling on AWS EC2.', 'order' => 3],
        ] as $svc) {
            Service::updateOrCreate(['title' => $svc['title']], $svc);
        }

        // Testimonials (idempotent by author+quote)
        foreach ([
            ['author' => 'A. Client', 'role' => 'CTO', 'company' => 'Tech Co', 'quote' => 'Himanshu delivered our project on time with exceptional quality.', 'avatar_url' => null, 'order' => 1],
            ['author' => 'B. Manager', 'role' => 'Product Manager', 'company' => 'Startup Inc.', 'quote' => 'Great communicator and leader—guided juniors effectively.', 'avatar_url' => null, 'order' => 2],
        ] as $t) {
            Testimonial::updateOrCreate(['author' => $t['author'], 'quote' => $t['quote']], $t);
        }

        // Education entries (10th, 12th PSEB, BCA at Govt Rajindra College)
        $this->call([
            EducationSeeder::class,
            SeoSeeder::class,
        ]);
    }
}
