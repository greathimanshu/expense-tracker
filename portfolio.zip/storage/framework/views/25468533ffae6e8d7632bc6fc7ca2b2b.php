<!doctype html>
<html lang="en" class="h-full">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?php echo e($title ?? 'Portfolio'); ?> · Glass</title>
  <meta name="description" content="<?php echo e($metaDescription ?? 'Laravel + Livewire portfolio SPA'); ?>">
  <?php if(isset($metaKeywords)): ?>
    <meta name="keywords" content="<?php echo e($metaKeywords); ?>">
  <?php endif; ?>
  <link rel="canonical" href="<?php echo e(url()->current()); ?>">

  <!-- Google Fonts: preconnect + stylesheet (display=swap) -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@600;700&display=swap" rel="stylesheet">

  <!-- Open Graph -->
  <meta property="og:type" content="website">
  <meta property="og:title" content="<?php echo e($ogTitle ?? ($title ?? 'Portfolio')); ?>">
  <meta property="og:description" content="<?php echo e($ogDescription ?? ($metaDescription ?? 'Laravel + Livewire portfolio SPA')); ?>">
  <meta property="og:url" content="<?php echo e(url()->current()); ?>">
  <?php if(isset($ogImage)): ?>
    <meta property="og:image" content="<?php echo e($ogImage); ?>">
  <?php endif; ?>

  <!-- Twitter -->
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="<?php echo e($twitterTitle ?? ($title ?? 'Portfolio')); ?>">
  <meta name="twitter:description" content="<?php echo e($twitterDescription ?? ($metaDescription ?? 'Laravel + Livewire portfolio SPA')); ?>">
  <?php if(isset($ogImage)): ?>
    <meta name="twitter:image" content="<?php echo e($ogImage); ?>">
  <?php endif; ?>
  <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css','resources/js/app.js']); ?>
  <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

</head>
<body class="h-full bg-gradient-to-br from-slate-100 to-indigo-100 text-slate-800 antialiased">
  <div class="min-h-screen flex flex-col relative overflow-hidden">
    <div aria-hidden="true" class="absolute inset-0 -z-10">
      <div class="absolute -top-10 -left-10 h-72 w-72 rounded-full bg-gradient-to-br from-indigo-400/40 to-violet-400/40 blur-3xl"></div>
      <div class="absolute bottom-[-6rem] right-[-4rem] h-80 w-80 rounded-full bg-gradient-to-tr from-sky-300/40 to-fuchsia-300/40 blur-3xl"></div>
    </div>
    <?php echo $__env->make('components.site.themes.glass.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <main class="flex-1"><?php echo e($slot); ?></main>
    <?php echo $__env->make('components.site.themes.glass.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
  </div>
  <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\portfolio\resources\views/layouts/themes/glass.blade.php ENDPATH**/ ?>