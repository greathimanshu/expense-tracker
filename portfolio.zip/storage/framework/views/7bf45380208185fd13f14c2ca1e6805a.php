<header class="sticky top-0 z-40 bg-white border-b border-gray-200">
  <div class="container mx-auto max-w-6xl px-4 py-3 flex items-center justify-between">
    <?php echo $__env->make('components.site.logo', ['class' => 'font-semibold text-xl'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <nav class="hidden md:flex items-center gap-6 text-sm text-slate-700">
      <a href="#projects" class="hover:text-indigo-600">Projects</a>
      <a href="#experience" class="hover:text-indigo-600">Experience</a>
      <a href="#skills" class="hover:text-indigo-600">Skills</a>
      <a href="#contact" class="hover:text-indigo-600">Contact</a>
      <a href="<?php echo e(route('resume.view')); ?>" class="hover:text-indigo-600">Resume</a>
    </nav>
    <div class="flex items-center gap-2">
      <!-- <button type="button" data-toggle-theme class="hidden md:inline-flex items-center justify-center rounded-md border border-gray-200 px-3 py-1.5 text-sm text-slate-700 hover:bg-gray-50">
        <span class="dark:hidden">🌙 Dark</span>
        <span class="hidden dark:inline">☀️ Light</span>
      </button> -->
      <button type="button" data-mobile-menu-toggle class="md:hidden inline-flex items-center justify-center rounded-md border border-gray-200 p-2 text-slate-700 hover:bg-gray-50" aria-label="Toggle navigation">☰</button>
    </div>
  </div>
</header>
<?php /**PATH C:\xampp\htdocs\portfolio\resources\views/components/site/themes/minimal/header.blade.php ENDPATH**/ ?>