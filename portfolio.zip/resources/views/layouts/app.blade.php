<!doctype html>
<html lang="en" class="h-full">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{{ $title ?? 'Portfolio' }}</title>
    <meta name="description" content="{{ $metaDescription ?? 'Laravel + Livewire portfolio SPA' }}">
    <meta name="author" content="{{ config('app.name') }}">
    @isset($metaKeywords)
        <meta name="keywords" content="{{ $metaKeywords }}">
    @endisset
    <link rel="canonical" href="{{ url()->current() }}">

    <!-- Open Graph -->
    <meta property="og:type" content="website">
    <meta property="og:title" content="{{ $ogTitle ?? ($title ?? 'Portfolio') }}">
    <meta property="og:description" content="{{ $ogDescription ?? ($metaDescription ?? 'Laravel + Livewire portfolio SPA') }}">
    <meta property="og:url" content="{{ url()->current() }}">
    <meta property="og:site_name" content="{{ config('app.name') }}">
    @isset($ogImage)
        <meta property="og:image" content="{{ $ogImage }}">
    @endisset

    <!-- Twitter -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="{{ $twitterTitle ?? ($title ?? 'Portfolio') }}">
    <meta name="twitter:description" content="{{ $twitterDescription ?? ($metaDescription ?? 'Laravel + Livewire portfolio SPA') }}">
    @isset($ogImage)
        <meta name="twitter:image" content="{{ $ogImage }}">
    @endisset

    @yield('head')
    <link rel="icon" href="/favicon.ico">
    <!-- Google Fonts: preconnect + stylesheet (display=swap) -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@600;700&display=swap" rel="stylesheet">
    <!-- Theme boot: set initial theme before CSS loads to avoid wrong colors -->
    <script>
        (function () {
            try {
                var saved = localStorage.getItem('theme');
                var theme = (saved === 'dark' || saved === 'light') ? saved : (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
                var root = document.documentElement;
                root.dataset.theme = theme;
                if (theme === 'dark') root.classList.add('dark'); else root.classList.remove('dark');
            } catch (e) {}
        })();
    </script>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
    @livewireStyles
</head>
<body class="h-full bg-gray-50 text-gray-800 antialiased">
    <!-- Scroll progress bar -->
    <div id="scrollProgress" class="fixed top-0 left-0 h-[3px] w-0 z-50"></div>
    <div class="min-h-screen flex flex-col relative overflow-hidden">
        <!-- Animated background layers -->
        <div aria-hidden="true" class="pointer-events-none absolute inset-0 -z-10 bg-animated-gradient opacity-20"></div>
        <div aria-hidden="true" class="pointer-events-none absolute inset-0 -z-10 bg-radial-mask"></div>
        <div aria-hidden="true" class="pointer-events-none absolute inset-0 -z-10">
            <div class="blob blob-1"></div>
            <div class="blob blob-2"></div>
            <div class="blob blob-3"></div>
        </div>

        @include('components.site.header')

        <main class="flex-1">
            @hasSection('content')
                @yield('content')
            @else
                {{ $slot }}
            @endif
        </main>

        @include('components.site.footer')
    </div>

    @livewireScripts
    <script>
        // Fallback: enable theme toggle ONLY if main bundle did not initialize
        (function(){
            if (window.__themeFallbackInit) return; // avoid duplicate bindings
            window.__themeFallbackInit = true;
            function apply(theme){
                var root = document.documentElement;
                root.dataset.theme = theme;
                root.classList.toggle('dark', theme === 'dark');
                try { localStorage.setItem('theme', theme); } catch(e) {}
            }
            function toggle(){
                var next = (document.documentElement.dataset.theme === 'dark') ? 'light' : 'dark';
                apply(next);
            }
            document.addEventListener('DOMContentLoaded', function(){
                if (window.__themeBundleInit) return; // main JS already bound handlers
                document.querySelectorAll('[data-toggle-theme]').forEach(function(btn){
                    btn.addEventListener('click', toggle);
                });
            });
        })();
    </script>
</body>
</html>

