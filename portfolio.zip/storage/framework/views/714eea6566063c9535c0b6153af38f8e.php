<div>
<?php ($theme = $__forceTheme ?? ($profile->site_theme ?? 'minimal-accent')); ?>
<section id="home" class="relative overflow-hidden reveal in-view">
    <!--[if BLOCK]><![endif]--><?php switch($theme):
        case ('minimal'): ?>
            <div class="relative z-10 container mx-auto max-w-6xl px-4 py-20 grid md:grid-cols-2 gap-10 items-center">
                <div class="text-slate-900 dark:text-gray-100">
                    <h1 class="text-4xl md:text-5xl font-extrabold tracking-tight text-slate-900 dark:text-white"><span style="font-family:'Cinzel',serif;"><?php echo e($profile->name ?? 'Your Name'); ?></span></h1>
                    <p class="mt-2 text-base md:text-lg text-gray-700/90 dark:text-gray-300">
                        <span data-typewriter data-phrases="<?php echo e($profile?->typewriter_phrases ?: implode('|', array_filter([
                                $profile->title ?? 'Laravel Developer','Livewire Enthusiast','Clean Code Advocate','Problem Solver',
                            ]))); ?>" data-loop="true" data-speed="110" data-delay="1500"><?php echo e($profile->title ?? 'Laravel Developer'); ?></span>
                        <span class="tw-caret" aria-hidden="true">|</span>
                    </p>
                    <p class="mt-4 text-sm md:text-base leading-relaxed text-gray-700 dark:text-gray-300"><?php echo e($profile->bio ?? 'Write a short, impactful bio here.'); ?></p>
                    <div class="mt-7 flex flex-wrap gap-3">
                        <a href="#contact" data-magnetic class="magnetic-wrap inline-flex items-center gap-2 px-5 py-2 rounded-md bg-[#6366f1] text-white hover:bg-[#5558e6] shadow-sm"><span class="magnetic-target">Hire Me</span></a>
                        <a href="<?php echo e(route('resume.view')); ?>" data-magnetic class="magnetic-wrap inline-flex items-center gap-2 px-4 py-2 rounded-md ring-1 ring-[#6366f1]/30 hover:bg-[#6366f1]/10 text-slate-800 dark:text-gray-100"><span class="magnetic-target">View Resume</span></a>
                    </div>
                    <div class="mt-5 flex flex-wrap gap-2 text-sm">
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $socials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e($s->url); ?>" target="_blank" class="inline-flex items-center gap-2 px-3 py-1.5 rounded-md ring-1 ring-gray-200/70 hover:bg-white/60 text-gray-700 dark:text-gray-200"><span><?php echo e($s->label); ?></span></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>
                <div class="justify-self-center">
                    <div class="relative">
                        <div class="relative w-40 h-40 md:w-56 md:h-56 rounded-full p-[3px] bg-gray-200 dark:bg-slate-800 shadow-md">
                            <div class="w-full h-full rounded-full bg-white dark:bg-slate-900 overflow-hidden flex items-center justify-center">
                                <!--[if BLOCK]><![endif]--><?php if($profile?->avatar_url): ?>
                                    <img src="<?php echo e($profile->avatar_url); ?>" alt="Avatar" class="w-full h-full object-cover" width="224" height="224" decoding="async">
                                <?php else: ?>
                                    <span class="text-5xl">👨‍💻</span>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php break; ?>
        <?php case ('glass'): ?>
            <div aria-hidden="true" class="pointer-events-none absolute inset-0 -z-10 bg-animated-gradient opacity-20"></div>
            <div class="relative z-10 container mx-auto max-w-6xl px-4 py-20 grid md:grid-cols-2 gap-10 items-center">
                <div class="rounded-2xl border border-white/30 dark:border-white/10 bg-white/60 dark:bg-slate-900/40 backdrop-blur p-6 text-slate-900 dark:text-gray-100 shadow-xl">
                    <h1 class="text-4xl md:text-5xl font-extrabold tracking-tight text-slate-900 dark:text-white"><span style="font-family:'Cinzel',serif;"><?php echo e($profile->name ?? 'Your Name'); ?></span></h1>
                    <p class="mt-2 text-base md:text-lg text-gray-700/90 dark:text-gray-300">
                        <span data-typewriter data-phrases="<?php echo e($profile?->typewriter_phrases ?: implode('|', array_filter([
                                $profile->title ?? 'Laravel Developer','Livewire Enthusiast','Clean Code Advocate','Problem Solver',
                            ]))); ?>" data-loop="true" data-speed="110" data-delay="1500"><?php echo e($profile->title ?? 'Laravel Developer'); ?></span>
                        <span class="tw-caret" aria-hidden="true">|</span>
                    </p>
                    <p class="mt-4 text-sm md:text-base leading-relaxed text-gray-700 dark:text-gray-300"><?php echo e($profile->bio ?? 'Write a short, impactful bio here.'); ?></p>
                    <div class="mt-7 flex flex-wrap gap-3">
                        <a href="#contact" data-magnetic class="magnetic-wrap inline-flex items-center gap-2 px-5 py-2 rounded-md bg-[#6366f1] text-white hover:bg-[#5558e6] shadow-sm"><span class="magnetic-target">Hire Me</span></a>
                        <a href="<?php echo e(route('resume.view')); ?>" data-magnetic class="magnetic-wrap inline-flex items-center gap-2 px-4 py-2 rounded-md ring-1 ring-[#6366f1]/30 hover:bg-[#6366f1]/10 text-slate-800 dark:text-gray-100"><span class="magnetic-target">View Resume</span></a>
                    </div>
                    <div class="mt-5 flex flex-wrap gap-2 text-sm">
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $socials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e($s->url); ?>" target="_blank" class="inline-flex items-center gap-2 px-3 py-1.5 rounded-md ring-1 ring-gray-200/70 hover:bg-white/60 text-gray-700 dark:text-gray-200"><span><?php echo e($s->label); ?></span></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>
                <div class="justify-self-center">
                    <div class="relative">
                        <div class="absolute -inset-6 rounded-full bg-gradient-to-br from-indigo-500/25 to-purple-500/25 blur-2xl"></div>
                        <div class="relative w-40 h-40 md:w-56 md:h-56 rounded-full p-[3px] bg-gradient-to-br from-indigo-500 to-purple-500 shadow-xl">
                            <div class="w-full h-full rounded-full bg-white/95 dark:bg-slate-900/70 overflow-hidden flex items-center justify-center">
                                <!--[if BLOCK]><![endif]--><?php if($profile?->avatar_url): ?>
                                    <img src="<?php echo e($profile->avatar_url); ?>" alt="Avatar" class="w-full h-full object-cover" width="224" height="224" decoding="async">
                                <?php else: ?>
                                    <span class="text-5xl">👨‍💻</span>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php break; ?>
        <?php case ('minimal-accent'): ?>
        <?php default: ?>
            <!-- Accent gradient spot -->
            <div aria-hidden="true" class="pointer-events-none absolute -left-40 top-10 w-[28rem] h-[28rem] rounded-full bg-gradient-to-br from-indigo-400/30 to-purple-300/30 blur-3xl"></div>
            <div class="relative z-10 container mx-auto max-w-6xl px-4 py-20 grid md:grid-cols-2 gap-10 items-center">
                <!-- Left: Minimal + Accent -->
                <div class="text-slate-900 dark:text-gray-100">
                    <h1 class="text-4xl md:text-5xl font-extrabold tracking-tight text-slate-900 dark:text-white"><span style="font-family:'Cinzel',serif;"><?php echo e($profile->name ?? 'Your Name'); ?></span></h1>
                    <p class="mt-2 text-base md:text-lg text-gray-700/90 dark:text-gray-300">
                        <span data-typewriter data-phrases="<?php echo e($profile?->typewriter_phrases ?: implode('|', array_filter([
                                $profile->title ?? 'Laravel Developer','Livewire Enthusiast','Clean Code Advocate','Problem Solver',
                            ]))); ?>" data-loop="true" data-speed="110" data-delay="1500"><?php echo e($profile->title ?? 'Laravel Developer'); ?></span>
                        <span class="tw-caret" aria-hidden="true">|</span>
                    </p>
                    <p class="mt-4 text-sm md:text-base leading-relaxed text-gray-700 dark:text-gray-300"><?php echo e($profile->bio ?? 'Write a short, impactful bio here.'); ?></p>
                    <div class="mt-7 flex flex-wrap gap-3">
                        <a href="#contact" data-magnetic class="magnetic-wrap inline-flex items-center gap-2 px-5 py-2 rounded-md bg-[#6366f1] text-white hover:bg-[#5558e6] shadow-sm"><span class="magnetic-target">Hire Me</span></a>
                        <a href="<?php echo e(route('resume.view')); ?>" data-magnetic class="magnetic-wrap inline-flex items-center gap-2 px-4 py-2 rounded-md ring-1 ring-[#6366f1]/30 hover:bg-[#6366f1]/10 text-slate-800 dark:text-gray-100"><span class="magnetic-target">View Resume</span></a>
                    </div>
                    <div class="mt-5 flex flex-wrap gap-2 text-sm">
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $socials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e($s->url); ?>" target="_blank" class="inline-flex items-center gap-2 px-3 py-1.5 rounded-md ring-1 ring-gray-200/70 hover:bg-white/60 text-gray-700 dark:text-gray-200"><span><?php echo e($s->label); ?></span></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>
                <!-- Right: Circular avatar with subtle ring/glow -->
                <div class="justify-self-center">
                    <div class="relative">
                        <div class="absolute -inset-6 rounded-full bg-gradient-to-br from-indigo-500/20 to-purple-500/20 blur-2xl"></div>
                        <div class="relative w-40 h-40 md:w-56 md:h-56 rounded-full p-[3px] bg-gradient-to-br from-indigo-500 to-purple-500 shadow-xl">
                            <div class="w-full h-full rounded-full bg-white/95 dark:bg-slate-900/70 overflow-hidden flex items-center justify-center">
                                <!--[if BLOCK]><![endif]--><?php if($profile?->avatar_url): ?>
                                    <img src="<?php echo e($profile->avatar_url); ?>" alt="Avatar" class="w-full h-full object-cover">
                                <?php else: ?>
                                    <span class="text-5xl">👨‍💻</span>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    <?php endswitch; ?><!--[if ENDBLOCK]><![endif]-->
</section>

<section id="services" class="py-16 reveal">
    <div class="container mx-auto max-w-6xl px-4">
        <h2 class="text-2xl font-bold mb-8 inline-flex items-center gap-2">
            <span class="inline-block h-5 w-1 rounded bg-[#6366f1]"></span>
            Services
        </h2>
        <div class="grid md:grid-cols-3 gap-6">
            <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $svc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="card card-accent card-gradient-2 card-hover p-6 reveal-up">
                <div class="text-3xl"><?php echo e($svc->icon); ?></div>
                <h3 class="mt-3 font-semibold text-lg"><?php echo e($svc->title); ?></h3>
                <p class="mt-2 text-gray-600"><?php echo e($svc->summary); ?></p>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-gray-500">No services added yet.</p>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>
    </div>
    </section>

<section id="testimonials" class="py-16 reveal">
    <div class="container mx-auto max-w-6xl px-4">
        <h2 class="text-2xl font-bold mb-8 inline-flex items-center gap-2">
            <span class="inline-block h-5 w-1 rounded bg-[#6366f1]"></span>
            Testimonials
        </h2>
        <div class="grid md:grid-cols-2 gap-6">
            <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="card card-accent card-gradient-1 card-hover p-6 reveal-up">
                <blockquote class="text-gray-700 italic">“<?php echo e($t->quote); ?>”</blockquote>
                <div class="mt-4 flex items-center gap-3">
                    <div class="h-10 w-10 rounded-full bg-gray-100 flex items-center justify-center overflow-hidden">
                        <!--[if BLOCK]><![endif]--><?php if($t->avatar_url): ?>
                            <img src="<?php echo e($t->avatar_url); ?>" alt="<?php echo e($t->author); ?>" class="w-full h-full object-cover" width="40" height="40" loading="lazy" decoding="async">
                        <?php else: ?>
                            <span>💬</span>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                    <div>
                        <div class="font-medium"><?php echo e($t->author); ?></div>
                        <div class="text-sm text-gray-500"><?php echo e($t->role); ?> <!--[if BLOCK]><![endif]--><?php if($t->company): ?> · <?php echo e($t->company); ?> <?php endif; ?><!--[if ENDBLOCK]><![endif]--></div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-gray-500">No testimonials yet.</p>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>
    </div>
</section>

<section id="projects" class="py-16 reveal">
    <div class="container mx-auto max-w-6xl px-4">
        <div class="flex items-end justify-between mb-8">
            <h2 class="text-2xl font-bold inline-flex items-center gap-2">
                <span class="inline-block h-5 w-1 rounded bg-[#6366f1]"></span>
                Projects
            </h2>
            <a href="#projects" class="text-sm text-indigo-600">View all</a>
        </div>
        <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="group card card-hover overflow-hidden reveal-up">
                <!--[if BLOCK]><![endif]--><?php if($p->image_url): ?>
                    <div class="relative" data-tilt>
                        <img src="<?php echo e($p->image_url); ?>" loading="lazy" class="h-40 w-full object-cover tilt-img blur-up" alt="<?php echo e($p->title); ?>">
                    </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                <div class="p-5">
                    <div class="flex items-center justify-between gap-2">
                        <h3 class="font-semibold text-lg"><?php echo e($p->title); ?></h3>
                        <!--[if BLOCK]><![endif]--><?php if($p->year): ?>
                            <span class="badge badge-indigo"><?php echo e($p->year); ?></span>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                    <p class="mt-2 text-gray-600 line-clamp-3"><?php echo e($p->description); ?></p>
                    <?php ($techs = collect(explode(',', (string)$p->tech_stack))->map(fn($t) => trim($t))->filter()); ?>
                    <!--[if BLOCK]><![endif]--><?php if($techs->count()): ?>
                        <div class="mt-3 flex flex-wrap gap-2">
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $techs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tech): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php ($t = strtolower($tech)); ?>
                                <?php ($cls = match(true) {
                                    str_contains($t,'laravel') || str_contains($t,'php') => 'badge-rose',
                                    str_contains($t,'vue') || str_contains($t,'node') => 'badge-emerald',
                                    str_contains($t,'react') || str_contains($t,'next') => 'badge-cyan',
                                    str_contains($t,'tailwind') || str_contains($t,'css') => 'badge-indigo',
                                    str_contains($t,'mysql') || str_contains($t,'sql') => 'badge-amber',
                                    default => 'badge'
                                }); ?>
                                <span class="badge <?php echo e($cls); ?>"><?php echo e($tech); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    <div class="mt-4 flex items-center gap-3 text-sm">
                        <!--[if BLOCK]><![endif]--><?php if($p->github_url): ?>
                            <a class="text-gray-700 hover:text-black" target="_blank" href="<?php echo e($p->github_url); ?>">GitHub</a>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <!--[if BLOCK]><![endif]--><?php if($p->live_url): ?>
                            <a class="text-[#6366f1] hover:text-[#5558e6]" target="_blank" href="<?php echo e($p->live_url); ?>">Live</a>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-gray-500">No projects yet.</p>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>
    </div>
</section>

<section id="experience" class="py-16 reveal">
    <div class="container mx-auto max-w-6xl px-4">
        <h2 class="text-2xl font-bold mb-8 inline-flex items-center gap-2">
            <span class="inline-block h-5 w-1 rounded bg-[#6366f1]"></span>
            Experience
        </h2>
        <div class="space-y-6">
            <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $experiences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="card card-accent card-gradient-3 card-hover p-5 reveal-up">
                <div class="flex items-center justify-between flex-wrap gap-2">
                    <div>
                        <h3 class="font-semibold"><?php echo e($e->role); ?> · <?php echo e($e->company); ?></h3>
                        <p class="text-sm text-gray-600"><?php echo e($e->location); ?></p>
                    </div>
                    <span class="badge"><?php echo e(optional($e->start_date)->format('M Y')); ?> — <?php echo e($e->end_date ? $e->end_date->format('M Y') : 'Present'); ?></span>
                </div>
                <p class="mt-3 text-gray-700"><?php echo e($e->description); ?></p>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-gray-500">No experience added yet.</p>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>
    </div>
</section>

<section id="skills" class="py-16 reveal">
    <div class="container mx-auto max-w-6xl px-4">
        <h2 class="text-2xl font-bold mb-8 inline-flex items-center gap-2">
            <span class="inline-block h-5 w-1 rounded bg-[#6366f1]"></span>
            Skills
        </h2>
        <div class="grid sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="card card-hover p-4 flex items-center justify-between reveal-up">
                <span class="font-medium"><?php echo e($s->name); ?></span>
                <span class="badge badge-emerald"><?php echo e($s->proficiency); ?>%</span>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-gray-500">No skills added yet.</p>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>
    </div>
</section>

<section id="contact" class="py-16 reveal">
    <div class="container mx-auto max-w-6xl px-4">
        <h2 class="text-2xl font-bold mb-6 inline-flex items-center gap-2">
            <span class="inline-block h-5 w-1 rounded bg-[#6366f1]"></span>
            Contact
        </h2>
        <div class="rounded-xl border border-gray-200 bg-white p-6">
            <p class="text-gray-700">Feel free to reach out at
                <a class="text-indigo-600 hover:underline" href="mailto:<?php echo e($profile->email ?? 'you@example.com'); ?>"><?php echo e($profile->email ?? 'you@example.com'); ?></a>
            </p>
        </div>
    </div>
</section>
</div>
<?php /**PATH C:\xampp\htdocs\portfolio\resources\views/livewire/portfolio.blade.php ENDPATH**/ ?>