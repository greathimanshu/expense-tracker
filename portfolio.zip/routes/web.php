<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ResumeController;
use App\Livewire\Portfolio as PortfolioPage;
use App\Livewire\Admin\Login as AdminLogin;
use App\Livewire\Admin\Dashboard as AdminDashboard;
use App\Livewire\Admin\ProfileEditor as AdminProfileEditor;
use App\Livewire\Admin\Projects as AdminProjects;
use App\Livewire\Admin\Experiences as AdminExperiences;
use App\Livewire\Admin\Skills as AdminSkills;
use App\Livewire\Admin\SocialLinks as AdminSocialLinks;
use App\Livewire\Admin\Services as AdminServices;
use App\Livewire\Admin\Testimonials as AdminTestimonials;
use App\Livewire\Admin\Educations as AdminEducations;
use App\Livewire\Admin\Certificates as AdminCertificates;
use App\Livewire\Admin\Theme as AdminTheme;
use App\Livewire\Admin\Seo as AdminSeo;
use App\Livewire\Admin\Account as AdminAccount;
use App\Http\Controllers\ThemePreviewController;
use Illuminate\Support\Facades\Auth;

Route::get('/', PortfolioPage::class)->name('portfolio');

// Public resume routes
Route::get('/resume', [ResumeController::class, 'view'])->name('resume.view');
Route::get('/resume.json', [ResumeController::class, 'json'])->name('resume.json');
Route::get('/resume.md', [ResumeController::class, 'markdown'])->name('resume.markdown');
Route::get('/resume.pdf', [ResumeController::class, 'pdf'])->name('resume.pdf');

// Admin auth routes
Route::middleware('guest')->group(function () {
    Route::get('/admin/login', AdminLogin::class)->name('admin.login');
    // Alias for default auth middleware redirect
    Route::get('/login', AdminLogin::class)->name('login');
});

Route::post('/admin/logout', function () {
    Auth::logout();
    request()->session()->invalidate();
    request()->session()->regenerateToken();
    return redirect()->route('admin.login');
})->name('admin.logout');

// Admin area
Route::prefix('admin')->middleware(['auth','single.session'])->name('admin.')->group(function () {
    Route::get('/', AdminDashboard::class)->name('dashboard');
    Route::get('/profile', AdminProfileEditor::class)->name('profile');
    Route::get('/projects', AdminProjects::class)->name('projects');
    Route::get('/experience', AdminExperiences::class)->name('experience');
    Route::get('/skills', AdminSkills::class)->name('skills');
    Route::get('/social-links', AdminSocialLinks::class)->name('socials');
    Route::get('/services', AdminServices::class)->name('services');
    Route::get('/testimonials', AdminTestimonials::class)->name('testimonials');
    Route::get('/education', AdminEducations::class)->name('education');
    Route::get('/certificates', AdminCertificates::class)->name('certificates');
    Route::get('/theme', AdminTheme::class)->name('theme');
    Route::get('/seo', AdminSeo::class)->name('seo');
    Route::get('/account', AdminAccount::class)->name('account');
    Route::get('/theme/preview/{theme}', PortfolioPage::class)->name('theme.preview');
});
