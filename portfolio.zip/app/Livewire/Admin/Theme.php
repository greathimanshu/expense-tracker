<?php

namespace App\Livewire\Admin;

use App\Models\Profile;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Validate;
use Livewire\Component;

class Theme extends Component
{
    #[Validate('required|in:minimal,minimal-accent,glass,purple')]
    public string $site_theme = 'minimal-accent';

    public function mount(): void
    {
        $p = Profile::first();
        if ($p) {
            $this->site_theme = $p->site_theme ?: 'minimal-accent';
        }
    }

    public function setTheme(string $theme): void
    {
        $this->site_theme = $theme;
        $this->validateOnly('site_theme');
        $p = Profile::first();
        if (!$p) {
            $p = new Profile();
        }
        $p->site_theme = $this->site_theme;
        $p->save();
        session()->flash('status', 'Theme updated to '.str_replace('-', ' ', $this->site_theme).'.');
    }

    #[Layout('layouts.admin')]
    public function render()
    {
        return view('livewire.admin.theme');
    }
}
