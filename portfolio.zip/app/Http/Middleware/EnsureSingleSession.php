<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

class EnsureSingleSession
{
    public function handle(Request $request, Closure $next): Response
    {
        if (Auth::check()) {
            $user = Auth::user();
            $currentId = (string) ($user->current_session_id ?? '');
            $thisId = (string) $request->session()->getId();

            if ($currentId && $currentId !== $thisId) {
                // Another session has taken over; logout this session
                Auth::logout();
                $request->session()->invalidate();
                $request->session()->regenerateToken();

                return redirect()->route('admin.login')
                    ->withErrors(['email' => 'You have been logged out because your account was used to sign in elsewhere.']);
            }
        }

        return $next($request);
    }
}
