<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Profile extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'title',
        'typewriter_phrases',
        'site_theme',
        'bio',
        'location',
        'email',
        'phone',
        'avatar_url',
        'resume_url',
    ];
}
