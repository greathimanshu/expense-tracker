<!doctype html>
<html lang="en" class="h-full">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{{ $title ?? 'Portfolio' }} · Purple</title>
  <meta name="description" content="{{ $metaDescription ?? 'Laravel + Livewire portfolio SPA' }}">
  @isset($metaKeywords)
    <meta name="keywords" content="{{ $metaKeywords }}">
  @endisset
  <link rel="canonical" href="{{ url()->current() }}">

  <!-- Open Graph -->
  <meta property="og:type" content="website">
  <meta property="og:title" content="{{ $ogTitle ?? ($title ?? 'Portfolio') }}">
  <meta property="og:description" content="{{ $ogDescription ?? ($metaDescription ?? 'Laravel + Livewire portfolio SPA') }}">
  <meta property="og:url" content="{{ url()->current() }}">
  @isset($ogImage)
    <meta property="og:image" content="{{ $ogImage }}">
  @endisset

  <!-- Twitter -->
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="{{ $twitterTitle ?? ($title ?? 'Portfolio') }}">
  <meta name="twitter:description" content="{{ $twitterDescription ?? ($metaDescription ?? 'Laravel + Livewire portfolio SPA') }}">
  @isset($ogImage)
    <meta name="twitter:image" content="{{ $ogImage }}">
  @endisset
  @vite(['resources/css/app.css','resources/js/app.js'])
  @livewireStyles
  <style>
    /* Animated gradient for header/footer bars and background orbs */
    @keyframes gradientShift { 0%{background-position:0% 50%} 50%{background-position:100% 50%} 100%{background-position:0% 50%} }
    @keyframes floatSlow { 0%{ transform: translateY(0) translateX(0);} 50%{ transform: translateY(-12px) translateX(6px);} 100%{ transform: translateY(0) translateX(0);} }
    html { scroll-behavior: smooth; }
    /* Ensure anchors don't slide under sticky header */
    .section-anchor { scroll-margin-top: 96px; }
  </style>
</head>
<body class="h-full bg-gradient-to-br from-purple-50 via-fuchsia-50 to-indigo-50 text-slate-800 antialiased">
  <!-- Animated background orbs -->
  <div aria-hidden="true" class="pointer-events-none fixed inset-0 -z-10 overflow-hidden">
    <div class="absolute -top-10 -left-16 h-64 w-64 rounded-full blur-3xl opacity-25"
         style="background:linear-gradient(45deg,#a78bfa,#f0abfc,#818cf8); background-size:200% 200%; animation: gradientShift 12s ease infinite, floatSlow 10s ease-in-out infinite;"></div>
    <div class="absolute bottom-[-5rem] right-[-6rem] h-72 w-72 rounded-full blur-3xl opacity-20"
         style="background:linear-gradient(45deg,#c084fc,#a78bfa,#7c3aed); background-size:200% 200%; animation: gradientShift 14s ease-in-out infinite, floatSlow 12s ease-in-out infinite;"></div>
  </div>

  <div class="min-h-screen flex flex-col">
    @include('components.site.themes.purple.header')
    <main class="flex-1 pt-2 sm:pt-4">{{ $slot }}</main>
    @include('components.site.themes.purple.footer')
  </div>
  @livewireScripts
</body>
</html>
