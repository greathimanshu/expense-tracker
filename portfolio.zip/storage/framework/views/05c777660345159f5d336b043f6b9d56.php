<?php ($theme = $__forceTheme ?? ($profile->site_theme ?? 'purple')); ?>

<!-- Purple themed page: professional hero, refined sections, responsive grids, subtle motion -->
<div>
  <!-- Hero -->
  <section id="home" class="section-anchor relative overflow-hidden">
    <!-- accent orbs -->
    <div class="pointer-events-none absolute inset-0 -z-10">
      <div class="absolute -left-20 -top-16 h-72 w-72 rounded-full blur-3xl opacity-30"
           style="background:linear-gradient(45deg,#a78bfa,#c084fc,#7c3aed); background-size:200% 200%; animation: gradientShift 12s ease infinite"></div>
      <div class="absolute right-[-5rem] top-10 h-64 w-64 rounded-full blur-3xl opacity-25"
           style="background:linear-gradient(45deg,#c084fc,#a78bfa,#7c3aed); background-size:200% 200%; animation: gradientShift 16s ease-in-out infinite"></div>
    </div>

    <div class="relative z-10 container mx-auto max-w-6xl px-4 py-16 sm:py-20 lg:py-24 grid gap-10 lg:grid-cols-12 items-center">
      <div class="lg:col-span-7">
        <h1 class="text-4xl sm:text-5xl font-extrabold leading-tight tracking-tight text-slate-900">
          <span style="font-family:'Cinzel',serif;"><?php echo e($profile->name ?? 'Your Name'); ?></span>
        </h1>
        <div class="mt-2 h-1 w-24 rounded-full" style="background:linear-gradient(90deg,#7c3aed,#a78bfa,#7c3aed); background-size:200% 100%; animation: gradientShift 14s linear infinite"></div>
        <p class="mt-3 text-lg sm:text-xl text-slate-700"><?php echo e($profile->title ?? 'Full‑Stack Developer'); ?></p>
        <!--[if BLOCK]><![endif]--><?php if($profile?->bio): ?>
          <p class="mt-4 text-slate-700/90 max-w-2xl"><?php echo e($profile->bio); ?></p>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        <div class="mt-6 flex flex-wrap gap-3">
          <?php ($resumeHref = $profile?->resume_url ?: route('resume.view')); ?>
          <a href="<?php echo e($resumeHref); ?>" target="_blank" class="inline-flex items-center justify-center rounded-md px-4 py-2 text-white shadow-sm transition focus:outline-none focus:ring-2 focus:ring-purple-400"
             style="background:linear-gradient(90deg,#7c3aed,#a78bfa,#7c3aed); background-size:300% 100%; animation: gradientShift 14s linear infinite;">
            Download Resume
          </a>
          <a href="#contact" class="inline-flex items-center justify-center rounded-md border border-purple-200/80 px-4 py-2 text-slate-800 hover:bg-purple-50 transition focus:outline-none focus:ring-2 focus:ring-purple-300">Contact</a>
        </div>
        <?php ($validSocials = collect($socials ?? [])->filter(fn($s) => !empty($s->platform) && !empty($s->url))); ?>
        <!--[if BLOCK]><![endif]--><?php if($validSocials->count()): ?>
          <div class="mt-6 flex flex-wrap gap-2">
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $validSocials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <a href="<?php echo e($s->url); ?>" target="_blank" class="inline-flex items-center gap-1 rounded-md border border-purple-200 px-3 py-1.5 text-slate-800 hover:bg-purple-50 text-sm"><?php echo e($s->platform); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
          </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
      </div>
      <div class="lg:col-span-5 flex justify-center lg:justify-end">
        <!--[if BLOCK]><![endif]--><?php if($profile?->avatar_url): ?>
          <img src="<?php echo e($profile->avatar_url); ?>" alt="Avatar" class="h-40 w-40 sm:h-48 sm:w-48 lg:h-56 lg:w-56 rounded-full border-4 border-white shadow-xl object-cover">
        <?php else: ?>
          <div class="h-40 w-40 sm:h-48 sm:w-48 lg:h-56 lg:w-56 rounded-full bg-white/70 border border-purple-100 shadow-xl"></div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
      </div>
    </div>
  </section>

  <!-- Projects -->
  <section id="projects" class="section-anchor py-12 sm:py-14 lg:py-16">
    <div class="container mx-auto max-w-6xl px-4">
      <h2 class="text-2xl sm:text-3xl font-extrabold tracking-tight bg-clip-text text-transparent"
          style="background:linear-gradient(90deg,#7c3aed,#a78bfa,#c084fc,#7c3aed); background-size:300% 100%; animation: gradientShift 12s linear infinite;">Projects</h2>
      <div class="mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <article class="group rounded-xl border border-purple-100 bg-white/80 backdrop-blur shadow-sm hover:shadow-md transition-all duration-200 hover:-translate-y-0.5">
            <div class="p-4">
              <h3 class="font-semibold text-slate-900 group-hover:text-purple-700"><?php echo e($project->title); ?></h3>
              <p class="mt-1 text-sm text-slate-600"><?php echo e($project->description); ?></p>
              <!--[if BLOCK]><![endif]--><?php if($project->url): ?>
                <a href="<?php echo e($project->url); ?>" target="_blank"
                   class="mt-3 inline-flex items-center gap-1 text-sm text-purple-700 hover:text-purple-800">View →</a>
              <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </div>
          </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
      </div>
    </div>
  </section>

  <!-- Experience & Skills -->
  <section id="experience" class="section-anchor py-12 sm:py-14 lg:py-16 bg-white/70">
    <div class="container mx-auto max-w-6xl px-4 grid gap-8 lg:grid-cols-2">
      <div>
        <h2 class="text-2xl sm:text-3xl font-extrabold text-slate-900">Experience</h2>
        <div class="mt-4 space-y-3">
          <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $experiences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="rounded-lg border border-purple-100 bg-white/80 p-4 shadow-sm">
              <h3 class="font-semibold text-slate-900"><?php echo e($exp->role); ?> · <span class="text-purple-700"><?php echo e($exp->company); ?></span></h3>
              <p class="text-xs text-slate-600"><?php echo e($exp->start_date); ?> — <?php echo e($exp->end_date ?: 'Present'); ?></p>
              <p class="mt-2 text-sm text-slate-700"><?php echo e($exp->description); ?></p>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </div>
      </div>
      <div id="skills">
        <h2 class="text-2xl sm:text-3xl font-extrabold text-slate-900">Skills</h2>
        <div class="mt-4 grid grid-cols-2 sm:grid-cols-3 gap-3">
          <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="rounded-lg border border-purple-100 bg-white/80 px-3 py-2 text-sm text-slate-800 flex items-center justify-between">
              <span><?php echo e($skill->name); ?></span>
              <span class="text-purple-700"><?php echo e($skill->proficiency); ?>%</span>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </div>
      </div>
    </div>
  </section>

  <!-- Services & Testimonials -->
  <section id="services" class="section-anchor py-12 sm:py-14 lg:py-16">
    <div class="container mx-auto max-w-6xl px-4 grid gap-8 lg:grid-cols-2">
      <div>
        <h2 class="text-2xl sm:text-3xl font-extrabold text-slate-900">Services</h2>
        <div class="mt-4 grid sm:grid-cols-2 gap-4">
          <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $svc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="rounded-lg border border-purple-100 bg-white/80 p-4 shadow-sm hover:shadow-md transition-all duration-200 hover:-translate-y-0.5">
              <h3 class="font-semibold text-slate-900"><?php echo e($svc->title); ?></h3>
              <p class="mt-1 text-sm text-slate-700"><?php echo e($svc->description); ?></p>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </div>
      </div>
      <div id="testimonials">
        <h2 class="text-2xl sm:text-3xl font-extrabold text-slate-900">Testimonials</h2>
        <div class="mt-4 space-y-3">
          <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="rounded-lg border border-purple-100 bg-white/80 p-4 shadow-sm">
              <p class="text-sm text-slate-800">“<?php echo e($t->quote); ?>”</p>
              <p class="mt-1 text-xs text-purple-700">— <?php echo e($t->author); ?></p>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </div>
      </div>
    </div>
  </section>

  <!-- Contact -->
  <section id="contact" class="section-anchor py-12 sm:py-14 lg:py-16 bg-white/70">
    <div class="container mx-auto max-w-6xl px-4">
      <h2 class="text-2xl sm:text-3xl font-extrabold text-slate-900">Contact</h2>
      <div class="mt-4 rounded-xl border border-purple-100 bg-white/80 p-4 shadow-sm">
        <div class="grid sm:grid-cols-2 gap-4 text-sm">
          <div>
            <div class="text-slate-700"><strong>Email:</strong> <a class="text-purple-700 hover:text-purple-800" href="mailto:<?php echo e($profile->email); ?>"><?php echo e($profile->email); ?></a></div>
            <!--[if BLOCK]><![endif]--><?php if($profile->phone): ?>
              <div class="text-slate-700 mt-1"><strong>Phone:</strong> <a class="text-purple-700 hover:text-purple-800" href="tel:<?php echo e($profile->phone); ?>"><?php echo e($profile->phone); ?></a></div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            <!--[if BLOCK]><![endif]--><?php if($profile->location): ?>
              <div class="text-slate-700 mt-1"><strong>Location:</strong> <?php echo e($profile->location); ?></div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
          </div>
          <div class="flex flex-wrap gap-2">
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $socials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <a target="_blank" href="<?php echo e($s->url); ?>" class="inline-flex items-center gap-1 rounded-md border border-purple-200 px-3 py-1.5 text-slate-800 hover:bg-purple-50"><?php echo e($s->platform); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
          </div>
        </div>
      </div>
    </div>
  </section>
</div>
<?php /**PATH C:\xampp\htdocs\portfolio\resources\views/livewire/themes/purple.blade.php ENDPATH**/ ?>