<!doctype html>
<html lang="en" class="h-full">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?php echo e($title ?? 'Portfolio'); ?> · Minimal</title>
  <meta name="description" content="<?php echo e($metaDescription ?? 'Laravel + Livewire portfolio SPA'); ?>">
  <?php if(isset($metaKeywords)): ?>
    <meta name="keywords" content="<?php echo e($metaKeywords); ?>">
  <?php endif; ?>
  <link rel="canonical" href="<?php echo e(url()->current()); ?>">

  <!-- Open Graph -->
  <meta property="og:type" content="website">
  <meta property="og:title" content="<?php echo e($ogTitle ?? ($title ?? 'Portfolio')); ?>">
  <meta property="og:description" content="<?php echo e($ogDescription ?? ($metaDescription ?? 'Laravel + Livewire portfolio SPA')); ?>">
  <meta property="og:url" content="<?php echo e(url()->current()); ?>">
  <?php if(isset($ogImage)): ?>
    <meta property="og:image" content="<?php echo e($ogImage); ?>">
  <?php endif; ?>

  <!-- Twitter -->
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="<?php echo e($twitterTitle ?? ($title ?? 'Portfolio')); ?>">
  <meta name="twitter:description" content="<?php echo e($twitterDescription ?? ($metaDescription ?? 'Laravel + Livewire portfolio SPA')); ?>">
  <?php if(isset($ogImage)): ?>
    <meta name="twitter:image" content="<?php echo e($ogImage); ?>">
  <?php endif; ?>
  <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css','resources/js/app.js']); ?>
  <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

</head>
<body class="h-full bg-white text-slate-800 antialiased">
  <div class="min-h-screen flex flex-col">
    <?php echo $__env->make('components.site.themes.minimal.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <main class="flex-1"><?php echo e($slot); ?></main>
    <?php echo $__env->make('components.site.themes.minimal.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
  </div>
  <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\portfolio\resources\views/layouts/themes/minimal.blade.php ENDPATH**/ ?>