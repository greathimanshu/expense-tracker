<div>
@php($theme = $__forceTheme ?? ($profile->site_theme ?? 'minimal-accent'))
<section id="home" class="relative overflow-hidden reveal in-view">
    @switch($theme)
        @case('minimal')
            <div class="relative z-10 container mx-auto max-w-6xl px-4 py-20 grid md:grid-cols-2 gap-10 items-center">
                <div class="text-slate-900 dark:text-gray-100">
                    <h1 class="text-4xl md:text-5xl font-extrabold tracking-tight text-slate-900 dark:text-white"><span style="font-family:'Cinzel',serif;">{{ $profile->name ?? 'Your Name' }}</span></h1>
                    <p class="mt-2 text-base md:text-lg text-gray-700/90 dark:text-gray-300">
                        <span data-typewriter data-phrases="{{ $profile?->typewriter_phrases ?: implode('|', array_filter([
                                $profile->title ?? 'Laravel Developer','Livewire Enthusiast','Clean Code Advocate','Problem Solver',
                            ])) }}" data-loop="true" data-speed="110" data-delay="1500">{{ $profile->title ?? 'Laravel Developer' }}</span>
                        <span class="tw-caret" aria-hidden="true">|</span>
                    </p>
                    <p class="mt-4 text-sm md:text-base leading-relaxed text-gray-700 dark:text-gray-300">{{ $profile->bio ?? 'Write a short, impactful bio here.' }}</p>
                    <div class="mt-7 flex flex-wrap gap-3">
                        <a href="#contact" data-magnetic class="magnetic-wrap inline-flex items-center gap-2 px-5 py-2 rounded-md bg-[#6366f1] text-white hover:bg-[#5558e6] shadow-sm"><span class="magnetic-target">Hire Me</span></a>
                        <a href="{{ route('resume.view') }}" data-magnetic class="magnetic-wrap inline-flex items-center gap-2 px-4 py-2 rounded-md ring-1 ring-[#6366f1]/30 hover:bg-[#6366f1]/10 text-slate-800 dark:text-gray-100"><span class="magnetic-target">View Resume</span></a>
                    </div>
                    <div class="mt-5 flex flex-wrap gap-2 text-sm">
                        @foreach($socials as $s)
                            <a href="{{ $s->url }}" target="_blank" class="inline-flex items-center gap-2 px-3 py-1.5 rounded-md ring-1 ring-gray-200/70 hover:bg-white/60 text-gray-700 dark:text-gray-200"><span>{{ $s->label }}</span></a>
                        @endforeach
                    </div>
                </div>
                <div class="justify-self-center">
                    <div class="relative">
                        <div class="relative w-40 h-40 md:w-56 md:h-56 rounded-full p-[3px] bg-gray-200 dark:bg-slate-800 shadow-md">
                            <div class="w-full h-full rounded-full bg-white dark:bg-slate-900 overflow-hidden flex items-center justify-center">
                                @if($profile?->avatar_url)
                                    <img src="{{ $profile->avatar_url }}" alt="Avatar" class="w-full h-full object-cover" width="224" height="224" decoding="async">
                                @else
                                    <span class="text-5xl">👨‍💻</span>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            @break
        @case('glass')
            <div aria-hidden="true" class="pointer-events-none absolute inset-0 -z-10 bg-animated-gradient opacity-20"></div>
            <div class="relative z-10 container mx-auto max-w-6xl px-4 py-20 grid md:grid-cols-2 gap-10 items-center">
                <div class="rounded-2xl border border-white/30 dark:border-white/10 bg-white/60 dark:bg-slate-900/40 backdrop-blur p-6 text-slate-900 dark:text-gray-100 shadow-xl">
                    <h1 class="text-4xl md:text-5xl font-extrabold tracking-tight text-slate-900 dark:text-white"><span style="font-family:'Cinzel',serif;">{{ $profile->name ?? 'Your Name' }}</span></h1>
                    <p class="mt-2 text-base md:text-lg text-gray-700/90 dark:text-gray-300">
                        <span data-typewriter data-phrases="{{ $profile?->typewriter_phrases ?: implode('|', array_filter([
                                $profile->title ?? 'Laravel Developer','Livewire Enthusiast','Clean Code Advocate','Problem Solver',
                            ])) }}" data-loop="true" data-speed="110" data-delay="1500">{{ $profile->title ?? 'Laravel Developer' }}</span>
                        <span class="tw-caret" aria-hidden="true">|</span>
                    </p>
                    <p class="mt-4 text-sm md:text-base leading-relaxed text-gray-700 dark:text-gray-300">{{ $profile->bio ?? 'Write a short, impactful bio here.' }}</p>
                    <div class="mt-7 flex flex-wrap gap-3">
                        <a href="#contact" data-magnetic class="magnetic-wrap inline-flex items-center gap-2 px-5 py-2 rounded-md bg-[#6366f1] text-white hover:bg-[#5558e6] shadow-sm"><span class="magnetic-target">Hire Me</span></a>
                        <a href="{{ route('resume.view') }}" data-magnetic class="magnetic-wrap inline-flex items-center gap-2 px-4 py-2 rounded-md ring-1 ring-[#6366f1]/30 hover:bg-[#6366f1]/10 text-slate-800 dark:text-gray-100"><span class="magnetic-target">View Resume</span></a>
                    </div>
                    <div class="mt-5 flex flex-wrap gap-2 text-sm">
                        @foreach($socials as $s)
                            <a href="{{ $s->url }}" target="_blank" class="inline-flex items-center gap-2 px-3 py-1.5 rounded-md ring-1 ring-gray-200/70 hover:bg-white/60 text-gray-700 dark:text-gray-200"><span>{{ $s->label }}</span></a>
                        @endforeach
                    </div>
                </div>
                <div class="justify-self-center">
                    <div class="relative">
                        <div class="absolute -inset-6 rounded-full bg-gradient-to-br from-indigo-500/25 to-purple-500/25 blur-2xl"></div>
                        <div class="relative w-40 h-40 md:w-56 md:h-56 rounded-full p-[3px] bg-gradient-to-br from-indigo-500 to-purple-500 shadow-xl">
                            <div class="w-full h-full rounded-full bg-white/95 dark:bg-slate-900/70 overflow-hidden flex items-center justify-center">
                                @if($profile?->avatar_url)
                                    <img src="{{ $profile->avatar_url }}" alt="Avatar" class="w-full h-full object-cover" width="224" height="224" decoding="async">
                                @else
                                    <span class="text-5xl">👨‍💻</span>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            @break
        @case('minimal-accent')
        @default
            <!-- Accent gradient spot -->
            <div aria-hidden="true" class="pointer-events-none absolute -left-40 top-10 w-[28rem] h-[28rem] rounded-full bg-gradient-to-br from-indigo-400/30 to-purple-300/30 blur-3xl"></div>
            <div class="relative z-10 container mx-auto max-w-6xl px-4 py-20 grid md:grid-cols-2 gap-10 items-center">
                <!-- Left: Minimal + Accent -->
                <div class="text-slate-900 dark:text-gray-100">
                    <h1 class="text-4xl md:text-5xl font-extrabold tracking-tight text-slate-900 dark:text-white"><span style="font-family:'Cinzel',serif;">{{ $profile->name ?? 'Your Name' }}</span></h1>
                    <p class="mt-2 text-base md:text-lg text-gray-700/90 dark:text-gray-300">
                        <span data-typewriter data-phrases="{{ $profile?->typewriter_phrases ?: implode('|', array_filter([
                                $profile->title ?? 'Laravel Developer','Livewire Enthusiast','Clean Code Advocate','Problem Solver',
                            ])) }}" data-loop="true" data-speed="110" data-delay="1500">{{ $profile->title ?? 'Laravel Developer' }}</span>
                        <span class="tw-caret" aria-hidden="true">|</span>
                    </p>
                    <p class="mt-4 text-sm md:text-base leading-relaxed text-gray-700 dark:text-gray-300">{{ $profile->bio ?? 'Write a short, impactful bio here.' }}</p>
                    <div class="mt-7 flex flex-wrap gap-3">
                        <a href="#contact" data-magnetic class="magnetic-wrap inline-flex items-center gap-2 px-5 py-2 rounded-md bg-[#6366f1] text-white hover:bg-[#5558e6] shadow-sm"><span class="magnetic-target">Hire Me</span></a>
                        <a href="{{ route('resume.view') }}" data-magnetic class="magnetic-wrap inline-flex items-center gap-2 px-4 py-2 rounded-md ring-1 ring-[#6366f1]/30 hover:bg-[#6366f1]/10 text-slate-800 dark:text-gray-100"><span class="magnetic-target">View Resume</span></a>
                    </div>
                    <div class="mt-5 flex flex-wrap gap-2 text-sm">
                        @foreach($socials as $s)
                            <a href="{{ $s->url }}" target="_blank" class="inline-flex items-center gap-2 px-3 py-1.5 rounded-md ring-1 ring-gray-200/70 hover:bg-white/60 text-gray-700 dark:text-gray-200"><span>{{ $s->label }}</span></a>
                        @endforeach
                    </div>
                </div>
                <!-- Right: Circular avatar with subtle ring/glow -->
                <div class="justify-self-center">
                    <div class="relative">
                        <div class="absolute -inset-6 rounded-full bg-gradient-to-br from-indigo-500/20 to-purple-500/20 blur-2xl"></div>
                        <div class="relative w-40 h-40 md:w-56 md:h-56 rounded-full p-[3px] bg-gradient-to-br from-indigo-500 to-purple-500 shadow-xl">
                            <div class="w-full h-full rounded-full bg-white/95 dark:bg-slate-900/70 overflow-hidden flex items-center justify-center">
                                @if($profile?->avatar_url)
                                    <img src="{{ $profile->avatar_url }}" alt="Avatar" class="w-full h-full object-cover">
                                @else
                                    <span class="text-5xl">👨‍💻</span>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    @endswitch
</section>

<section id="services" class="py-16 reveal">
    <div class="container mx-auto max-w-6xl px-4">
        <h2 class="text-2xl font-bold mb-8 inline-flex items-center gap-2">
            <span class="inline-block h-5 w-1 rounded bg-[#6366f1]"></span>
            Services
        </h2>
        <div class="grid md:grid-cols-3 gap-6">
            @forelse($services as $svc)
            <div class="card card-accent card-gradient-2 card-hover p-6 reveal-up">
                <div class="text-3xl">{{ $svc->icon }}</div>
                <h3 class="mt-3 font-semibold text-lg">{{ $svc->title }}</h3>
                <p class="mt-2 text-gray-600">{{ $svc->summary }}</p>
            </div>
            @empty
                <p class="text-gray-500">No services added yet.</p>
            @endforelse
        </div>
    </div>
    </section>

<section id="testimonials" class="py-16 reveal">
    <div class="container mx-auto max-w-6xl px-4">
        <h2 class="text-2xl font-bold mb-8 inline-flex items-center gap-2">
            <span class="inline-block h-5 w-1 rounded bg-[#6366f1]"></span>
            Testimonials
        </h2>
        <div class="grid md:grid-cols-2 gap-6">
            @forelse($testimonials as $t)
            <div class="card card-accent card-gradient-1 card-hover p-6 reveal-up">
                <blockquote class="text-gray-700 italic">“{{ $t->quote }}”</blockquote>
                <div class="mt-4 flex items-center gap-3">
                    <div class="h-10 w-10 rounded-full bg-gray-100 flex items-center justify-center overflow-hidden">
                        @if($t->avatar_url)
                            <img src="{{ $t->avatar_url }}" alt="{{ $t->author }}" class="w-full h-full object-cover" width="40" height="40" loading="lazy" decoding="async">
                        @else
                            <span>💬</span>
                        @endif
                    </div>
                    <div>
                        <div class="font-medium">{{ $t->author }}</div>
                        <div class="text-sm text-gray-500">{{ $t->role }} @if($t->company) · {{ $t->company }} @endif</div>
                    </div>
                </div>
            </div>
            @empty
                <p class="text-gray-500">No testimonials yet.</p>
            @endforelse
        </div>
    </div>
</section>

<section id="projects" class="py-16 reveal">
    <div class="container mx-auto max-w-6xl px-4">
        <div class="flex items-end justify-between mb-8">
            <h2 class="text-2xl font-bold inline-flex items-center gap-2">
                <span class="inline-block h-5 w-1 rounded bg-[#6366f1]"></span>
                Projects
            </h2>
            <a href="#projects" class="text-sm text-indigo-600">View all</a>
        </div>
        <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            @forelse($projects as $p)
            <div class="group card card-hover overflow-hidden reveal-up">
                @if($p->image_url)
                    <div class="relative" data-tilt>
                        <img src="{{ $p->image_url }}" loading="lazy" class="h-40 w-full object-cover tilt-img blur-up" alt="{{ $p->title }}">
                    </div>
                @endif
                <div class="p-5">
                    <div class="flex items-center justify-between gap-2">
                        <h3 class="font-semibold text-lg">{{ $p->title }}</h3>
                        @if($p->year)
                            <span class="badge badge-indigo">{{ $p->year }}</span>
                        @endif
                    </div>
                    <p class="mt-2 text-gray-600 line-clamp-3">{{ $p->description }}</p>
                    @php($techs = collect(explode(',', (string)$p->tech_stack))->map(fn($t) => trim($t))->filter())
                    @if($techs->count())
                        <div class="mt-3 flex flex-wrap gap-2">
                            @foreach($techs as $tech)
                                @php($t = strtolower($tech))
                                @php($cls = match(true) {
                                    str_contains($t,'laravel') || str_contains($t,'php') => 'badge-rose',
                                    str_contains($t,'vue') || str_contains($t,'node') => 'badge-emerald',
                                    str_contains($t,'react') || str_contains($t,'next') => 'badge-cyan',
                                    str_contains($t,'tailwind') || str_contains($t,'css') => 'badge-indigo',
                                    str_contains($t,'mysql') || str_contains($t,'sql') => 'badge-amber',
                                    default => 'badge'
                                })
                                <span class="badge {{ $cls }}">{{ $tech }}</span>
                            @endforeach
                        </div>
                    @endif
                    <div class="mt-4 flex items-center gap-3 text-sm">
                        @if($p->github_url)
                            <a class="text-gray-700 hover:text-black" target="_blank" href="{{ $p->github_url }}">GitHub</a>
                        @endif
                        @if($p->live_url)
                            <a class="text-[#6366f1] hover:text-[#5558e6]" target="_blank" href="{{ $p->live_url }}">Live</a>
                        @endif
                    </div>
                </div>
            </div>
            @empty
                <p class="text-gray-500">No projects yet.</p>
            @endforelse
        </div>
    </div>
</section>

<section id="experience" class="py-16 reveal">
    <div class="container mx-auto max-w-6xl px-4">
        <h2 class="text-2xl font-bold mb-8 inline-flex items-center gap-2">
            <span class="inline-block h-5 w-1 rounded bg-[#6366f1]"></span>
            Experience
        </h2>
        <div class="space-y-6">
            @forelse($experiences as $e)
            <div class="card card-accent card-gradient-3 card-hover p-5 reveal-up">
                <div class="flex items-center justify-between flex-wrap gap-2">
                    <div>
                        <h3 class="font-semibold">{{ $e->role }} · {{ $e->company }}</h3>
                        <p class="text-sm text-gray-600">{{ $e->location }}</p>
                    </div>
                    <span class="badge">{{ optional($e->start_date)->format('M Y') }} — {{ $e->end_date ? $e->end_date->format('M Y') : 'Present' }}</span>
                </div>
                <p class="mt-3 text-gray-700">{{ $e->description }}</p>
            </div>
            @empty
                <p class="text-gray-500">No experience added yet.</p>
            @endforelse
        </div>
    </div>
</section>

<section id="skills" class="py-16 reveal">
    <div class="container mx-auto max-w-6xl px-4">
        <h2 class="text-2xl font-bold mb-8 inline-flex items-center gap-2">
            <span class="inline-block h-5 w-1 rounded bg-[#6366f1]"></span>
            Skills
        </h2>
        <div class="grid sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            @forelse($skills as $s)
            <div class="card card-hover p-4 flex items-center justify-between reveal-up">
                <span class="font-medium">{{ $s->name }}</span>
                <span class="badge badge-emerald">{{ $s->proficiency }}%</span>
            </div>
            @empty
                <p class="text-gray-500">No skills added yet.</p>
            @endforelse
        </div>
    </div>
</section>

<section id="contact" class="py-16 reveal">
    <div class="container mx-auto max-w-6xl px-4">
        <h2 class="text-2xl font-bold mb-6 inline-flex items-center gap-2">
            <span class="inline-block h-5 w-1 rounded bg-[#6366f1]"></span>
            Contact
        </h2>
        <div class="rounded-xl border border-gray-200 bg-white p-6">
            <p class="text-gray-700">Feel free to reach out at
                <a class="text-indigo-600 hover:underline" href="mailto:{{ $profile->email ?? 'you@example.com' }}">{{ $profile->email ?? 'you@example.com' }}</a>
            </p>
        </div>
    </div>
</section>
</div>
