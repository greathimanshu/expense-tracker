<!doctype html>
<html lang="en" class="h-full" data-admin-theme="light">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e($title ?? 'Admin'); ?> • <?php echo e(config('app.name')); ?></title>
    <meta name="description" content="Admin - <?php echo e(config('app.name')); ?>">
    <link rel="icon" href="/favicon.ico">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

</head>
<body class="h-full bg-gray-50 text-gray-800 antialiased">
    <div class="min-h-screen">
        <?php if (isset($component)) { $__componentOriginalbebe114f3ccde4b38d7462a3136be045 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbebe114f3ccde4b38d7462a3136be045 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.sidebar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbebe114f3ccde4b38d7462a3136be045)): ?>
<?php $attributes = $__attributesOriginalbebe114f3ccde4b38d7462a3136be045; ?>
<?php unset($__attributesOriginalbebe114f3ccde4b38d7462a3136be045); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbebe114f3ccde4b38d7462a3136be045)): ?>
<?php $component = $__componentOriginalbebe114f3ccde4b38d7462a3136be045; ?>
<?php unset($__componentOriginalbebe114f3ccde4b38d7462a3136be045); ?>
<?php endif; ?>
        <!-- Mobile sidebar drawer -->
        <div id="mobileSidebar" class="fixed inset-0 z-40 md:hidden hidden">
            <div data-close-sidebar class="absolute inset-0 bg-black/40"></div>
            <div class="absolute inset-y-0 left-0 w-72 bg-gradient-to-b from-indigo-600 to-violet-600 text-white shadow-2xl p-3">
                <div class="flex items-center justify-between h-12 border-b border-white/10">
                    <a href="<?php echo e(route('admin.dashboard')); ?>" wire:navigate class="font-semibold tracking-tight">Admin</a>
                    <button type="button" data-close-sidebar class="px-2 py-1 rounded-md bg-white/10 hover:bg-white/20">✕</button>
                </div>
                <div class="mt-3 text-sm">
                    <?php ($items = [
                      ['label'=>'Dashboard','route'=>'admin.dashboard','icon'=>'🏠'],
                      ['label'=>'Profile','route'=>'admin.profile','icon'=>'👤'],
                      ['label'=>'Projects','route'=>'admin.projects','icon'=>'📦'],
                      ['label'=>'Experience','route'=>'admin.experience','icon'=>'🧰'],
                      ['label'=>'Skills','route'=>'admin.skills','icon'=>'📊'],
                      ['label'=>'Social Links','route'=>'admin.socials','icon'=>'🔗'],
                      ['label'=>'Services','route'=>'admin.services','icon'=>'🧩'],
                      ['label'=>'Testimonials','route'=>'admin.testimonials','icon'=>'💬'],
                      ['label'=>'Education','route'=>'admin.education','icon'=>'🎓'],
                      ['label'=>'Certificates','route'=>'admin.certificates','icon'=>'📜'],
                      ['label'=>'Theme','route'=>'admin.theme','icon'=>'🎨'],
                      ['label'=>'SEO','route'=>'admin.seo','icon'=>'🔎'],
                      ['label'=>'Account','route'=>'admin.account','icon'=>'⚙️'],
                    ]); ?>
                    <ul class="space-y-1">
                      <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $it): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php ($active = request()->routeIs($it['route'])); ?>
                        <li>
                          <a href="<?php echo e(route($it['route'])); ?>" wire:navigate class="flex items-center gap-2 px-3 py-2 rounded-md transition-colors <?php echo e($active ? 'bg-white text-indigo-700' : 'text-white/80 hover:text-white hover:bg-white/10'); ?>">
                            <span class="w-5 text-center"><?php echo e($it['icon']); ?></span>
                            <span><?php echo e($it['label']); ?></span>
                          </a>
                        </li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        </div>

        <div class="md:pl-64 flex flex-col min-h-screen">
            <header class="sticky top-0 z-30 bg-white/80 backdrop-blur">
                <div class="h-0.5 w-full bg-gradient-to-r from-indigo-600 to-violet-600"></div>
                <div class="px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between border-b border-gray-100">
                    <div class="flex items-center gap-3">
                        <button type="button" data-open-sidebar class="md:hidden px-3 py-2 border border-indigo-200 text-indigo-700 rounded-md hover:bg-indigo-50">Menu</button>
                        <div class="text-sm text-gray-700 font-medium">Admin Panel</div>
                    </div>
                    <div class="flex items-center gap-3">
                        <?php if(auth()->guard()->check()): ?>
                            <div class="hidden sm:block text-sm text-gray-600"><?php echo e(auth()->user()->email); ?></div>
                            <form method="POST" action="<?php echo e(route('admin.logout')); ?>">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="px-3 py-1.5 rounded-md bg-indigo-600 text-white hover:bg-indigo-500 text-sm">Logout</button>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            </header>

            <main class="flex-1 p-4 sm:p-6 lg:p-8 bg-white/40">
                <div class="mx-auto max-w-6xl">
                    <?php echo e($slot); ?>

                </div>
            </main>

            <footer class="border-t border-gray-100 py-6 px-4 sm:px-6 lg:px-8 text-sm text-gray-500">
                © <?php echo e(date('Y')); ?> <?php echo e(config('app.name')); ?>. Admin.
            </footer>
        </div>
    </div>

    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\portfolio\resources\views/layouts/admin.blade.php ENDPATH**/ ?>